package primer_proyecto_mmf;

/**
 *
 * @author Manuel Monterroso Flores
 * @version JDK 17 NetBeans 12.5
 */
public class Primer_proyecto_MMF {

    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
{
for(int i = 0; i <= 12; i++)
{
System.out.print("12 * "+ i + " = " + 12 * i + "\n");
}
}
}

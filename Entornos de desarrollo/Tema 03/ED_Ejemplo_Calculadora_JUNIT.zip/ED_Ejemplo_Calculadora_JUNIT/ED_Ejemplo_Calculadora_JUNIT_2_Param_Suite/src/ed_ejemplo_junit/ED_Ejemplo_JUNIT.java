
package ed_ejemplo_junit;

public class ED_Ejemplo_JUNIT {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Calculadora cdr = new Calculadora();
        cdr.div(1, 0);
    }
    
}

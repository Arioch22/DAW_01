public class GrupoContactos {

	
	private String nombre;

	

}
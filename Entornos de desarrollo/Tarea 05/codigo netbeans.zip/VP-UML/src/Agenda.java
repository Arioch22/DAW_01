public class Agenda {

	

	/**
	 * 
	 * @param contacto
	 */
	public void InsertarContacto(Contacto contacto) {
		// TODO - implement Agenda.InsertarContacto
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nombre
	 */
	public Contacto ObtenerContacto(String nombre) {
		// TODO - implement Agenda.ObtenerContacto
		throw new UnsupportedOperationException();
	}

	public Contacto[] ObtenerContactos() {
		// TODO - implement Agenda.ObtenerContactos
		throw new UnsupportedOperationException();
	}

}
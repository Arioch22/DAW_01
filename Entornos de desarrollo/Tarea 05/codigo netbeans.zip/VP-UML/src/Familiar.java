public class Familiar extends Contacto {

	
	private String partentesco;

	

}
public class Cuenta_Usuario {

	
	private String email;
	private String nombre;

	

}
public class Contacto {

	
	private String nombre;
	private String direccion;
	private String telefono;
	private String email;

	

}
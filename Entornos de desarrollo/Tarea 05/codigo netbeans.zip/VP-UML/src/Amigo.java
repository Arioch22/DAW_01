
import java.util.GregorianCalendar;

public class Amigo extends Contacto {

	
	private GregorianCalendar fecha_nacimiento;

	

}
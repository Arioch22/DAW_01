package tarea07;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/** Ejercicio 4. Clasificación de coincidentes
 * @author profe
 */
public class Ejercicio04 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        final int CANTIDAD_COLORES = 15;
        List<String> listaColores1 = new ArrayList<>();
        List<String> listaColores2 = new ArrayList<>();
        Map<String, List<Integer>> mapCoincidencias = new HashMap<>();

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("CLASIFICACIÓN DE COINCIDENTES");
        System.out.println("-----------------------------");
        // No hay, pues se usa un número fijo de elementos aleatorios

        // Rellenamos la lista con aleatorios hasta que haya CANTIDAD_NUMEROS
        for (int i = 0; i < CANTIDAD_COLORES; i++) {
            listaColores1.add(Utilidades.colorAleatorio());
        }
        System.out.printf("Contenido inicial de la lista1: %s\n", listaColores1.toString());

        for (int i = 0; i < CANTIDAD_COLORES; i++) {
            listaColores2.add(Utilidades.colorAleatorio());
        }
        System.out.printf("Contenido inicial de la lista2: %s\n", listaColores2.toString());
        System.out.println();

        //----------------------------------------------
        //                 Procesamiento
        //----------------------------------------------
        for (int i = 0; i < listaColores1.size(); i++) {
            String color = listaColores1.get(i);
            if (color.equals(listaColores2.get(i))) {
                if (!mapCoincidencias.containsKey(color)) {
                    mapCoincidencias.put(color, new ArrayList());
                }
                mapCoincidencias.get(color).add(i);
            }
        }

        //----------------------------------------------
        //            Salida de resultados
        //----------------------------------------------
        System.out.printf("Clasificación de coincidencias: %s\n", mapCoincidencias);

    }

}

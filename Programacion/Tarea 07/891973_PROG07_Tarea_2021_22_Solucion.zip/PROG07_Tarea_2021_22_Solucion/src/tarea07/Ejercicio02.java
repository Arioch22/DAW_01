package tarea07;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Ejercicio 2. Búsqueda de coincidentes
 * @author profe
 */
public class Ejercicio02 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        final int CANTIDAD_COLORES = 10;
        List<String> listaColores1 = new ArrayList<>();
        List<String> listaColores2 = new ArrayList<>();
        List<String> listaColoresEliminados = new ArrayList<>();
        Set<String> setColoresEliminados = new HashSet<>();
        List<Integer> listaPosicionesEliminadas= new ArrayList<>();
        
        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("BÚSQUEDA DE COINCIDENTES");
        System.out.println("------------------------");
        // No hay, pues se usa un número fijo de elementos aleatorios

        // Rellenamos la lista con aleatorios hasta que haya CANTIDAD_NUMEROS
        for (int i = 0; i < CANTIDAD_COLORES; i++) {
            listaColores1.add(Utilidades.colorAleatorio()); 
        }
        System.out.printf("1. Contenido inicial de la lista1: %s\n", listaColores1.toString());

        for (int i = 0; i < CANTIDAD_COLORES; i++) {
            listaColores2.add(Utilidades.colorAleatorio()); 
        }
        System.out.printf("2. Contenido inicial de la lista2: %s\n", listaColores2.toString());
        System.out.println();
        
        //----------------------------------------------
        //               Procesamiento
        //----------------------------------------------

        // Recorremos a la vez las dos listas
        for (int i=0; i<listaColores1.size(); i++) {
            String color=listaColores1.get(i);
            // Comprobamos si en la misma posición encontramos el mismo color en ambas listas
            if (color.equals(listaColores2.get(i))) { 
                listaColoresEliminados.add(color);  // Se incluye ese color en la lista de eliminados
                setColoresEliminados.add(color);
                listaPosicionesEliminadas.add(i);   // Se incluye la posición en la lista de posiciones
                listaColores1.set(i, "---");          // Se "tacha" ese color en las listas originales
                listaColores2.set(i, "---");
            }
        }

        //----------------------------------------------
        //            Salida de resultados
        //----------------------------------------------
        System.out.printf("1. Contenido final de la lista 1:  %s\n", listaColores1.toString());
        System.out.printf("2. Contenido final de la lista 2:  %s\n", listaColores2.toString());
        System.out.printf("3. Contenido final de la lista de colores eliminados: %s\n", listaColoresEliminados.toString());
        System.out.printf("4. Contenido final de la lista de posiciones eliminadas: %s\n", listaPosicionesEliminadas.toString());
        System.out.printf("5. Contenido final del conjunto de colores eliminados: %s\n", setColoresEliminados.toString());
        
    }

}

package tarea07;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

/** Ejercicio 6. Ordenación de citas literarias
 * @author profe
 */
public class Ejercicio06 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        List<CitaLiteraria> listaCitas= new LinkedList<>();

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("ORDENACIÓN DE CITAS LITERARIAS");
        System.out.println("------------------------------");

        // Rellenamos la lista con las citas literarias
        
        listaCitas.add (new CitaLiteraria ("Soy el mejor en morir en la escena", "Libro 1"));
        listaCitas.add (new CitaLiteraria ("El mundo acaba hoy", "Libro 1", "Libro 2"));
        listaCitas.add (new CitaLiteraria ("Silba una vez y vendré siempre", "Libro 3", "Libro 4", "Libro 5"));
        listaCitas.add (new CitaLiteraria ("Un invitado invita a cien"));
        
        
        // Mostramos el contenido inicial de la lista
        System.out.printf("Contenido inicial de la lista:\n");
        mostrarListaCitas (listaCitas);
        
        //----------------------------------------------
        //     Procesamiento + Salida de resultados
        //----------------------------------------------

        // Ordenación de la lista por texto de la cita (alfabético) y la mostramos por pantalla
        System.out.printf ("\nOrdenación de la lista por texto de la cita (alfabético):\n");
        Collections.sort(listaCitas, new ComparadorCitasPorTexto() );
        mostrarListaCitas (listaCitas);
        
        // Ordenación de la lista por longitud de la cita y la mostramos por pantalla
        System.out.printf ("\nOrdenación de la lista por longitud de la cita:\n");
        Collections.sort(listaCitas, new ComparadorCitasPorLongitud() );
        mostrarListaCitas (listaCitas);

        // Ordenación de la lista por número de obras en las que aparece la cita y la mostramos por pantalla
        System.out.printf ("\nOrdenación de la lista por número de obras en las que aparece la cita:\n");
        Collections.sort(listaCitas, new ComparadorCitasPorNumObras() );
        mostrarListaCitas (listaCitas);
    }

    // Método que recorre una lista de citas y las muestra cada una por pantalla
    static void mostrarListaCitas (List<CitaLiteraria> listaCitas) {
        int contador=1;
        for (CitaLiteraria elemento: listaCitas) {
            System.out.printf ("%d. %s\n", contador++, elemento);
        }        
    }
            
}

/**
 * Clase que permite comparar dos objetos CitaLiteraria usando como criterio
 * de comparación el contenido (texto) de esas citas. Se trata de una comparación
 * alfabética o lexicográfica.
 * @author profe
 */
class ComparadorCitasPorTexto implements Comparator<CitaLiteraria> {
    @Override
    public int compare (CitaLiteraria c1, CitaLiteraria c2) {
        return c1.getTexto().compareToIgnoreCase(c2.getTexto());
    }
}

/**
 * Clase que permite comparar dos objetos CitaLiteraria usando como criterio
 * de comparación la longitud del contenido (texto) de esas citas. 
 * @author profe
 */class ComparadorCitasPorLongitud implements Comparator<CitaLiteraria> {
    @Override
    public int compare (CitaLiteraria c1, CitaLiteraria c2) {
        return c1.getTexto().length() -  c2.getTexto().length();
    }
}

/**
 * Clase que permite comparar dos objetos CitaLiteraria usando como criterio
 * de comparación la cantidad de veces que esas citas aparecen en distintas obras.
 * @author profe
 */class ComparadorCitasPorNumObras implements Comparator<CitaLiteraria> {
    @Override
    public int compare (CitaLiteraria c1, CitaLiteraria c2) {
        return c1.getUsos().size() -  c2.getUsos().size();
    }   
}
    
    

package tarea07;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.util.InputMismatchException;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/** Ejercicio 5. Clasificación de fechas por día de la semana
 * @author profe
 */
public class Ejercicio05 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        final int YEAR_MIN = 1900;
        final int YEAR_MAX = 2100;

        // Variables de entrada
        int year = 0;

        // Variables de salida
        Map<Month, Map<DayOfWeek, Set<LocalDate>>> mapDiasSemana = new TreeMap<>();

        // Variables auxiliares
        boolean errorEntrada;
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        // Objeto Scanner para lectura desde teclado
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("CLASIFICACIÓN DE FECHAS DE UN AÑO POR DÍA DE LA SEMANA");
        System.out.println("------------------------------------------------------");

        // Leer y comprobar el año (1900 y 2023), ambos incluidos
        do {
            System.out.printf("Introduzca año (%d-%d): \n", YEAR_MIN, YEAR_MAX);
            try {
                year = teclado.nextInt();
                errorEntrada = (year < YEAR_MIN || year > YEAR_MAX);
            } catch (InputMismatchException ex) {
                System.err.println("Error de lectura: no es un número entero válido.");
                errorEntrada = true;
                teclado.nextLine(); // "Purgamos" lo que haya en el teclado, que es incorrecto
            }
        } while (errorEntrada);
        System.out.println();

        //----------------------------------------------
        //                  Procesamiento
        //----------------------------------------------
        // Recorremos todos los días del año (bucle)
        LocalDate primerDia = LocalDate.of(year, 1, 1);       // Primer día del año (1 de enero)
        LocalDate ultimoDia = LocalDate.of(year, 12, 31);     // Último día del año (31 de diciembre)
        for (LocalDate dia = primerDia; !dia.isAfter(ultimoDia); dia = dia.plusDays(1)) {
            if (!mapDiasSemana.containsKey(dia.getMonth())) {
                mapDiasSemana.put(dia.getMonth(), new TreeMap<>());
            }
            if (!mapDiasSemana.get(dia.getMonth()).containsKey(dia.getDayOfWeek())) {
                mapDiasSemana.get(dia.getMonth()).put(dia.getDayOfWeek(), new TreeSet<>());
            }
            mapDiasSemana.get(dia.getMonth()).get(dia.getDayOfWeek()).add(dia);
        }

        //----------------------------------------------
        //           Salida de resultados
        //----------------------------------------------
        System.out.println("MUESTREO DE FECHAS");
        System.out.println("------------------");
        
        System.out.printf ("Fechas de febrero que caen en lunes: \n");
        for (LocalDate fecha: mapDiasSemana.get(Month.FEBRUARY).get(DayOfWeek.MONDAY)) {
            System.out.printf ("%s\n", fecha.format(formatoFecha));
        }
        System.out.printf ("Fechas de marzo que caen en jueves: \n");
        for (LocalDate fecha: mapDiasSemana.get(Month.MARCH).get(DayOfWeek.THURSDAY)) {
            System.out.printf ("%s\n", fecha.format(formatoFecha));
        }
        System.out.printf ("Fechas de diciembre que caen en domingo: \n");
        for (LocalDate fecha: mapDiasSemana.get(Month.DECEMBER).get(DayOfWeek.SUNDAY)) {
            System.out.printf ("%s\n", fecha.format(formatoFecha));
        }

        
    }

}

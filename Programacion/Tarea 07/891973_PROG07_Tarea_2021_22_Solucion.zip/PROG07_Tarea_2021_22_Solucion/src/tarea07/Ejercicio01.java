package tarea07;

import java.util.HashSet;
import java.util.Set;

/**
 * Ejercicio 1. Combinando colores.
 * @author Profe
 */
public class Ejercicio01 {
    
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        final int CANTIDAD_COLORES = 3;
        Set<String> setColores1, setColores2, union, interseccion, diferencia;
        // Al usar conjuntos (set) garantizamos que no se pueden repetir elementos
        setColores1=new HashSet<>();
        setColores2=new HashSet<>();
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        // No hay, pues se usa un número fijo de elementos aleatorios
        System.out.println("CONJUNTOS DE COLORES");
        System.out.println("--------------------");

        //----------------------------------------------
        //                  Procesamiento
        //----------------------------------------------
        // Rellenamos los conjuntos con aleatorios hasta que haya CANTIDAD_NUMEROS
        while (setColores1.size()<CANTIDAD_COLORES) {
            // Al añadir en un conjunto, si se produce una repetición, es como si no se añadiera nada
            setColores1.add(Utilidades.colorAleatorio()); 
        }
        while (setColores2.size()<CANTIDAD_COLORES) {
            // Al añadir en un conjunto, si se produce una repetición, es como si no se añadiera nada
            setColores2.add(Utilidades.colorAleatorio()); 
        }
        
        // Unión de los dos conjuntos 
        union= new HashSet<>(setColores1);
        union.addAll(setColores2);
        
        // Intersección de los conjuntos
        interseccion= new HashSet<>(setColores1);
        interseccion.retainAll(setColores2);
        
        // Diferencia de los conjuntos
        diferencia= new HashSet<>(setColores1);
        diferencia.removeAll(setColores2);
        
        //----------------------------------------------
        //              Salida de Resultados 
        //----------------------------------------------
        // Recorremos el conjunto y mostramos su contenido por pantalla
        System.out.printf ("Conjunto C1: %s\n", setColores1);
        System.out.printf ("Conjunto C2: %s\n", setColores2);
        System.out.printf ("Unión C1 y C2: %s\n", union);
        System.out.printf ("Intersección C1 y C2: %s\n", interseccion);
        System.out.printf ("Diferencia C1-C2: %s\n", diferencia);

        System.out.println();
    }
   
}

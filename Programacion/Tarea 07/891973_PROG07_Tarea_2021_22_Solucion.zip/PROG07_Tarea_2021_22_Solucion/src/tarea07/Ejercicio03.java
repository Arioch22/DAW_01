package tarea07;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.TreeMap;

/** Ejercicio 3. Un color por día
 * @author profe
 */
public class Ejercicio03 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        final int NUM_DIAS=5;
        Map<LocalDate, String> mapColoresPorFecha= new TreeMap<>();
        DateTimeFormatter formatoFecha = DateTimeFormatter.ofPattern ("dd/MM/yyyy");

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("ASIGNACIÓN DE COLORES: UN COLOR DIFERENTE POR CADA FECHA");
        System.out.println("--------------------------------------------------------");
        // No hay entrada de datos pues la estructura se rellena elementos aleatorios
        
        //----------------------------------------------
        //                  Procesamiento
        //----------------------------------------------
        // Vamos creando las claves del map y asignando un color para cada clave
        // El color no puede repetirse
        LocalDate fechaInicial= LocalDate.of (2022, 3, 1);  
        // Recorremos fechas desde 01/03/2022 hasta 01/03/2020+NUM_DIAS
        for (LocalDate fecha=fechaInicial; fecha.isBefore(fechaInicial.plusDays(NUM_DIAS)) ; fecha=fecha.plusDays(1)) {
            boolean colorRepetido= true;
            do { // Generamos un aleatorio y lo insertamos en la nueva fecha solo si aún no ha salido
                String color= Utilidades.colorAleatorio();
                if (!mapColoresPorFecha.containsValue(color)) {
                    mapColoresPorFecha.put (fecha, color);
                    colorRepetido= false;
                }
            } while (colorRepetido);
        }
   
        //----------------------------------------------
        //           Salida de resultados
        //----------------------------------------------
        System.out.printf( "Contenido final del mapa de colores organizado por fechas:\n");
        for (Map.Entry<LocalDate, String> elemento: mapColoresPorFecha.entrySet())
        {
            System.out.printf("Fecha %s: %s\n",elemento.getKey().format(formatoFecha),elemento.getValue());
        }
        
        
 
    }

}

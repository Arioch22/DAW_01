package tarea07;

/** Ejercicio 3. Un color por día
 * @author profe
 */
public class Ejercicio03 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        final int NUM_DIAS=5;

        
        
        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("ASIGNACIÓN DE COLORES: UN COLOR DIFERENTE POR CADA FECHA");
        System.out.println("--------------------------------------------------------");
        // No hay entrada de datos pues la estructura se rellena elementos aleatorios
        
        //----------------------------------------------
        //                  Procesamiento
        //----------------------------------------------

        
        
        
        
        //----------------------------------------------
        //           Salida de resultados
        //----------------------------------------------
        System.out.printf( "Contenido final del mapa de colores organizado por fechas:\n");

        
        
 
    }

}

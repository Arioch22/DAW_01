package tarea07;

/** Ejercicio 6. Ordenación de citas literarias
 * @author profe
 */
public class Ejercicio06 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("ORDENACIÓN DE CITAS LITERARIAS");
        System.out.println("------------------------------");

        // Rellenamos la lista con las citas literarias
        

        
        // Mostramos el contenido inicial de la lista
        
        //----------------------------------------------
        //     Procesamiento + Salida de resultados
        //----------------------------------------------

        // Ordenación de la lista por texto de la cita (alfabético) y la mostramos por pantalla

        
        // Ordenación de la lista por longitud de la cita y la mostramos por pantalla

        
        
        // Ordenación de la lista por número de obras en las que aparece la cita y la mostramos por pantalla


    }

            
}


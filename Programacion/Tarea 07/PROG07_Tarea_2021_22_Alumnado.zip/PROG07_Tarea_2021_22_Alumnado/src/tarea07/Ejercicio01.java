package tarea07;

/**
 * Ejercicio 1. Combinando colores.
 * @author Profe
 */
public class Ejercicio01 {
    
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        final int CANTIDAD_COLORES = 3;


        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        // No hay, pues se usa un número fijo de elementos aleatorios
        System.out.println("CONJUNTOS DE COLORES");
        System.out.println("--------------------");
        
        

        //----------------------------------------------
        //                  Procesamiento
        //----------------------------------------------
        // Rellenamos los conjuntos con aleatorios hasta que haya CANTIDAD_NUMEROS
        
        
        // Cálculo de la Unión de los dos conjuntos 
        
        
        // Cálculo de la Intersección de los conjuntos
        
        
        // Cálculo de la Diferencia de los conjuntos
        
        
        //----------------------------------------------
        //              Salida de Resultados 
        //----------------------------------------------




    }
   
}

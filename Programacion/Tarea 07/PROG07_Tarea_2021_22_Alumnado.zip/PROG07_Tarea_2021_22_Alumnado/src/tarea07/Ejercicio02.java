package tarea07;

/** Ejercicio 2. Búsqueda de coincidentes
 * @author profe
 */
public class Ejercicio02 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        final int CANTIDAD_COLORES = 10;



        
        //----------------------------------------------
        //               Entrada de datos 
        //----------------------------------------------
        System.out.println("BÚSQUEDA DE COINCIDENTES");
        System.out.println("------------------------");
        // No hay, pues se usa un número fijo de elementos aleatorios

        // Rellenamos la lista con aleatorios hasta que haya CANTIDAD_NUMEROS


        
        //----------------------------------------------
        //               Procesamiento
        //----------------------------------------------
        
        
        
        
        
        //----------------------------------------------
        //            Salida de resultados
        //----------------------------------------------



        
    }

}

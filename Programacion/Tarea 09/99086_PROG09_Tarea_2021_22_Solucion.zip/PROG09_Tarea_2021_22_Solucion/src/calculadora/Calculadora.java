package calculadora;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


/**
 * Clase principal desde donde arranca la aplicación
 * @author Profesor
 */
public class Calculadora extends Application {
    
    @Override
    public void start(Stage stage) {   
        
        Parent root;
        try {
            root = FXMLLoader.load(getClass().getResource("MiVistaFXML.fxml"));
            Scene scene = new Scene(root);       
            stage.setScene(scene);
            stage.setTitle("Calculadora del IES Aguadulce");
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(Calculadora.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}

package calculadora;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/**
 * La lógica de negocio en este caso consiste en los métodos necesarios para
 * evaluar la expresión que el usuario introduzca a través de la vista de la
 * aplicación.
 * 
 * @author Profesor
 */

public final class Modelo {
    
    
    private Modelo () { }
    
    /**
     * Evaluar la cadena que se pasa como parámetro
     * @param cadena String con la expresión a evaluar
     * @return Una cadena con el resultado o bien null si la cadena recibida
     *         como parámetro no era válida
     */
    public static String evaluar(String cadena) {
        Pattern patron;
        Object evaluacion = null ;
        // Expresión regular para verificar la validez una expresión
        // compuesta por números reales con operadores, por ejemplo 8.5+7.6 
		/*
		Explicación:
		
		^([-+/*]\d+(\.\d+)?)*
		^ 		Comienzo de la cadena
		[-+/*] 	Uno de estos operadores
		\d+ 		Uno o más números
		(\.\d+)? 	Un punto opcional seguido de uno o más números
		()* 		La expresión completa repetida cero o más veces


		*/
        patron = Pattern.compile("^\\d+(\\.\\d+)?([-+/*]\\d+(\\.\\d+)?)*");
        Matcher matcher = patron.matcher(cadena); 
        boolean exprValida = matcher.matches() ;
        
        // Si es una expresión válida se intenta evaluar
        if (exprValida) {
           
            ScriptEngineManager manager = new ScriptEngineManager();
            ScriptEngine engine = manager.getEngineByName("js");
            
            // Se intenta evaluar la expresión contenida en la variable cadena
            try {
                evaluacion = engine.eval(cadena);
            } catch (ScriptException ex) {
                evaluacion = "Error" ;
                Logger.getLogger(Calculadora.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        } 
        return String.format("%s", evaluacion); 
    }

    /**
     * Evalúa la expresión pasada en text y posteriormente realiza la raíz 
     * cuadrada dicha expresión
     * 
     * @param texto Presunta expresión a calcular la raíz
     * @return Cadena de caracteres con el resultado del cálculo o bien null
     *         si la expresión que se pasó no era válida
     */
    static String raizCuadrada(String texto) {
        String devolver = null ;
        
        // Comprobar si es una expresión válida y evaluarla antes de hacer la raíz
        String resultado = evaluar(texto);
        if (!(resultado.equalsIgnoreCase("null") )) {
            // Como ha sido válida pasamos el resultado de cadena a double
            double numero = Double.parseDouble(resultado);
            // Calcular la razí cuadrada
            double raiz = Math.sqrt(numero) ;
            //Pasar el resultado a String
            devolver = Double.toString(raiz);
        }
        return devolver ;
    }
   
}

package calculadora;

import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

/**
 * 
 * @author 
 */
public class Modelo {
    
    
    /**
     * Evaluar la cadena que se pasa como parámetro
     * @param cadena String con la expresión a evaluar
     * @return Una cadena con el resultado o bien null si la cadena recibida
     *         como parámetro no era válida
     */
    public static String evaluar(String cadena) {
        
         
        return null ; 
        
    }

    /**
     * Evalúa la expresión pasada en text y posteriormente realiza la raíz 
     * cuadrada dicha expresión
     * 
     * @param texto Presunta expresión a calcular la raíz
     * @return Cadena de caracteres con el resultado del cálculo o bien null
     *         si la expresión que se pasó no era válida
     */
    static String raizCuadrada(String text) {
        
        return null ;
    }
   
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ejercicio4;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.RasterFormatException;
import java.io.*;
import javax.imageio.ImageIO;
import javax.imageio.stream.ImageInputStream;

/**
 * Programa para trabajar con imágenes.
 * @profesorado
 */
public class Ejercicio4 {

    /**
    * Método principal.
    */
    public static void main(String[] args) {
        
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada
        int alto, ancho, srcPixel, valR, valG, valB;
        BufferedImage brImagen=null;
        
        //Debemos probar con las dos fotos que se adjuntan al proyecto
        //String rutaImagen = System.getProperty("user.dir") + "/recursos/foto.png";
        String rutaImagen = System.getProperty("user.dir") + "/recursos/foto2.png";
        
        // Variables de salida
        String salida;
        
        // Variables auxiliares
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        
        try(FileInputStream fImagen = new FileInputStream(rutaImagen);){
            ImageInputStream streamImagen = ImageIO.createImageInputStream(fImagen);
            brImagen = ImageIO.read(streamImagen);
            
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
            
            alto = brImagen.getHeight();
            ancho = brImagen.getWidth();
            
            System.out.println("Alto: "+alto);
            System.out.println("Ancho: "+ancho);
            
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        
            //A la hora de recorrer la imagen se recorre al revés
            for(int i=0; i<ancho;i++){
                for(int j=0; j<alto;j++){
                    srcPixel = brImagen.getRGB(i,j);
                    Color c = new Color(srcPixel);
                    valR = c.getRed();
                    valG = c.getGreen();
                    valB = c. getBlue();
                    if(valR==255 && valG==255 &&valB==255 )
                        System.out.print(" ");
                    else
                        System.out.print("*");
                }
                System.out.println("");
            }
        }catch (FileNotFoundException e) {
            System.out.println("Error: archivo " + rutaImagen + "·no encontrado.");
        } catch(IOException e){
            System.out.printf("Error de entrada/salida: %s\n",e.getMessage());
        }
        
        System.out.println ();
	System.out.println ("Archivo cerrado y procesamento finalizado");
	System.out.println ("---------");
        
        
        System.out.println ();
	System.out.println ("Fin del programa.");
    }
}

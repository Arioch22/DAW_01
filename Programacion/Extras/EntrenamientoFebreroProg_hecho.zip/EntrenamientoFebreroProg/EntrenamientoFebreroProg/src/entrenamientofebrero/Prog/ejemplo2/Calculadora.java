/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entrenamientofebrero.Prog.ejemplo2;

/**
 *
 * @author Usuario
 */
public class Calculadora {

    private double num1;
    private double num2;
    private char operacion;
    private String resultado;

    public Calculadora(double num1, double num2, char caracter){
          this.num1=num1;
          this.num2=num2;
          this.operacion=caracter;      
    }
    
    public String getResultado(){
        
        if (operacion == '+') {
            resultado = String.valueOf(num1+num2);
        } else if (operacion == '-') {

            resultado = String.valueOf(num1-num2);
        } else if (operacion == '*') {
            resultado = String.valueOf(num1*num2);
        } else if (operacion == '/') {
            resultado = String.valueOf( num1/num2);
        } else {
            return resultado = "operador inválido";

        }
         
        return resultado;
    }

    public void setNum1(double num1) {
        this.num1 = num1;
    }

    public void setNum2(double num2) {
        this.num2 = num2;
    }
    
    
   
}
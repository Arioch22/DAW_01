package ejercicio03;


/**
 * Interface Poligono
 * 
 * @author portatil_profesorado
 */
public interface Poligono {
    double getArea() ;
    int getLados() ;
    double getPerimetro();   
}

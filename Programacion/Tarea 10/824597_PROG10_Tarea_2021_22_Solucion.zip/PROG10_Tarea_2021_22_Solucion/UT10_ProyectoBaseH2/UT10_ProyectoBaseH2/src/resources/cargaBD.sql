

INSERT INTO PERSONAJE VALUES
(1, 'Han Solo', 'Contrabandista', 'Humano'),
(2, 'Luke Skywalker', 'Jedi hijo de Anakin', 'Jedi'),
(3, 'Leia', 'Princesa hija de Anakin', 'Humano'),
(4, 'C3PO', 'Androide propiedad de Leia', 'Robot'),
(5, 'R2D2', 'Robot propiedad de Leia', 'Robot'),
(6, 'Chewbacca', 'Wookiee del planeta Valmori', 'Wookiee'),
(7, 'Anakin Skywalker', 'Alias Darth Vader', 'Jedi'), 
(8, 'Obi-Wan Kenobi', 'Jedi maestro de Anakin', 'Jedi');

INSERT INTO NAVE VALUES
(1, 'Halcón Milenario', 3),
(2, 'Tie Fighter', 2),
(3, 'X Wing', 2),
(4, 'Y Wing', 4),
(5, 'Lanzadera GR', 8); 

INSERT INTO PILOTA VALUES
(1, 1, '1995-01-29', 3),
(1, 1, '2011-02-12', 0),
(2, 3, '2010-11-07', 5),
(6, 1, '1999-06-05', 5),
(8, 5, '2008-12-12', 5),
(2, 4, '2009-02-12', 8);

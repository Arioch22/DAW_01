package domotica;

public class Domotica {


}

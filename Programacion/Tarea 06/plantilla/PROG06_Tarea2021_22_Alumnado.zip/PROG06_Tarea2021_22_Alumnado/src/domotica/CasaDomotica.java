package domotica;

public class CasaDomotica {


}

package domotica.dispositivos;

public interface Activable {
    
        
}

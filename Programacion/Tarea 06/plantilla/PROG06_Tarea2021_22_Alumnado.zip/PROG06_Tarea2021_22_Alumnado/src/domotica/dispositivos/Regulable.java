package domotica.dispositivos;

public interface Regulable {
    
    
}

package domotica.dispositivos;

public class Bombilla  {


}

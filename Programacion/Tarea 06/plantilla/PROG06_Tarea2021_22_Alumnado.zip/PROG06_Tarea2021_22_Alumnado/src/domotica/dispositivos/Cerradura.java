package domotica.dispositivos;

public class Cerradura {

}

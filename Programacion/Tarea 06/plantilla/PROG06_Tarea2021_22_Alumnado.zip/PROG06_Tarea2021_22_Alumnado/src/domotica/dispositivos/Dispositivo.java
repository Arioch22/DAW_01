package domotica.dispositivos;

public class Dispositivo {

}

/**
 * Paquete principal de clases para elementos domóticos.
 * Incorpora herramientas de trabajo para otras clases así como la clase 
 * <code>CasaDomotica</code>.
 * @author profe
 */
package domotica;

package domotica.dispositivos;

/**
 * Interfaz <code>Activable</code>. Las clases que implementen esta interfaz 
 * representarán objetos que podrán activarse y desactivarse.
 * @author profe
 */
public interface Activable {
    
    /**
     * Activa el elemento.
     * @throws IllegalStateException si el elemento ya estaba activado
     */
    public void on() throws IllegalStateException;

    /**
     * Desactiva el elemento.
     * @throws IllegalStateException si el elemento ya estaba desactivado
     */
    public void off() throws IllegalStateException;
    
    /**
     * Obtiene el estado del elemento. Si está activado será <code>true</code>.
     * Si no lo está será <code>false</code>.
     * @return estado actual del elemento
     */
    public boolean getEstado();
        
}

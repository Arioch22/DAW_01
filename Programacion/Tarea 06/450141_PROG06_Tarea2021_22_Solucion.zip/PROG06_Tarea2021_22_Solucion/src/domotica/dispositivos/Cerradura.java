package domotica.dispositivos;

/**
 * Clase que representa un mecanismo de cerradura domótica. Podrá estar abierta 
 * (<code>false</code> o "desactivada") o cerrada (<code>true</code> o "activada").
 * @author profe
 */
public final class Cerradura extends Dispositivo implements Activable {

    // Atributos de objeto
    private boolean estado; // Indica si la cerradura está abierta (false o "desactivada") o cerrada (true o "activada")

    //------------------------------------------------------------
    //                        Constructores
    //------------------------------------------------------------
    /**
     * Constructor que instancia un objeto <code>Cerradura</code> 
     * a partir de una descripción, ubicación y estado inicial.
     * @param descripcion descripción del dispositivo
     * @param ubicacion ubicación (número de habitación) del dispositivo
     * @param estadoInicial estado inicial del dispositivo (cerradura abierta o cerrada)
     */
    public Cerradura(String descripcion, int ubicacion, boolean estadoInicial) {
        super(descripcion, ubicacion);  // Aprovechamos el constructor del ancestro (parte "genérica")
        this.estado= estadoInicial;     // Asginación del estado inicial (parte "específica")
    }

    /**
     * Constructor que instancia un objeto <code>Cerradura</code> 
     * a partir de una descripción y una ubicación. El estado inicial será "abierta" 
     * o "desactivada" (<code>false</code>).
     * @param descripcion descripción del dispositivo
     * @param ubicacion ubicación (número de habitación) del dispositivo
     */
    public Cerradura(String descripcion, int ubicacion) {
        this (descripcion, ubicacion, false); // Estado incial: cerradura abierta o "desactivada"
    }

    
    //------------------------------------------------------------
    //          Implementación de la interfaz Activable
    //------------------------------------------------------------    

    /**
     * Obtiene el estado actual de la cerradura. El valor <code>true</code> significa
     * que la cerradura está cerrada. El valor <code>false</code> indica que está abierta.
     * @return estado actual de la cerradura.
     */
    @Override
    public boolean getEstado() {
        return this.estado;
    }    

    
    /**
     * Activa la cerradura (cierra)
     * @throws IllegalStateException si la cerradura ya está cerrada (activada)
     */
    @Override
    public void on() throws IllegalStateException {
        if (this.estado) {
            throw new IllegalStateException("Cerradura ya activada (cerrada)");
        }
        this.estado= true;
    }

    /**
     * Desactiva la cerradura (abre)
     * @throws IllegalStateException si la cerradura ya está abierta (desactivada)
     */
    @Override
    public void off() throws IllegalStateException {
        if (!this.estado) {
            throw new IllegalStateException("Cerradura ya desactivada (abierta)");
        }
        this.estado= false;
    }

    //------------------------------------------------------------
    //                         Método toString
    //------------------------------------------------------------
    /**
     * Devuelve una cadena que representa el estado de la cerradura de forma textual.
     * @return cadena que representa el estado de la cerradura de forma textual.
     */
    @Override
    public String toString() {
        return String.format("%s estado:%s",
                super.toString(), this.estado ? "cerrada" : "abierta");
    }
}

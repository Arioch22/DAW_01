package domotica.dispositivos;

import domotica.Domotica;

/**
 * Clase abstracta que representa un dispositivo domótico genérico. Contendrá información
 * relativa a su <strong>identificación única</strong>, una <strong>descripción</strong> 
 * y su <strong>ubicación</strong> en la vivienda.
 * La identificación única se genera de manera automática mediante números consecutivos 
 * empezando por el 1.
 * @author profe
 */
public abstract class Dispositivo {
    
    // Atributos estáticos variables (estado de la clase)
    private static int nextId = 1;   // Contador de identificadores

    // Atributos de objeto 
    private final int id;
    private final String descripcion;
    private int ubicacion;

    //------------------------------------------------------------
    //                        Constructores
    //------------------------------------------------------------
    /**
     * Constructor de un objeto dispositivo domótico a partir de una descripción y
     * una ubicación.
     * @param descripción descripcion del dispositivo
     * @param ubicacion ubicación (número de habitación) del dispositivo
     * @throws IllegalArgumentException si el número de habitación no es válido
     */
    public Dispositivo(String descripción, int ubicacion) throws IllegalArgumentException {
        if (ubicacion < Domotica.MIN_UBICACION || ubicacion > Domotica.MAX_UBICACION) {
            throw new IllegalArgumentException(String.format("Ubicación no válida: %d", ubicacion));
        } else {
            this.id = Dispositivo.nextId++;
            this.descripcion = descripción;
            this.ubicacion = ubicacion;
        }
    }

    //------------------------------------------------------------
    //                    Métodos getter
    //------------------------------------------------------------
    /**
     * Obtiene el identificador único del dispositivo.
     * @return id del dispositivo.
     */
    public int getId() {
        return this.id;
    }

    /**
     * Obtiene la descripcion del dispositivo.
     * @return descripcion del dispositivo.
     */
    public String getDescripcion() {
        return this.descripcion;
    }

    /**
     * Obtiene la ubicación del dispositivo.
     * @return ubicación del dispositivo.
     */
    public int getUbicacion() {
        return this.ubicacion;
    }

    //------------------------------------------------------------
    //                         Método toString
    //------------------------------------------------------------
    /**
     * Devuelve una cadena que representa el estado de la bombilla de forma
     * textual.
     * @return cadena que representa el estado de la bombilla de forma textual.
     */
    @Override
    public String toString() {
        return String.format("tipo:%-9s id:%d descripción:\"%s\" ubicación:%d",
                this.getClass().getSimpleName(), this.id, this.descripcion, this.ubicacion);
    }

}

package domotica.dispositivos;

/**
 * Clase <code>Bombilla</code>. Representa una lámpara domótica "inteligente". 
 * Permite la regulación de su intensidad.
 * @author profe
 */
public final class Bombilla extends Dispositivo implements Activable, Regulable {

    // Atributos públicos constantes (rangos y valores por omisión)
    /**
     * Mínima intensidad posible para una bombilla: {@value MIN_INTENSIDAD}.
     */
    public static final int MIN_INTENSIDAD = 0;
    /**
     * Máxima intensidad posible para una bombilla: {@value MAX_INTENSIDAD}.
     */
    public static final int MAX_INTENSIDAD = 10;

    // Atributos de estado (variables)
    private int intensidad;         // Intensidad actual de la bombilla
    private int numVecesManipulada; // Número de veces que ha sido manipulada (encendida o apagada) de manera "efectiva"
    

    //------------------------------------------------------------
    //                        Constructores
    //------------------------------------------------------------
    /**
     * Instancia un objeto <code>Bombilla</code> a partir de una descripcón y una
     * ubicación.
     * @param descripcion descripción del dispositivo
     * @param ubicacion ubicación (número de habitación) del dispositivo
     */
    public Bombilla(String descripcion, int ubicacion) {
        super(descripcion, ubicacion);
        this.intensidad= Bombilla.MIN_INTENSIDAD;
        this.numVecesManipulada = 0;
    }

    //------------------------------------------------------------
    //                    Métodos getter
    //------------------------------------------------------------
    /**
     * Obtiene el número de veces que la bombilla ha sido manipulada.
     * @return número de veces que la bombilla ha sido manipulada.
     */
    public int getNumVecesManipulada() {
        return this.numVecesManipulada;
    }
    
    //------------------------------------------------------------
    //          Implementación de la interfaz Activable
    //------------------------------------------------------------    
    /**
     * Obtiene el estado actual de la bombilla. El valor <code>true</code> significa
     * que la bombilla está encendida (en cualquier intensidad menos la mínima).
     * El valor <code>false</code> que está apagada (mínima intensidad posible).
     * @return estado actual de la bombilla.
     */
    @Override
    public boolean getEstado() {
        return this.intensidad != Bombilla.MIN_INTENSIDAD;
    }

    /**
     * Enciende la bombilla. Se establece su intensidad al valor máximo.
     * @throws IllegalStateException si la bombilla ya está encendida
     */
    @Override
    public void on() throws IllegalStateException {
        if (this.getEstado()) {
            throw new IllegalStateException("Bombilla ya encendida");
        }
        this.numVecesManipulada++;
        this.intensidad= Bombilla.MAX_INTENSIDAD;
    }

    /**
     * Apaga la bombilla. Se establece su intensidad al valor mínimo.
     * @throws IllegalStateException si la bombilla ya está apagada
     */
    @Override
    public void off() throws IllegalStateException  {
        if (!this.getEstado()) {
            throw new IllegalStateException("Bombilla ya apagada");
        }
        this.numVecesManipulada++;
        this.intensidad= Bombilla.MIN_INTENSIDAD;
    }

    //------------------------------------------------------------
    //         Implementación de la interfaz Regulable
    //------------------------------------------------------------
    /**
     * Obtiene la intensidad actual de la bombilla.
     * @return intensidad actual del bombilla.
     */
    @Override
    public int getIntensidad() {
        return this.intensidad;
    }

    /**
     * Incrementa en un punto la intensidad lumínica de la bombilla. Si ya se ha
     * alcanzado la intensidad máxima, se permanece en la intensidad máxima y no 
     * se considera que haya sido manipulada.
     * @return intensidad alcanzada tras la operación.
     */
    @Override
    public int up() {
        if (this.intensidad < Bombilla.MAX_INTENSIDAD) {
            this.intensidad++;
            this.numVecesManipulada++;
        }
        return this.intensidad;
    }

    /**
     * Decrementa en un punto la intensidad lumínica de la bombilla. Si ya se ha
     * alcanzado la intensidad mínima, se permanece en la intensidad mínima y no
     * se considera que haya sido manipulada.
     * @return intensidad alcanzada tras la operación.
     */
    @Override
    public int down() {
        if (this.intensidad > Bombilla.MIN_INTENSIDAD) {
            this.intensidad--;
            this.numVecesManipulada++;
        }
        return this.intensidad;
    }

    //------------------------------------------------------------
    //                         Método toString
    //------------------------------------------------------------
    /**
     * Devuelve una cadena que representa el estado de la bombilla de forma textual.
     * @return cadena que representa el estado de la bombilla de forma textual
     */
    @Override
    public String toString() {
        return String.format("%s estado:%s int:%-2d NVM:%-3d",
                super.toString(), this.getEstado() ? "encendida" : "apagada",
                this.intensidad, this.numVecesManipulada);
    }

}

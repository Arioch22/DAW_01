package domotica;

import domotica.dispositivos.Activable;
import domotica.dispositivos.Bombilla;
import domotica.dispositivos.Cerradura;
import domotica.dispositivos.Dispositivo;

/**
 * Clase que representa una vivienda domótica con un conjunto de dispositivos
 * domóticos de distintos tipos.
 * @author profe
 */
public class CasaDomotica {

    // Atributos de objeto
    private final String propietario;
    private final String descripcion;
    private final Dispositivo[] listaDispositivos;

    // Estos atributos no son necesarios. Se pueden calcular a partir de la lista de dispositivos.
    // Ahora bien, pueden mejorar el funcionamiento de algunos métodos.
    // Si se decide incorporarlos por facilidad de implementación y mejora de la eficiencia de los getter, 
    // debe hacerse con precaución para que su uso no genere inconsistencias con la información "real" contenida
    // en el array
    private int numBombillas;
    private int numCerraduras;

    //--------------------------------------------------------------------------
    //                          CONSTRUCTORES
    //--------------------------------------------------------------------------
    /**
     * Constructor para una vivenda domótica.
     * @param propietario propietario de la vivienda
     * @param descripcion descripción de la vivienda
     * @param dispositivos lista variable de dispositivos domóticos integrados en la
     * vivienda
     */
    public CasaDomotica(String propietario, String descripcion, Dispositivo... dispositivos) {
        // Resevamos espacio para el array de dispositivos
        this.listaDispositivos = new Dispositivo[dispositivos.length];
        // Iniciamos atributos básicos
        this.propietario = propietario;
        this.descripcion = descripcion;
        // Iniciamos atributos de tipo "contador"
        this.numBombillas = 0;
        this.numCerraduras = 0;

        // Rellenamos el array de dispositivos con los parámetros recibidos
        // (y a la vez "contabilizamos" cuántas bombillas y cerraduras hay
        // Usando un for "tradicional" con índices (opción a)
        for (int disp = 0; disp < dispositivos.length; disp++) {
            listaDispositivos[disp] = dispositivos[disp];
            if (listaDispositivos[disp] instanceof Bombilla) {
                this.numBombillas++;
            } else if (listaDispositivos[disp] instanceof Cerradura) {
                this.numCerraduras++;
            }
        }

/*        
        // Usando un for "mejorado" o "foreach" ("para cada") (opcíon b)
        for (Dispositivo disp : dispositivos) {
            if (disp instanceof Bombilla) {
                this.numBombillas++;
            } else if (disp instanceof Cerradura) {
                this.numCerraduras++;
            }
        }
*/
  
        // O bien:
        // System.arraycopy(dispositivos, 0, listaDispositivos, 0, dispositivos.length);
        // En tal caso el número de bombillas y de cerraduras habrá que calcularlos en los getter
    }

    //--------------------------------------------------------------------------
    //                            MÉTODOS GETTER
    //--------------------------------------------------------------------------
    /**
     * Obtiene el número de dispositivos integrados en la vivienda.
     * @return número de dispositivos integrados en la vivienda
     */
    public int getNumDispositivos() {
        return this.listaDispositivos.length;
    }

    /**
     * Obtiene el número de dispositivos de tipo <code>Bombilla</code> integrados
     * en la vivienda.
     * @return número de bombiilas instaladas en la vivienda
     */
    public int getNumBombillas() {
        return this.numBombillas;
        // Si no disponemos de este atributo, habrá que hacer un barrido por todo el array de dispositivos
    }

    /**
     * Obtiene el número de dispositivos de tipo <code>Cerradura</code> integrados
     * en la vivienda.
     * @return número de cerraduras instaladas en la vivienda
     */
    public int getNumCerraduras() {
        return this.numCerraduras;
        // Si no disponemos de este atributo, habrá que hacer un barrido por todo el array de dispositivos
    }

    //--------------------------------------------------------------------------
    //                          MÉTODOS DE ACCIÓN
    //--------------------------------------------------------------------------
    /**
     * Cierra todas las cerraduras de la casa que estén aún sin cerrar.
     * @return el número de cerraduras que se han activado (cerrado)
     */
    public int cerrarCerraduras() {
        int cerradurasActivadas = 0;
        for (Dispositivo dispositivo : listaDispositivos) {
            if (dispositivo instanceof Cerradura) {
                if ( !((Cerradura) dispositivo).getEstado() ) {
                    // Solo activamos (cerramos) la cerradura si aún no está activada.
                    ((Cerradura) dispositivo).on();
                    cerradurasActivadas++;
                }
            }
        }
        return cerradurasActivadas;
    }

    /**
     * Activa todos los dispositivos de la casa que estén aún sin activar.
     * @return el número de dispositivos que se han activado
     */
    public int activarDispositivosActivables() {
        int dispositivosActivados = 0;
        for (Dispositivo dispositivo : listaDispositivos) {
            if (dispositivo instanceof Activable) {
                if ( !((Activable) dispositivo).getEstado() ) {
                    // Solo activamos (cerramos) la cerradura si aún no está activada.
                    ((Activable) dispositivo).on();
                    dispositivosActivados++;
                }
            }
        }
        return dispositivosActivados;
    }




    @Override
    /**
     * Devuelve una cadena que representa el estado de la casa de forma textual.
     * @return cadena que representa el estado de la casa de forma textual
     */
    public String toString() {
        StringBuilder resultado = new StringBuilder();
        StringBuilder blanco = new StringBuilder();
        StringBuilder bordes = new StringBuilder();
        // +--- (82 veces) ----+
        bordes.append("+").append("-".repeat(82)).append("+").append("\n");
        // | (82 veces) |
        blanco.append("|").append(" ".repeat(82)).append("|").append("\n");

        resultado.append(bordes);
        resultado.append(String.format("|%-82s|\n", "CASA DOMOTICA"));
        resultado.append(String.format("|Propietario: %-69s|\n", this.propietario));
        resultado.append(String.format("|Descripción: %-69s|\n", this.descripcion));
        resultado.append(bordes);
        for (int estancia = Domotica.MIN_UBICACION; estancia <= Domotica.MAX_UBICACION; estancia++) {
            resultado.append(String.format("|Estancia: %-72d|\n", estancia));
            resultado.append(blanco);
            for (Dispositivo dispositivo : listaDispositivos) {
                if (dispositivo.getUbicacion() == estancia) {
                    resultado.append(String.format("|%-82s|\n", dispositivo));
                }
            }
            resultado.append(bordes);
        }

        return resultado.toString();
    }

}


/**
 * Proporciona las clases o programas de prueba para las clases del paquete <code>domotica</code>
 * y subpaquetes.
 * @author profe
 */
package pruebas;
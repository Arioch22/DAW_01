package pruebas;

import domotica.dispositivos.Dispositivo;

/**
 * Herramientas para los programas de prueba
 * @author profe
 */
public final class Utilidades {

    private Utilidades() {

    }

    /**
     * Muestra por pantalla el conteido de un array de dispositivos.
     * Genera una línea por dispositivo.
     * @param listaDispositivos array con los dispositivos
     */
    public static void mostrarContenidoArrayDisp(Dispositivo[] listaDispositivos) {
        for (int i = 0; i < listaDispositivos.length; i++) {
            Dispositivo disp = listaDispositivos[i];
            System.out.printf("Dispositivo %d: %s\n", i, disp);
        }
        System.out.println();
    }

}

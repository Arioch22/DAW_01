/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pro_und08.flujos;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Ejemplos escritura ficheros de texto
 *
 * @author profesor
 */
public class EjemploFileWriter {

    public static void main(String[] args) {
        
        // Usaremos BufferedWriter y FileWriter 

//        modoAntiguo();
  
        // Modo nuevo. Usaremos BufferedWriter y FileWriter 
//        modoNuevo(); // Java7

        // usamos FileWriter 
//        ejemploFileWriter();

        // usamos PrintWriter
//        ejemploPrintWriter();


        // escribir con codificacion  específica
//        escribrConCodificacion();

        // leemos de teclado y volcamos en un fichero de texto
        // usando printWriter
        ejemploEscrituraDesdeTeclado();
    }

    /**
     * Usamos filewriter y BufferedWriter
     */
    private static void modoAntiguo() {
        String cadena = "Linea de texto que escribimos en el fichero\n";
        List<String> listaCadenas = Arrays.asList("Linea uno de escritura", "Linea dos","Linea tres");
        // creamos los flujos
        BufferedWriter bw = null;
        FileWriter fw = null;
        // si el fichero no existe, lo crea
        // Si el fichero existe, lo borra y lo crea de nuevo
        try {
            fw = new FileWriter("filewriter.txt");
            bw = new BufferedWriter(fw);
            for (String cad : listaCadenas) {
                bw.write(cad);
                bw.newLine(); // ajusta el caracter newline al sistema en que estemos
            }

        } catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        } finally {
            // liberamos los recursos de los flujos
            try {
                if (bw != null) {
                    bw.close();
                }

                if (fw != null) {
                    fw.close();
                }
            } catch (IOException ex) {
                System.err.format("IOException: %s%n", ex);
            }
        }

    }

    /**
     * Usamos filewriter y bufferedreader pero con try with resources. Crea un
     * recurso en el try y luego lo libera
     */
    private static void modoNuevo() {
        String cadena = "Linea de texto que escribimos en el fichero\n";
        List<String> listaCadenas = Arrays.asList("Linea uno de escritura", "Linea dos");

        // si el fichero no existe, lo crea
        // Si el fichero existe, lo borra y lo crea de nuevo
        // try-with-resources: crea los recursos 
        // y los libera automaticamente al finalizar el bloque
        try ( FileWriter writer = new FileWriter("filewriter.txt"); 
                BufferedWriter bw = new BufferedWriter(writer)) {
            for (String cad : listaCadenas) {
                bw.write(cad);
                bw.newLine(); // ajusta el caracter newline al sistema en que estemos
            }

        } catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }

    }

    /**
     * haciendo uso solamente de FileWriter (con try-with-resources)
     */
    private static void ejemploFileWriter() {

//      ejemplo escribir una cadena o parte de ella        
//
//        String data = "Ejemplo FileWriter.";
//        try ( FileWriter fileWriter = new FileWriter("Filewriter.txt")) {
//            fileWriter.write(data);
//          fileWriter.write(data, 4, 10); /// escribimos parte de la cadena
//        } catch (Exception e) {
//            e.printStackTrace();
//        }


//      ejemplo escribir varias lineas consecutivas
        List<String> listaCadenas = Arrays.asList("Linea uno de escritura", "Linea dos");
        try ( FileWriter fw = new FileWriter("Filewriter.txt")) {
            for (String cad : listaCadenas) {
                fw.write(cad);
                fw.write("\n"); // no tenemos método para escribir fin de linea en FileWriter
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * usamos PrintWriter. Podemos hacerlo a traves de un filewriter o a traves
     * de un bufferedWriter
     *
     */
    private static void ejemploPrintWriter() {
        // Uso printwriter a atraves de un Filewriter
//        String nombre = "Filewriter.txt";
//        try {
//            FileWriter fw = new FileWriter(nombre,true);// append: fichero existe previamente y queremos añadir texto
//            PrintWriter pw = new PrintWriter(fw,true); // para abrir con autoflush
//            pw.println("Hola"); 
//            pw.println("Maria"); 
//            pw.printf("%s", "Hola Manuelw2a"); 
//            //  pw.close();   // si no abro con autoflush
//        } catch (IOException ex) {
//            System.err.println("Error accediendo a " + nombre);
//        }

        // Uso printwriter a atraves de un BufferedWriter
        List<String> listaCadenas = Arrays.asList("Linea uno de escritura", "Linea dos");
        try ( PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("Filewriter.txt")))) {

            for (String cad : listaCadenas) {
                pw.println(cad); // tiene un metodo con fin de linea incorporado
                // se podria chequear el error con boolean hayError = pw.checkError();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * Lee del teclado y escribe en un fichero de texto
     */
    private static void ejemploEscrituraDesdeTeclado() {
        System.out.println("Por favor escriba varias lineas usando el teclado, y al terminar escriba fin\n");
        try {
            PrintWriter out = null;
            out = new PrintWriter(new FileWriter("FileWriter1.txt", false));

            BufferedReader br = new BufferedReader(
                    new InputStreamReader(System.in));
            String s;
            while (!(s = br.readLine()).equals("fin")) {
                out.println(s);
            }
            out.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    private static void escribrConCodificacion() {

        OutputStreamWriter osw = null;
        try {
            osw = new OutputStreamWriter(new FileOutputStream("Fichero2.txt"),StandardCharsets.UTF_8 );
            osw.write("Hola mundo\n");
            osw.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(EjemploFileWriter.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(EjemploFileWriter.class.getName()).log(Level.SEVERE, null, ex);
        }

//        try {
////            FileWriter fw = new FileWriter("Fichero2.txt", Charset.forName("UTF-16"));
//            FileWriter fw = new FileWriter("Fichero2.txt", Charset.forName("UTF8"));
////             FileWriter fw = new FileWriter("Fichero2.txt", Charset.forName("ISO-8859-1"));
//            fw.write("Hola María Luisa");
//            fw.flush();
//            fw.close();
//        } catch (IOException ex) {
//            Logger.getLogger(EjemploFileWriter.class.getName()).log(Level.SEVERE, null, ex);
//        }
//
    }
}

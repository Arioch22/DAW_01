/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pro_und08.flujos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 *
 * @author profesor
 */
public class CopiaFichero {

    public static void main(String[] args) {
        try {
            copiaFichero("c:/tmp/kkk/app-release.apk", "c:/tmp/kkk/fSalida.apk");
        } catch (Exception ex) {
            System.err.println("Error copiando fichero.:" + ex.getMessage());
        }
        
    }

    private static void copiaFichero(String pathFte, String pathDest) throws Exception {
        FileInputStream fi;
        FileOutputStream fo;
        try {
            fi = new FileInputStream(pathFte);
        } catch (FileNotFoundException ex) {
            throw new Exception("Fichero no encontrado " + pathFte);
        }
        try {
            fo = new FileOutputStream(pathDest);
        } catch (FileNotFoundException ex) {
            throw new Exception("Fichero no encontrado " + pathFte);
        }
        try {
            int n = 0;

            byte[] pepe = new byte[256];
            while ((n = fi.read(pepe)) >= 0) {
                fo.write(pepe, 0, n);
            }

            fi.close();
            fo.close();
        } catch (IOException ex) {
            throw new Exception(ex.getMessage());
        }

    }
}

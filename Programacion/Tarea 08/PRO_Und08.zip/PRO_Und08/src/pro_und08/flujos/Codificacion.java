/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pro_und08.flujos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;

/**
 *
 * @author profesor
 */
public class Codificacion {

    public static void main(String[] args) {
        averiguaCodificacion();
    }

    private static void averiguaCodificacion() {
        FileInputStream fichero;
        try {
            // Elegimos fichero para leer flujos de bytes "crudos"
            fichero = new FileInputStream("Fichero2.txt");
            // InputStreamReader sirve de puente de flujos de byte a caracteres
            InputStreamReader unReader = new InputStreamReader(fichero);
            // Vemos la codificación actual
            System.out.println(unReader.getEncoding());
        } catch (FileNotFoundException ex) {
            System.err.println(Codificacion.class.getName());
        }
    }
}

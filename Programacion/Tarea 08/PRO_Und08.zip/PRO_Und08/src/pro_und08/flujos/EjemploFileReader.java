/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pro_und08.flujos;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

/**
 *
 * @author profesor
 */
public class EjemploFileReader {

    public static void main(String[] args) {
        // Lectura fichero 
//        EjemploFileReader();

        // lectura fichero with resources
        EjemploFileReader1();

    }

    /**
     * Usamos FileReader con Bufferedreader
     */
    private static void EjemploFileReader() {
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;

        try {
            // Apertura del fichero y creacion de BufferedReader para poder
            // hacer una lectura comoda (disponer del metodo readLine()).
//         archivo = new File ("Filewriter.txt");
//         fr = new FileReader ( archivo); // usamos un File en el constructor
            fr = new FileReader("Filewriter.txt");
            br = new BufferedReader(fr);

            // Lectura del fichero
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // En el finally cerramos el fichero, para asegurarnos
            // que se cierra tanto si todo va bien como si salta 
            // una excepcion.
            try {
                if (null != fr) {
                    fr.close();
                }
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
    }

    /**
     * Usamos FileReader con Bufferedreader with resources
     */
    private static void EjemploFileReader1() {

        try ( FileReader fr = new FileReader("Filewriter.txt");  BufferedReader br = new BufferedReader(fr)) {

            // Lectura del fichero
            String linea;
            while ((linea = br.readLine()) != null) {
                System.out.println(linea);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pro_und08.flujos;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author profesor
 */
public class IOStandard {

//    static int valor;
    static int valor;

    public static void main(String[] args) {

//        System.out.println("Introduzca una letra");
//        try {
//            valor = System.in.read();
//        } catch (IOException ex) {
//            System.err.println("Se ha cometido un error");
//        }
//        System.out.println("valor:" + valor);
//
//        String s = Character.toString((char) valor);
//        
//        System.out.println("introducido:" + s);
//        System.err.println("Si uso la salida standard de error sale esto");
        System.out.println("Introduzca un texto:");
        int c;
        int contador = 0;
        try {
            // se lee hasta encontrar el fin de línea
            while ((c = System.in.read()) != '\n') {
                contador++;
                System.out.print((char) c);
            }
        } catch (IOException ex) {
            System.err.println("error " + ex.getMessage());
        }
        System.out.println(); // Se escribe el fin de línea
        System.err.println("Contados " + contador + " bytes en total.");

    }

}

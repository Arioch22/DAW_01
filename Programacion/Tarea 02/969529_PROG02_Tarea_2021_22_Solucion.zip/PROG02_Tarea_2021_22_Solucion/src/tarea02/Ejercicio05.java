package tarea02;

import java.util.Scanner;

/**
 * Ejercicio 5: construcción de cajas.
 * 
 * @author Profe
 */
public class Ejercicio05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        final byte MIN_FILAS =  2;
        final byte MAX_FILAS = 10;
        final byte MIN_COLUMNAS =  2;
        final byte MAX_COLUMNAS = 10;

        // Variables de entrada
        byte numFilas, numColumnas;
        byte rellena;

        // Variables de salida
        String cadenaResultado = "";

        // Variables auxiliares
        boolean cajaRellena;
        
        // Clase Scanner para petición de datos
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CONSTRUCCIÓN DE CAJAS");
        System.out.println("---------------------");
        do {
            System.out.print("Introduzca número de filas (" + 
                    MIN_FILAS + "-" + MAX_FILAS + "): ");
            numFilas = teclado.nextByte();
        } while (numFilas < MIN_FILAS || numFilas > MAX_FILAS);

        do {
            System.out.print("Introduzca número de columnas (" + 
                    MIN_COLUMNAS + "-" + MAX_COLUMNAS + "): ");
            numColumnas = teclado.nextByte();
        } while (numColumnas < MIN_COLUMNAS || numColumnas > MAX_COLUMNAS);
        
        System.out.print ("¿Caja rellena? (0: vacía, cualquier otro número rellena) ");        
        rellena= teclado.nextByte();
        cajaRellena= (rellena!=0);
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Construccion de la última fila (usando '+' para las esquinas y '-' para el resto del borde)
        cadenaResultado += '+';  // Esquina superior izquierda
        for (byte columna=1; columna <= numColumnas-2; columna++)
            cadenaResultado += '-';  // Borde superior
        cadenaResultado += '+';      // Esquina superior derecha
        cadenaResultado += '\n';     // Nueva línea
        
        // Construcción de las filas internas (entre 2 y numFilas-1)
        for (byte fila = 2; fila <= numFilas-1; fila++) {
            cadenaResultado += '|';  // Borde izquierdo
            for (byte columna = 2; columna <= numColumnas-1; columna++) {
                if (cajaRellena)
                    cadenaResultado += (fila-1);
                else
                    cadenaResultado += " ";
            }
            cadenaResultado += '|';   // Borde derecho
            cadenaResultado += '\n';  // Nueva línea
        }

        // Construccion de la última fila (usando '+' para las esquinas y '-' para el resto del borde)
        cadenaResultado += '+';  // Esquina superior izquierda
        for (int columna=1; columna <= numColumnas-2; columna++)
            cadenaResultado += '-';  // Borde superior
        cadenaResultado += '+';      // Esquina superior derecha
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println("Caja de tamaño " + numFilas + "x" + numColumnas + (cajaRellena ? " rellena" : " vacía") + ": ");
        System.out.println();
        System.out.println(cadenaResultado);
    }

}

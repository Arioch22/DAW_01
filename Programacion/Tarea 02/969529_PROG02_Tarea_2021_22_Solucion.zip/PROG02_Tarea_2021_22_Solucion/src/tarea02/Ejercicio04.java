package tarea02;

import java.util.Scanner;

/**
 * Ejercicio 4: puntuación de un texto.
 *
 * @author Profe
 */
public class Ejercicio04 {

    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        byte MIN_MULTIPLICADOR= 1;
        byte MAX_MULTIPLICADOR= 3;
        byte MIN_LONG_TEXTO=    5;
        
        byte VALOR_VOCAL=         1;
        byte VALOR_XYZ_MINUSCULA= 2;
        byte VALOR_X_MAYUSCULA=   5;
        byte VALOR_OTROS_CHAR=   -1;

        // Variables de entrada
        String texto;
        byte multiplicador;
                
        // Variables de salida
        int puntuacionFinal;

        // Variables auxiliares
        int puntuacionAcumulada;  

        // Clase Scanner para petición de datos
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("VALOR DE UN TEXTO");
        System.out.println("------------------");
        do {
            System.out.print("Introduzca un texto con al menos " + MIN_LONG_TEXTO + " caracteres: ");
            texto= teclado.nextLine();
        } while (texto.length() < MIN_LONG_TEXTO); // Si la longitud del texto es menor de 5 se vuelve a pedir

        do {
            System.out.print("Introduzca el valor del multiplicador (entre " + MIN_MULTIPLICADOR + 
                    "-" +  MAX_MULTIPLICADOR + "): ");
            multiplicador = teclado.nextByte();
        } while (multiplicador<MIN_MULTIPLICADOR || multiplicador>MAX_MULTIPLICADOR); // Si no está en el rango 1-3 se vuelve a pedir

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Recorremos cada caracter y acumulamos su puntuación
        puntuacionAcumulada=0; // Acumulador iniciado a cero
        for (short i=0; i<texto.length(); i++) {
            char letra= texto.charAt(i);
            switch (letra) {
                    case 'a': case 'e': case'i': case 'o': case 'u':
                    case 'A': case 'E': case'I': case 'O': case 'U':
                        puntuacionAcumulada += VALOR_VOCAL;
                        break;
                        
                    case 'x': case 'y': case'z':
                        puntuacionAcumulada += VALOR_XYZ_MINUSCULA;
                        break;

                    case 'X':
                        puntuacionAcumulada += VALOR_X_MAYUSCULA;
                        break;
                    
                    default:
                        puntuacionAcumulada += VALOR_OTROS_CHAR;
            }
        }

        // Calculamos la puntuación final 
        puntuacionFinal= puntuacionAcumulada * multiplicador;
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.println("El valor del texto es: " + puntuacionFinal);
    }
}

package tarea02;

import java.util.Scanner;

/**
 * Ejercicio 3: Valor de un naipe en el juego del tute.
 * 
 * @author Nombre alumno/a
 */
public class Ejercicio03 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        
        // Variables de entrada
        
        // Variables de salida

        // Variables auxiliares

        // Clase Scanner para petición de datos de entrada
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("VALOR DE UN NAIPE EN EL TUTE");
        System.out.println("----------------------------");

        
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        
        
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");



    }
}

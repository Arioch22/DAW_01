package tarea02;

import java.util.Scanner;

/**
 * Ejercicio 5: construcción de cajas.
 * 
 * @author Nombre alumno/a
 */
public class Ejercicio05 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada

        // Variables de salida

        // Variables auxiliares
        
        // Clase Scanner para petición de datos
        Scanner teclado = new Scanner(System.in);

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CONSTRUCCIÓN DE CAJAS");
        System.out.println("---------------------");


        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------



        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");



    }

}

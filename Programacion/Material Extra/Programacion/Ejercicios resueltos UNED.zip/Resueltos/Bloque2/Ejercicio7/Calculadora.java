package bloque2;

/*  Escribir una clase Calculadora que realice las funciones típicas de una calculadora. La calculadora tendrá
    un método que pedirá al usuario tres valores: operación (+,-,*,/), operando1, operando2; y a partir de ellos
    mostrará el resultado de la operación.
    Cuando el usuario introduzca una Z como valor de la operación el programa parará. Si se introduce cualquier
    otro carácter se debe producir una excepción definida por el usuario imprimiendo un mensaje de error.       */

import java.util.InputMismatchException;
import java.util.Scanner;


public class Calculadora {

    private boolean continuar;

    private double operando1;

    private double operando2;

    private double resultado;

    private char operacion;

    Scanner myScan=new Scanner(System.in);




    public Calculadora() {

        operando1=0.00;

        operando2=0.00;

        resultado=0.00;

        char suma = '+';

        char resta = '-';

        char multiplicacion = '*';

        char division = '/';

        continuar=true;

    }

    public void iniciarCalculadora() {

        System.out.print("Introduce la  operación [+,-,*,/] a continuación, escribe 'Z' para salir del programa");

        System.out.println();

        operacion=myScan.next().charAt(0);

        if (operacion!='Z') {

            System.out.println("Introduce el primer operando a continuación");
            operando1=myScan.nextDouble();

            System.out.println("Introduce el segundo operando a continuación");
            operando2 = myScan.nextDouble();
        }




    }

    public void seleccionOperacion(char operacion) {

        if (operacion=='+') {

            resultado=operando1 + operando2;

            System.out.println("La operación es: " + operando1 + operacion + operando2);

            System.out.println("El resultado de la operación es: " + resultado);

            System.out.println("");


        }

        else if (operacion=='-') {

            resultado=operando1 - operando2;

            System.out.println("La operación es: " + operando1 + operacion + operando2);

            System.out.println("El resultado de la operación es: " + resultado);

            System.out.println("");


        }

        else if (operacion=='*') {

            resultado=operando1 * operando2;

            System.out.println("La operación es: " + operando1 + operacion + operando2);

            System.out.println("El resultado de la operación es: " + resultado);

            System.out.println("");


        }

        else if (operacion=='/') {

            resultado=operando1 / operando2;

            System.out.println("La operación es: " + operando1 + operacion + operando2);

            System.out.println("El resultado de la operación es: " + resultado);

            System.out.println("");

        }

    }

    public static void main(String[] args) {

        Scanner myScan2=new Scanner(System.in);

        Calculadora miCalculadora=new Calculadora();

        System.out.println("Bienvenido a la aplicación de Calculadora.");

        do {

            try {

                miCalculadora.iniciarCalculadora();

                if (miCalculadora.operacion=='Z' || miCalculadora.operacion=='z') {

                    miCalculadora.continuar = false;

                    miCalculadora.operando2=0;

                    System.out.println("Has salido del programa, hasta luego");

                }else {

                    miCalculadora.seleccionOperacion(miCalculadora.operacion);

                }

            }catch (InputMismatchException e) {

                System.out.println("Introduce caracteres númericos y usa la coma ',' para separar");

                miCalculadora.continuar=false;

            }

        } while (miCalculadora.continuar);

    }


}

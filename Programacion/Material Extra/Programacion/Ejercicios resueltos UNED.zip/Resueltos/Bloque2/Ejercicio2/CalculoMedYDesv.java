package JavaPruebas;

public class CalculoMedYDesv {

    public static  void main(String[] args) {

        MediaYDesviacion miCalculo=new MediaYDesviacion();

        miCalculo.setRandomNums();

        miCalculo.hallarMedia();

        miCalculo.hallarDesvia();

    }

}

class MediaYDesviacion {

    public MediaYDesviacion() {

        arrayNum=new double[30];

    }

    public void setRandomNums() {

        for (j=0;j<30;j++) {

            arrayNum[j]=Math.random();

            System.out.println(arrayNum[j]);

        }

    }

    public void hallarMedia() {

        media=0;

        for(i=0;i<30;i++) {

            media+=arrayNum[i];

        }

        media/=30;

        System.out.println("");

        System.out.println("La media del array es: " + media);

    }

    public void hallarDesvia() {

        desviacion=0;
        double valor=0;

        for(k=0;k<30;k++) {

            valor+=Math.pow(arrayNum[k]-media, 2);

        }

        valor/=30;

        desviacion=Math.sqrt(valor);

        System.out.println("");

        System.out.println("La desviación típica del array es: " + desviacion);


    }

    double [] arrayNum;

    private int i, j, k;

    private double media;

    private double desviacion;

}

package bloque2;

/*  Escribir una clase Cancion con los siguientes atributos:
    1. titulo: una variable String que guarda el título de la canción.
    2. autor: una variable String que guarda el autor de la canción.
        y los siguientes métodos:
    1. Cancion(String, String): constructor que recibe como parámetros el título y el autor de la canción
        (por este orden).
    2. Cancion(): constructor predeterminado que inicializa el título y el autor a cadenas vacías.
    3. dameTitulo(): devuelve el título de la canción.
    4. dameAutor(): devuelve el autor de la canción
    5. ponTitulo(String): establece el título de la canción.
    6. ponAutor(String): establece el autor de la canción. */


class Cancion {

    private String titulo;

    private String autor;

    public Cancion() {

        titulo="";

        autor="";

    }

    public Cancion(String titulo, String autor) {

        this.titulo=titulo;

        this.autor=autor;

    }

    public String dameTitulo() {

        return titulo;

    }

    public String dameAutor() {

        return autor;

    }

    public void ponTitulo(String titulo) {

        this.titulo=titulo;

    }

    public void ponAutor(String autor) {

        this.autor=autor;

    }

    public static void main(String[] args) {

        Cancion miCancion=new Cancion("StairWay to Heaven","Led Zeppelin");

        System.out.println(miCancion.dameTitulo());

        System.out.println(miCancion.dameAutor());

        Cancion miCancion2=new Cancion();

        System.out.println(miCancion2.dameTitulo());

        System.out.println(miCancion2.dameAutor());

        miCancion2.ponTitulo("La Cucaracha");

        miCancion2.ponAutor("Popular");

        System.out.println(miCancion2.dameTitulo());

        System.out.println(miCancion2.dameAutor());



    }

}
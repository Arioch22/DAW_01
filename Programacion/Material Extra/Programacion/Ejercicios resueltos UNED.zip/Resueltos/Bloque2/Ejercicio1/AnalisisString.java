package JavaPruebas;

import java.util.Scanner;

public class AnalisisString {

    public static void main(String[] args) {

        String miCadena="";
        Scanner myScan=new Scanner(System.in);

        System.out.println("Introduce una cadena de caracteres(frase o palabra)");

        miCadena=myScan.nextLine();

        Analisis miAnalisis=new Analisis();

        miAnalisis.setCadena(miCadena);

        System.out.println("La cadena es: " + miAnalisis.getCadena());

        System.out.println("El número total de caracteres es: " + miAnalisis.numTotal());

        System.out.println("");

        miAnalisis.vocales();



    }

}

class Analisis {

    public Analisis() {

        cadena="";

        numCaracteres=0;

        vocales=0;

        a=0;

        e=0;

        i=0;

        o=0;

        u=0;

    }

    public void setCadena(String cadena) {

        this.cadena=cadena;

    }

    public String getCadena() {

        return cadena;

    }

    public int numTotal() {

        return cadena.length();

    }

    public void vocales() {

        for(int j=0;j<cadena.length();j++) {
            if (cadena.charAt(j)=='A'||cadena.charAt(j)=='a') {

                vocales+=1;
                a+=1;

            }else if(cadena.charAt(j)=='E'||cadena.charAt(j)=='e') {

                vocales+=1;
                e+=1;

            }else if(cadena.charAt(j)=='I'||cadena.charAt(j)=='i') {

                vocales+=1;
                i+=1;

            }else if(cadena.charAt(j)=='O'||cadena.charAt(j)=='o') {

                vocales+=1;
                o+=1;

            }else if(cadena.charAt(j)=='U'||cadena.charAt(j)=='u') {

                vocales+=1;
                u+=1;

            }

        }

        System.out.println("El número de vocales es: " + vocales);
        System.out.println("");

        System.out.println("Numero de letras A/a: " + a);
        System.out.println("Numero de letras E/e: " + e);
        System.out.println("Numero de letras I/i: " + i);
        System.out.println("Numero de letras O/o: " + o);
        System.out.println("Numero de letras U/u: " + u);


    }

    private String cadena;

    private int numCaracteres;

    private int vocales;

    private int a;

    private int e;

    private int i;

    private int o;

    private int u;

}

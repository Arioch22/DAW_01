package bloque2;

/*  Realizar un programa capaz de multiplicar dos matrices2 de tamaño variable introducidas por el usuario
    desde teclado.

    El programa se asegurará de que, para que sea posible la realización del producto de dos matrices, el número
    de columnas de la primera matriz coincida con el número de filas de la segunda matriz.   */

import java.util.Scanner;

public class ProductoMatrices {

    Scanner myScan=new Scanner(System.in);

    int[][] matriz1;

    int[][] matriz2;

    int filas1;

    int columnas1;

    int filas2;

    int columnas2;

    public ProductoMatrices() {

        filas1=0;
        columnas1=0;

        filas2=0;
        columnas2=0;


    }

    public void rellenaMatriz() {

        System.out.println("Introduce la primera matriz: ");

        System.out.println("Número de filas: ");

        filas1=myScan.nextInt();

        System.out.println("Número de columnas: ");

        columnas1=myScan.nextInt();

        matriz1= new int[filas1][columnas1];

        for(int i=0;i< matriz1.length;i++) {

            for(int z=0; z<matriz1[0].length;z++) {

                System.out.println("Elemento " + "[" + i + "] " + "[" + z + "]: ");

                matriz1[i][z]=myScan.nextInt();

            }

        }

        System.out.println("Introduce la segunda matriz: ");

        System.out.println("Número de filas: ");

        filas2=myScan.nextInt();

        System.out.println("Número de columnas: ");

        columnas2=myScan.nextInt();

        if (columnas1 != filas2)
            throw new RuntimeException("No se pueden multiplicar las matrices");

        matriz2= new int[filas2][columnas2];

        for(int i=0;i< matriz2.length;i++) {

            for(int z=0; z<matriz2[0].length;z++) {

                System.out.println("Elemento " + "[" + i + "] " + "[" + z + "]: ");

                matriz2[i][z]=myScan.nextInt();

            }

        }

    }

    public void multiplicaMatrices() {

        if (columnas1 != filas2)
            throw new RuntimeException("No se pueden multiplicar las matrices");

        int[][] multiplicacion = new int[matriz1.length][matriz2.length];

        int suma;

        for(int k=0;k< matriz1.length; k++) {

            for (int l=0;l< matriz2.length;l++) {

                suma=0;

                for (int x=0;x< matriz2.length;x++) suma += matriz1[k][x] * matriz2[x][l];

                multiplicacion[k][l]=suma;

            }

        }

        System.out.println();

        System.out.println("La matriz resultado es: ");

        System.out.println();

        for (int i=0;i< multiplicacion.length;i++) {

            for (int j=0;j<multiplicacion[i].length;j++) {

                System.out.print(multiplicacion[i][j] + "  ");

            }

            System.out.println();

        }

    }

public static void main(String[] args) {

        ProductoMatrices multiMatriz=new ProductoMatrices();

        multiMatriz.rellenaMatriz();

        multiMatriz.multiplicaMatrices();

    }

}

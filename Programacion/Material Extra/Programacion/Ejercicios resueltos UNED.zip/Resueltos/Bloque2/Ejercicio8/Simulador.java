package bloque2;

/* Realizar un programa que simule aleatoriamente 5 partidas del juego, produciendo una salida del estilo de
        la figura */

import java.util.Random;


public class Simulador {

    public static void main(String[] args) {

        int i=1;

        Jugador jugador1=new Jugador("Jugador 1");

        Jugador jugador2=new Jugador("Jugador 2");

        while(i<=5) {
            jugador1.jugar();
            jugador2.jugar();

            System.out.println("----------------------");
            System.out.println("Partida " + i);
            System.out.println("----------------------");

            System.out.println(jugador1.getNombre() + ":");
            jugador1.imprimirJugada();

            System.out.println(jugador2.getNombre() + ":");
            jugador2.imprimirJugada();

            Arbitro elArbitro=new Arbitro(jugador1.consultarJugada(), jugador2.consultarJugada());
            elArbitro.decision();

            i++;

        }

    }

}

class Arbitro {

    private final String jugador1;

    private final String jugador2;


    public Arbitro(String jugador1, String jugador2) {

        this.jugador1=jugador1;

        this.jugador2=jugador2;

    }

    public void decision() {

        String resultado;
        if (jugador1.equals("Piedra") && jugador2.equals("Papel")) {

            resultado ="Resultado: Gana Jugador 2";

            System.out.println("");

            System.out.println(resultado);

        }

        else if (jugador1.equals("Papel") && jugador2.equals("Tijera")) {

            resultado ="Resultado: Gana Jugador 2";

            System.out.println("");

            System.out.println(resultado);

        }

        else if (jugador1.equals("Tijera") && jugador2.equals("Piedra")) {

            resultado ="Resultado: Gana Jugador 2";

            System.out.println("");

            System.out.println(resultado);

        }

        else if (jugador1.equals("Papel") && jugador2.equals("Piedra")) {

            resultado ="Resultado: Gana Jugador 1";

            System.out.println("");

            System.out.println(resultado);

        }

        else if (jugador1.equals("Piedra") && jugador2.equals("Tijera")) {

            resultado ="Resultado: Gana Jugador 1";

            System.out.println("");

            System.out.println(resultado);

        }

        else if (jugador1.equals("Tijera") && jugador2.equals("Papel")) {

            resultado ="Resultado: Gana Jugador 1";

            System.out.println("");

            System.out.println(resultado);

        }

        else if (jugador1.equals("Piedra") && jugador2.equals("Piedra")) {

            resultado ="Resultado: Empate";

            System.out.println("");

            System.out.println(resultado);

        }

        else if (jugador1.equals("Papel") && jugador2.equals("Papel")) {

            resultado ="Resultado: Empate";

            System.out.println("");

            System.out.println(resultado);

        }

        else if (jugador1.equals("Tijera") && jugador2.equals("Tijera")) {

            resultado ="Resultado: Empate";

            System.out.println("");

            System.out.println(resultado);


        }



    }

}

class Jugador{

    public String nombre;

    private String jugada;

    public Jugador(String nombre) {

        this.nombre=nombre;

    }

    public String getNombre() {

        return nombre;

    }

    public void jugar() {

        Jugada j = new Jugada();

        jugada=j.generarJugada();

    }

    public String consultarJugada() {

        return jugada;

    }

    public void imprimirJugada() {

        System.out.println("        " + jugada);

    }

}

class Jugada {

    Random miRandom = new Random();

    private String jugada;

    private final String[] jugadas;


    public Jugada() {

        jugadas= new String[3];

        jugadas[0]="Piedra";

        jugadas[1]="Papel";

        jugadas[2]="Tijera";

    }

    public String generarJugada() {

        int rdmNum=miRandom.nextInt(jugadas.length);

        switch (rdmNum) {

            case 0:
                jugada=jugadas[0];
                break;

            case 1:
                jugada=jugadas[1];
                break;

            case 2:
                jugada=jugadas[2];
                break;

            default:
                System.out.println("Ocurrió un error");
        }

        return jugada;

    }

}

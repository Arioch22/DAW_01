package bloque2;

/*Realizar un programa que simule un cajero automático de monedas. Los tipos de monedas que dispone el
        cajero son de 10, 20 y 50 céntimos de euro y 1 y 2 euros. Inicialmente el cajero tiene 100 monedas de cada
        tipo, que se van consumiendo para proporcionar las cantidades solicitadas. El cajero debe obtener la cantidad
        solicitada con los tipos de moneda que tenga en cada momento, tratando siempre de utilizar las monedas de
        mayor valor.    */

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Scanner;

public class ElCajero {

    // Clase principal contiene método main


    public static void main(String[] args) {

        double cantInic = 1;

        CajeroBanco miCajero = new CajeroBanco();

        Scanner myScan = new Scanner(System.in);

        while (cantInic != 0.00) {

            System.out.println("Introduce una cantidad a retirar. Introduce '0' para terminar");

            cantInic = myScan.nextDouble();

            miCajero.retirarDinero(cantInic);

        }
    }


    public static class CajeroBanco {


        // Declaramos las monedas que se iran sustrayendo.
        private int m2;
        private int m1;
        private int m50;
        private int m20;
        private int m10;

        //Declaramos las monedas que se irán usando.
        private int m2Usa;
        private int m1Usa;
        private int m50Usa;
        private int m20Usa;
        private int m10Usa;

        //Se declaran e inicializan los valores de cada moneda en forma de constantes
        private final double EURO2 = 2.00;
        private final double EURO1 = 1.00;
        private final double CTM50 = 0.50;
        private final double CTM20 = 0.20;
        private final double CTM10 = 0.10;

        //Se declaran los valores de las monedas pero en forma de BigDecimal,
        // para evitar pérdidas de precisión al realizar operaciones
        private final BigDecimal monEu2 = new BigDecimal(EURO2).setScale(2, RoundingMode.HALF_DOWN);
        private final BigDecimal monEu1 = new BigDecimal(EURO1).setScale(2, RoundingMode.HALF_DOWN);
        private final BigDecimal monCt50 = new BigDecimal(CTM50).setScale(2, RoundingMode.HALF_DOWN);
        private final BigDecimal monCt20 = new BigDecimal(CTM20).setScale(2, RoundingMode.HALF_DOWN);
        private final BigDecimal monCt10 = new BigDecimal(CTM10).setScale(2, RoundingMode.HALF_DOWN);


        //Contructor por defecto
        public CajeroBanco() {
            m2 = 100;
            m1 = 100;
            m50 = 100;
            m20 = 100;
            m10 = 100;

            m2Usa = 0;
            m1Usa = 0;
            m50Usa = 0;
            m20Usa = 0;
            m10Usa = 0;

        }


        public void retirarDinero(double valor) {

            BigDecimal bigValor = new BigDecimal(valor).setScale(2, RoundingMode.DOWN);

            if(bigValor.doubleValue()>=0.10) {

                bigValor=bigValor.setScale(1, RoundingMode.DOWN);

                System.out.println("Se entrega la cantidad de: " + bigValor.doubleValue() + "0");

                bigValor=bigValor.setScale(2, RoundingMode.HALF_DOWN);

            }

            while (bigValor.doubleValue() >= 0.1) {

                if (bigValor.doubleValue() >= 2.00 && m2 > 0) {

                    m2--;

                    m2Usa++;

                    bigValor = bigValor.subtract(monEu2);


                } else if (bigValor.doubleValue() >= 1.00 && m1 > 0) {

                    m1--;

                    m1Usa++;

                    bigValor = bigValor.subtract(monEu1);


                } else if (bigValor.doubleValue() >= 0.50 && m50 > 0) {

                    m50--;

                    m50Usa++;

                    bigValor = bigValor.subtract(monCt50);



                } else if (bigValor.doubleValue() >= 0.20 && m20 > 0) {

                    m20--;

                    m20Usa++;

                    bigValor = bigValor.subtract(monCt20);

                } else if (bigValor.doubleValue() >= 0.10 && m10 > 0) {

                    m10--;

                    m10Usa++;

                    bigValor = bigValor.subtract(monCt10);

                } else if(m2==0&&m1==0&&m50==0&&m20==0&&m10==0) {

                    System.out.println("Se han acabado las monedas. Falta: " + bigValor.doubleValue() + "0€");

                    bigValor=new BigDecimal(0);

                } else {

                     System.out.println("Introduce números enteros o con 1 decimal señalado por una coma simple");

                }

            }

            if (bigValor.doubleValue() == 0) {

                System.out.println("En " + getM2() + " monedas de 2, " + getM1() + " monedas de 1, " +
                        getM50() + " monedas de 0.50, " + getM20() + " monedas de 0.20, " + getM10()
                        + " monedas de 0.10");

                m2Usa=0;
                m1Usa=0;
                m50Usa=0;
                m20Usa=0;
                m10Usa=0;

            }

        }

        public int getM2() {

            return m2Usa;

        }

        public int getM1() {

            return m1Usa;

        }

        public int getM50() {

            return m50Usa;

        }

        public int getM20() {

            return m20Usa;

        }

        public int getM10() {

            return m10Usa;

        }

    }
}

package JavaPruebas;

import java.util.Scanner;

/**
 *
 * @author Pablo Rojas Sáinz
 *
 * Realizar un programa que imprima la tabla de multiplicar por un número leído como dato.
 *
 */

public class TablaMultiplicar {

    public static void main(String[] args) {

        int tabla; // Declarado un número entero que corresponde a la tabla que queremos imprimir.

        Scanner scan=new Scanner(System.in); // Declaración del objeto Scanner.

        System.out.print("¿Número? "); // Pide al usuario que introduca el número de la tabla

        tabla=scan.nextInt();           // Asigna ese número a la variable tabla
        scan.close();


        System.out.println("Tabla de multiplicar por " + tabla);
        System.out.println("==========================");

        for(int i=1;i<11;i++) { // Inicio de bucle "for" que iterará 10 veces

            if(i<10) { // Imprime la tabla con valores del 1 al 9.

                /*System.out.println(tabla + "  x  " + i + "  =  " + (tabla*i));*/

                System.out.printf(tabla + " x  %d  =  %d", i, (i*tabla));
                System.out.println();



            }else if(i==10) { // Para multiplicar por 10 utiliza un formato diferente

                System.out.printf(tabla + " x %d  =  %d", i, (i*tabla));


            }else {

                System.out.println("Introduce un número entero, por favor.");

            }

        }




    }

}
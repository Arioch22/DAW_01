package bloque1;

import java.util.Scanner;

public class NumerosPerfectos {

    public static void main(String[] args) {
        //Metodo main en una clase principal o clase driver.

        int numero1, numero2;

        Scanner myScan=new Scanner(System.in);

        System.out.println("Introduce un  numero entero");

        numero1=myScan.nextInt();

        CalculoPerfectos miCalculo=new CalculoPerfectos();

        miCalculo.setNum(numero1);

        System.out.println("El número elegido es: " + miCalculo.getNum());

        miCalculo.compruebaPerfecto();

        System.out.println("El número introducido es perfecto: " + miCalculo.esPerfecto());

        System.out.println("Introduce un  numero entero");

        numero2=myScan.nextInt();

        myScan.close();

        System.out.println("Se imprimirá una lista con los números perfectos hasta el: " + numero2);

        miCalculo.listaPerfectos(numero2);

        System.out.println(miCalculo.finDelPrograma());




    }

}

class CalculoPerfectos {


    public void setNum(int num) {
        //Metodo para establecer el número que debemos comprobar.

        this.num=num;

    }

    public long getNum() {
        //Método que devuelve el número que debemos comprobar.

        return num;

    }

    public void compruebaPerfecto() {
        //Metodo que comprueba si el numero a comprobar es perfecto y en caso afirmativo
        // cambia el valor booleano a "true".

        while(i < num) {

            if (num % i ==0) {

                cifra=cifra + i;

            }

            i++;

        }

        if (cifra==num) {

            esP=true;

        }

    }

    public boolean esPerfecto() {
        //Método que devuelve el estado del booleano
        return esP;

    }

    public void listaPerfectos(int num2) {
        //Método que lista los números perfectos comprendidos entre 1 y un número que es introducido por teclado

        this.num2=num2;

        int [] arrayNum=new int[num2];

        for (j=0;j<arrayNum.length;j++) {

            arrayNum[j]=j+1;

            int cifra2 = 0;

            int k=1;

            //Dentro del bucle realizamos la misma tarea que con el método anterior

            while (k<arrayNum[j]) {

                if (arrayNum[j]%k == 0) {

                    cifra2+=k;

                }

                k++;

            }

            if (cifra2==arrayNum[j]) {

                    System.out.println(arrayNum[j] + " es perfecto");

            }


        }



    }

    public String finDelPrograma() {

        return "El programa ha finalizado. ";

    }


    private int num;

    private int num2;

    private int i=1;

    private int j=1;

    private int cifra=0;

    private boolean esP=false;


}


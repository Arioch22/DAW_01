package bloque1;

import java.util.Scanner;

public class TrianguloDigitos {

    public static void main(String[] args) {

        int altura, numLinea, i, j, k, l;

        numLinea=0;

        i=0;
        j=0;
        k=0;
        l=0;


        Scanner myScan=new Scanner(System.in);

        System.out.println("Introduce el número de lineas");
        altura=myScan.nextInt();


        while(altura>9) {

            System.out.println("Elige un numero entero entre 1 y 9");

            System.out.println("Introduce el número de lineas");

            altura = myScan.nextInt();

        }

        myScan.close();

        System.out.println("El número de líneas es: " + altura);

        for(i = 1; i <= altura; i++) { //BUCLE DE LINEA SALTA DE LINEA TRAS EJECUTAR INSTRUCCIONES

            numLinea+=1;

            for (j = 1; j <= altura-i; j++) { //Bucle que imprime espacios al principio de cada línea.

                System.out.print(" ");

            }

            for(k=1;k<=numLinea;k++) { // Bucle que imprime un número creciente tras los espacios.

                System.out.print(k);

            }

            for(l=numLinea-1;l>=1;l--){ // Bucle decreciente que imprime la segunda mitad del triangulo.

                System.out.print(l);

            }

            System.out.println();

        }






    }

}

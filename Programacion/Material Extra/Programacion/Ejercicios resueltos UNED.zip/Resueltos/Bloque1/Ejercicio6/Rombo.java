package bloque1;

import java.util.Scanner;

public class Rombo {
    public static void main(String[] args) {

        int numFilas;

        int n, c, k, espacio=0;
        Scanner myScan=new Scanner(System.in);

        System.out.println("Introduce el lado del rombo");
        numFilas=myScan.nextInt();


        n=numFilas+1;

        espacio= n-1;

        for(k=1;k<=n;k++) {

            for(c=1;c<=espacio; c++) {

                System.out.printf(" ");

            }
            espacio--;

            for (c=1;c<=2*k-1;c++) {

                if(c%2==0) {

                    System.out.printf("*");

                }else {

                    System.out.printf(" ");

                }
            }
            System.out.println();

        }

        espacio=1;

        for(k=1;k<=n-1;k++) {

            for(c=1;c<=espacio; c++) {

                System.out.printf(" ");

            }
            espacio++;

            for (c = 1 ; c <= 2*(n-k)-1; c++){
                if (c%2 ==0) {
                    System.out.printf("*");
                } else {
                    System.out.printf(" ");
                }

            }
            System.out.println();

        }

    }

}

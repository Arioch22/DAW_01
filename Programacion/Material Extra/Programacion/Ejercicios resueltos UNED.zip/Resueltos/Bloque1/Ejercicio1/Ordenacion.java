/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bloque1;
import java.util.Scanner; // Importa la clase Scanner.
/**
 *
 * @author Pablo Rojas Sáinz
 *
 * Realizar un programa que lea 3 valores enteros y los ordene de menor a mayor en las mismas variables en
 * que se leen: el valor menor quedará en la primera variable y el mayor en la última.
 *
 */
public class Ordenacion { // Una única clase llamada Ejercicio1.

    public static void main(String[] args) { // Inicio del método main.

        int num1, num2, num3; //Declaración de las variables que almacenarán números enteros.

        Scanner myscan = new Scanner(System.in); // Declaración de la clase Scanner del paquete java.util .


        System.out.println("Introduce el primer número a continuación"); // Pide al usuario
        num1 = myscan.nextInt();                                         // que introduzca por teclado
        System.out.println("El primer número es: " + num1);              // el primer número, lo asigna y lo imprime.

        System.out.println("A continuación, introduce el segundo número"); // Pide al usuario
        num2 = myscan.nextInt();                                           // que introduzca por teclado
        System.out.println("El segundo número es: " + num2);                // el segundo número, lo asigna y lo imprime.

        System.out.println("A continuación introduce el tercer número");    // Pide al usuario
        num3 = myscan.nextInt();                                            // que introduzca por teclado
        System.out.println("El tercer número es: " + num3);                 // el tercer número, lo asigna y lo imprime.

        myscan.close(); // Cierra el Scanner.

        /*Utiliza las estructuras "if" y "else if" y los operadores condicionales para hacer las comprobaciones*/


        if (num1<num2 && num2<num3) {

            System.out.println("Los números ordenados de menor a mayor"
                    + " son: " + num1 + " " + num2 + " " + num3);

        } else if (num1<num2 && num2>num3 && num3>num1) {

            System.out.println("Los números ordenados de menor a mayor"
                    + " son: " + num1 + " " + num3 + " " + num2);

        } else if (num1>num2 && num2<num3 && num1<num3) {

            System.out.println("Los números ordenados de menor a mayor"
                    + " son: " + num2 + " " + num1 + " " + num3);

        } else if (num1<num2 && num2>num3 && num1>num3) {

            System.out.println("Los números ordenados de menor a mayor"
                    + " son: " + num3 + " " + num1 + " " + num2);

        } else if (num1>num2 && num2>num3) {

            System.out.println("Los números ordenados de menor a mayor"
                    + " son: " + num3 + " " + num2 + " " + num1);

        } else if(num1>num2 && num2<num3 && num1>num3) {

            System.out.println("Los números ordenados de menor a mayor"
                    + " son: " + num2 + " " + num3 + " " + num1);

        } else {

            System.out.println("Introduce tres números enteros de diferente valor, por favor");

        }





    }

}
        
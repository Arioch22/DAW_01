package bloque1;

import java.util.Scanner;

/**
 *
 * @author Pablo Rojas Sáinz
 *
 * Realizar un programa que a partir del capital C, el tanto por ciento de interés anual I y los años de amortización
 * A de un crédito, introducidos como datos, calcule la anualidad fija a pagar a lo largo de los A años.
 *
 * El programa también debe calcular para todos los años la parte de la anualidad dedicada al pago de intereses
 * y la parte dedicada a la amortización de la deuda.
 *
 */


public class Anualidad {

    public static void main(String[] args) {

        double capital, interes, anios, anualidad;

        /*A continuación se piden al usuario los datos*/

        Scanner myscan=new Scanner(System.in);

        System.out.println("¿Capital?");
        capital=myscan.nextInt();

        System.out.println("¿Interés?");
        interes=myscan.nextInt();

        System.out.println("¿Años?");
        anios=myscan.nextInt();

        /*Se hace el calculo correspondiente para hallar la anualidad*/

        anualidad=(capital*((Math.pow(1+(interes/100), anios)*
                (interes/100))/(Math.pow(1+(interes/100), anios)-1)));

        System.out.println("Anualidad: "+Math.round(anualidad));

        /*Y se imprimen los datos correspondientes a la parte de la anualidad
        * correspondiente a los intereses y la amortización*/

        System.out.println("Anno         Intereses        Amortización");

        for(int i=1;i<=(anios);i++) {

            int numInteres, amortizacion;

            amortizacion= (int) (anualidad-(capital*interes/100));

            numInteres=(int) anualidad-amortizacion;

            if(String.valueOf(numInteres).length()>=5) {

                System.out.printf("%d            %d           %d%n", i, numInteres, amortizacion);

            }else {

                System.out.printf("%d            %d         %d%n", i, numInteres, amortizacion);

            }
            capital-=amortizacion;

        }
    }
}


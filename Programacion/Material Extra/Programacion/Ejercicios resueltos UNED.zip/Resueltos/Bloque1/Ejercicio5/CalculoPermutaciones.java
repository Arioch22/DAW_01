package bloque1;

/**
 *
 * @author Pablo Rojas Sáinz
 *
 * Realizar un programa que escriba todas las permutaciones posibles que se pueden obtener a partir de las
 * 4 letras: A, B, C y D. Para ello, se recomienda implementar el algoritmo Heap.
 *
 */

public class CalculoPermutaciones {

    public static void main(String[] args) {

        AlgoritmoHeap miAlgoritmo=new AlgoritmoHeap();

        char miArray[] = {'A', 'B', 'C', 'D'};

        miAlgoritmo.algoritmoHeap(miArray, miArray.length, miArray.length);

    }
}


class AlgoritmoHeap {


    public void imprArray(char miArray[], int numeroTam) { //Metodo que imprime el array y salta a la siguiente linea

        for (int i = 0; i < numeroTam; i++) {

            System.out.print(miArray[i] + " ");

        }
        System.out.println();



    }

    public void algoritmoHeap(char miArray[],int tamanio, int numeroTam) {

        //Si la variable tamanio tiene el valor de 1 llama a imprimir array
        if (tamanio == 1) imprArray(miArray, numeroTam);

        for (int i = 0; i < tamanio; i++) {
            //Bucle que intercambia los valores del array una vez por valor almacenado

            algoritmoHeap(miArray, tamanio - 1, numeroTam);//El método se llama a si mismo dentro del bucle

            int temp; //Variable local para almacenar valores

            if (tamanio % 2 == 1) { //Si el valor es impar
                temp = miArray[0]; //la variable adquiere el valor del primer valor del array
                miArray[0] = miArray[tamanio - 1]; //Y se sustituye el valor por otro

            } else {
                temp = miArray[i];
                miArray[i] = miArray[tamanio - 1];
            }
            miArray[tamanio - 1] = (char) temp; //La variable temp se asigna a la celda cuyo valor movimos

        }

    }

    private int numeroTam; // Variable para almacenar el valor del tamaño del array y poder llamar desde un método
                                // a otro recibiendo el mismo valor

    private int tamanio; //Variable con el valor del tamaño del array para hacer las permutaciones

}



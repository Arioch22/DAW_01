CREATE DATABASE  IF NOT EXISTS `curso` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `curso`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: curso
-- ------------------------------------------------------
-- Server version	5.6.48-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articulo`
--

DROP TABLE IF EXISTS `articulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(4) DEFAULT NULL,
  `descripcion` varchar(60) DEFAULT NULL,
  `ctrolStock` int(11) DEFAULT NULL,
  `codSeccion` varchar(2) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `articulo_ind1` (`codigo`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulo`
--

LOCK TABLES `articulo` WRITE;
/*!40000 ALTER TABLE `articulo` DISABLE KEYS */;
INSERT INTO `articulo` VALUES (1,'0001','Tomate frito fruco',1,'01'),(2,'0002','Tomate Triturado 500gr',1,'01'),(3,'0003','Gaseosa la Casera 1,5 L',1,'02'),(4,'0004','Cocacola 2 L Zero Zero',1,'02'),(5,'0005','Arroz redondo La cigala',1,'03'),(6,'0006','Tallarines nro 5 - 500 gr',1,'03'),(7,'0092','Varios Seccion Refrescos',0,'02'),(8,'0093','Varios Seccion legumbres y pastas',0,'03'),(9,'0091','Varios Seccion conservas',0,'01'),(15,'0026','Champu de huevo',1,'04'),(29,'0024','Cocacola',1,'02'),(32,'5555','Limpiador de baños',1,'03'),(37,'0025','Gel de Baño',1,'04'),(39,'0045','Gel de Baño',1,'04');
/*!40000 ALTER TABLE `articulo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `datosentrega`
--

DROP TABLE IF EXISTS `datosentrega`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `datosentrega` (
  `idTicket` int(11) NOT NULL DEFAULT '0',
  `direccion` varchar(45) DEFAULT NULL,
  `poblacion` varchar(45) DEFAULT NULL,
  `fechaEntrega` date DEFAULT NULL,
  PRIMARY KEY (`idTicket`),
  KEY `pk1_Ticket_idx` (`idTicket`),
  CONSTRAINT `pk1_Ticket` FOREIGN KEY (`idTicket`) REFERENCES `ticket` (`id`) ON DELETE NO ACTION ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `datosentrega`
--

LOCK TABLES `datosentrega` WRITE;
/*!40000 ALTER TABLE `datosentrega` DISABLE KEYS */;
INSERT INTO `datosentrega` VALUES (21,'Avda La Marina -36, 1º B','Almendralejo-1','2022-05-09'),(22,'Avda La Marina -36, 1º B','Almendralejo-1','2022-05-09');
/*!40000 ALTER TABLE `datosentrega` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lineaticket`
--

DROP TABLE IF EXISTS `lineaticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lineaticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idTicket` int(11) DEFAULT NULL,
  `codArticulo` varchar(4) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pk1_Ticket_idx` (`idTicket`),
  CONSTRAINT `pk2_Ticket` FOREIGN KEY (`idTicket`) REFERENCES `ticket` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lineaticket`
--

LOCK TABLES `lineaticket` WRITE;
/*!40000 ALTER TABLE `lineaticket` DISABLE KEYS */;
INSERT INTO `lineaticket` VALUES (10,21,'0001',2,2.45),(11,21,'0005',7,6.22),(12,21,'0003',10,8),(13,22,'0002',2,2.45),(14,22,'0004',10,8),(15,22,'0003',7,6.22);
/*!40000 ALTER TABLE `lineaticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto`
--

DROP TABLE IF EXISTS `producto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `producto` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `BARCODE` varchar(24) NOT NULL,
  `NOMBRE` varchar(200) NOT NULL,
  `PRECIO` double NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto`
--

LOCK TABLES `producto` WRITE;
/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prueba1`
--

DROP TABLE IF EXISTS `prueba1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prueba1` (
  `codigo` varchar(2) DEFAULT NULL,
  `nombre` varchar(25) DEFAULT NULL,
  `edad` int(11) DEFAULT NULL,
  `altuara` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prueba1`
--

LOCK TABLES `prueba1` WRITE;
/*!40000 ALTER TABLE `prueba1` DISABLE KEYS */;
INSERT INTO `prueba1` VALUES ('01','nombre reg 1',25,NULL);
/*!40000 ALTER TABLE `prueba1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `ticketCerrado` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket`
--

LOCK TABLES `ticket` WRITE;
/*!40000 ALTER TABLE `ticket` DISABLE KEYS */;
INSERT INTO `ticket` VALUES (21,'2022-05-09',0),(22,'2022-05-09',0);
/*!40000 ALTER TABLE `ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'curso'
--

--
-- Dumping routines for database 'curso'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-11 18:44:23

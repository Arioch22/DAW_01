/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10.conex;
import java.sql.*;

/**
 * Ejemplo de realizar una conexion a la BD
 * @author profesor
 */
public class Conex {
      public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
        // TODO code application logic here
   //URL de conexión
//        String connectionURL = "jdbc:h2:./minipos.h2db;MODE=MySQL;AUTO_RECONNECT=TRUE";
//        String connectionURL = "jdbc:mysql://localhost:3306/curso?useOldAliasMetadataBehavior=true";

        String connectionURL = "jdbc:mysql://localhost:3306/curso"; // mysql 5.6
//         String connectionURL = "jdbc:mysql://localhost:3306/curso?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
         
        //Usuario para conectar a la base de datos (rellenar si es necesario).
        String usuario = "profesor";
        //Contraseña para conectar a la base de datos (rellenar si es necesario).
        String password = "123456";
        
        // Si queremos registrar el driver      
        String sDriver = "com.mysql.jdbc.Driver";  //mysql 5.6
//         String sDriver = "com.mysql.cj.jdbc.Driver";
//         Class.forName(sDriver).newInstance();    

        //Paso 1: conectamos con la base de datos
        try ( Connection con = DriverManager.getConnection(connectionURL, usuario, password)) {

            //Paso 2: crear y ejecutar una consulta
            try ( Statement consulta = con.createStatement()) {
//                if (consulta.execute("SELECT id,nombre,precio FROM producto")) {
                if (consulta.execute("SELECT * from articulo")) {
                    ResultSet resultados = consulta.getResultSet();
                    while (resultados.next()) {
                        long id = resultados.getLong("id");
                        String codigo = resultados.getString("codigo");
                        String nombre = resultados.getString("descripcion");
                        System.out.printf("%5d %-4s %-15s\n", id, codigo,nombre);
                    }
                }
            } catch (SQLException ex) {
                System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");
            }

        } catch (SQLException ex) {
            System.err.printf("No se pudo conectar a la base de datos " + ex);
        }        
    }
    
}

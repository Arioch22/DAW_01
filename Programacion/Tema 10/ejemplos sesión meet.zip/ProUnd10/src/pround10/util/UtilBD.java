/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10.util;

import java.sql.Connection;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * clase de utilidades para acceso a BD del proyecto
 * @author profesor
 */
public class UtilBD {

    private static String connectionURL = "jdbc:mysql://localhost:3306/curso?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
    private static String usuario = "profesor";
    private static String password = "123456";
            
    public static Connection getConexionBD() throws Exception {
        Connection conex = null;
        try {
//                String driver = "com.mysql.cj.jdbc.Driver";
                String driver = "com.mysql.jdbc.Driver";
//                try {
//                    Class.forName(driver).newInstance();
//
//                } catch (ClassNotFoundException e) {
//                    throw new Exception("No se encuentra el driver de la base de datos " + driver);
//                } catch (InstantiationException ex) {
//                    throw new Exception("No se ha podido iniciar el driver de la base de datos (" + driver);
//                } catch (IllegalAccessException ex) {
//                    throw new Exception("No se ha podido iniciar el driver de la base de datos " + driver);
//                }
//                String connectionURL = "jdbc:mysql://localhost:3306/curso?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";

                conex = DriverManager.getConnection(connectionURL, usuario, password);
        } catch (SQLException ex) {
            System.err.printf("Se ha producido un error al ejecutar la consulta SQL.");
        }

        return conex;
    }
  public static void cierraConexionBD(Connection con) {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(UtilBD.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
  
   public static ResultSet getResulSetJDBC(Connection conn, String query) throws SQLException, ClassNotFoundException {
        return getResulSetJDBC(conn, query, -1);
    }

    public static ResultSet getResulSetJDBC(Connection conn, String query, int maxrows) throws SQLException, ClassNotFoundException {
        Statement stmt;
        ResultSet rset = null;
        try {
            stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            rset = stmt.executeQuery(query);
        } catch (Exception e) {
            throw new SQLException("Error:" + e.getMessage());
        }
        return rset;
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pround10;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import pround10.util.UtilBD;

/**
 *
 * @author profesor
 */
public class ProUnd10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Connection con = null;
        try {
            // TODO code application logic here
            con = UtilBD.getConexionBD();

        } catch (Exception ex) {
            Logger.getLogger(ProUnd10.class.getName()).log(Level.SEVERE, null, ex);
        }
        try ( Statement consulta = con.createStatement()) {
//                if (consulta.execute("SELECT id,nombre,precio FROM producto")) {
            if (consulta.execute("SELECT * from articulo")) {
                ResultSet resultados = consulta.getResultSet();
                while (resultados.next()) {
                    long id = resultados.getLong("id");
                    String codigo = resultados.getString("codigo");
                    String nombre = resultados.getString("descripcion");
                    System.out.printf("%5d %-4s %-15s\n", id, codigo, nombre);
                }
            }
            UtilBD.cierraConexionBD(con);
        } catch (SQLException ex) {
            System.err.printf("Se ha producido un error al ejecutar la consulta SQL.\n");
        }
        
    }

}

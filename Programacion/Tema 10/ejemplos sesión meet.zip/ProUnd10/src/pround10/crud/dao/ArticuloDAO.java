/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10.crud.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import pround10.clases.Articulo;
import pround10.util.UtilBD;

/**
 * Controlador o gestor de las operaciones /accesos que se hacen con la tabla
 * articulo en nuestra bd
 *
 * @author profesor
 */
public class ArticuloDAO {

    public void alta(Articulo reg, Connection con) throws Exception {
        String query = "INSERT INTO articulo (codigo, descripcion, ctrolStock, codSeccion)"
                + " VALUES (?,?,?,?)";
        if (con != null) {
            // No nos interesa saber el id del registro generado
//             try ( PreparedStatement consulta = con.prepareStatement(query)) {

            // Si queremos obtener los id de los registros insertados
            try (PreparedStatement consulta = con.prepareStatement(query,
                    Statement.RETURN_GENERATED_KEYS)) {

                consulta.setString(1, reg.getCodigo());
                consulta.setString(2, reg.getDescripcion());
                consulta.setInt(3, reg.getCtrolStock());
                consulta.setString(4, reg.getCodSeccion());

                int registrosAfectados = consulta.executeUpdate();
                if (registrosAfectados > 0) {
                    System.out.println("Producto insertado correctamente.");
                    // Si queremos obtener los id de los registros insertados
                    long id = -1;
                    ResultSet m = consulta.getGeneratedKeys();
                    if (m.next()) {
                        id = m.getLong(1);
                        System.out.printf("Producto insertado con ID=%d\n", id);
                    }

                } else {
                    System.out.println("El producto no ha podido ser insertado.");
                }
            } catch (SQLException ex) {
                System.err.printf("Se ha producido un error al ejecutar la consulta SQL." + ex.getMessage() + "\n");
                throw new Exception(ex.getMessage());
            }
        }
    }
    /**
     * busca un articulo por codigo
     * @param con: conexion
     * @param codigo : codigo del articulo a buscar
     * @return articulo encontrado o null si no existe
     */
    public Articulo buscaArticuloPorCodigo(Connection con, String codigo) {
        Articulo encontrado = null;
        String query = "select * from articulo "
                + " where codigo= ?";
        try (PreparedStatement consulta = con.prepareStatement(query)) {
            consulta.setString(1, codigo);
            if (consulta.execute()) {
                ResultSet resultados = consulta.getResultSet();
                int contador = 1;
                while (resultados.next() && contador == 1) {
                    contador++;
                    encontrado = new Articulo();
                    encontrado.setId(resultados.getInt("id"));
                    encontrado.setCodigo(resultados.getString("codigo"));
                    encontrado.setDescripcion(resultados.getString("descripcion"));
                    encontrado.setCtrolStock(resultados.getInt("ctrolStock"));
                    encontrado.setCodSeccion(resultados.getString("codSeccion"));
                }
            }
        } catch (SQLException ex) {
            System.err.printf("Se ha producido un error al ejecutar la consulta SQL." + ex.getMessage());
        }
        return encontrado;
    }
    /**
     * busca la lista de todos los articulos de la tabla
     * Ejemplo con preparedstatement
     * @param con : conexion 
     * @return lista( puede estar vacia, pero no será null)
     */
    public List<Articulo> buscaListaTodos(Connection con) {
        List<Articulo> lista = new ArrayList<>();
        String query = "select * from articulo order by codigo ";
        try (PreparedStatement consulta = con.prepareStatement(query)) {
            if (consulta.execute()) {
                ResultSet resultados = consulta.getResultSet();
                Articulo arti = null;
                while (resultados.next()) {
                    arti = new Articulo();
                    arti.setId(resultados.getInt("id"));
                    arti.setCodigo(resultados.getString("codigo"));
                    arti.setDescripcion(resultados.getString("descripcion"));
                    arti.setCtrolStock(resultados.getInt("ctrolStock"));
                    arti.setCodSeccion(resultados.getString("codSeccion"));
                    lista.add(arti);
                }
            }
        } catch (SQLException ex) {
            System.err.printf("Se ha producido un error al ejecutar la consulta SQL." + ex.getMessage());
        }
        return lista;
    }

    /**
     * Realiza una búsqueda en la BD usando un metodo static de una librería de
     * utilidades que hemos creado para manejo de los accesos a la BD
     *
     * @param con conexion
     * @return lista de artículos encontrados o lista vacia
     */
    public List<Articulo> buscaListaTodosUsoUtilBD(Connection con) {
        List<Articulo> lista = new ArrayList<>();
        String query = "select * from articulo order by codigo ";
        try {
            ResultSet resultados = UtilBD.getResulSetJDBC(con, query);
            Articulo arti = null;
            while (resultados.next()) {
                arti = new Articulo();
                arti.setId(resultados.getInt("id"));
                arti.setCodigo(resultados.getString("codigo"));
                arti.setDescripcion(resultados.getString("descripcion"));
                arti.setCtrolStock(resultados.getInt("ctrolStock"));
                arti.setCodSeccion(resultados.getString("codSeccion"));
                lista.add(arti);
            }

        } catch (SQLException | ClassNotFoundException ex) {
            System.err.printf("Se ha producido un error al ejecutar la consulta SQL." + ex.getMessage());
        }
        return lista;
    }
    /**
     * actualizar el campo seccion del articulo cuyo id se ha indicado.
     * @param con : conexion
     * @param id : id del articulo a modificar
     * @param seccion : valor de seccion a establecer
     */
    public void actualizarSeccion(Connection con, int id, String seccion) {
        String query = "UPDATE articulo SET codSeccion=? WHERE id=?;";
        if (con != null) {

            try (PreparedStatement consulta = con.prepareStatement(query)) {

                consulta.setString(1, seccion);
                consulta.setLong(2, id);

                int registrosAfectados = consulta.executeUpdate();
                if (registrosAfectados > 0) {
                    System.out.println("La seccion se ha modificado." + seccion);
                } else {
                    System.out.println("La seccion no se ha modificado, articulo no encontrado.");
                }

            } catch (SQLException ex) {
                System.err.printf("Se ha producio un error al ejecutar la consulta SQL.");
            }
        }
    }

    /**
     * borrar un registro por codigo
     *
     * @param con
     * @param codigo
     */
    public void borrarArticulo(Connection con, String codigo) throws Exception {
        String queryDelete = "DELETE FROM articulo WHERE codigo=?";
        if (con != null) {
            try (PreparedStatement consultaDelete = con.prepareStatement(queryDelete)) {

                consultaDelete.setString(1, codigo);
                int registrosAfectados = consultaDelete.executeUpdate();
                if (registrosAfectados > 0) {
                    System.out.println("El articulo ha sido eliminado correctamente");
                } else {
                    System.out.println("El articulo no ha sido eliminado, porque no existe.");
                }
            } catch (SQLException ex) {
                throw new Exception(ex.getMessage());
//                System.err.printf("Se ha producio un error al ejecutar la consulta SQL.");
            }
        }
    }
    /**
     * ejemplo buscar todos los articulos. Heco con statement
     * @param conn
     * @return 
     */
    public List<Articulo> buscaArticulos(Connection conn) {
        Statement stmt;
        ResultSet resultados = null;
        List<Articulo> lista = new ArrayList<>();
        try {
            stmt = conn.createStatement(); //ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String query = "select * from articulo";
            Articulo arti = null;
            resultados = stmt.executeQuery(query);
            while (resultados.next()) {
                arti = new Articulo();
                arti.setId(resultados.getInt("id"));
                arti.setCodigo(resultados.getString("codigo"));
                arti.setDescripcion(resultados.getString("descripcion"));
                arti.setCtrolStock(resultados.getInt("ctrolStock"));
                arti.setCodSeccion(resultados.getString("codSeccion"));
                lista.add(arti);
            }
        } catch (Exception e) {
            System.out.println("Erro:" + e.getMessage());
        }
        return lista;
    }

}

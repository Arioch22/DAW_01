/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10.crud.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pround10.clases.Articulo;
import pround10.util.UtilBD;

/**
 * Clase de demostracion de accesos a una BD mediante JDBC En el metodo main
 * están todos los ejemplos. Para probar cada uno hay que descomentariarlo
 *
 * @author profesor
 */
public class ejemploCRUD {

    public static void main(String[] args) {
        // alta
        ejemploAlta();

        // ejemblo busca registro
        // ejemploRecuperarRegistro();
        // ejemblo busca TODOS
//        ejemploRecuperarListaTodos();
        // ejemplo modificar
//        ejemploModificaRegistro();
//        ejemploRecuperarListaTodos();
        // ejemplo borrar
//        ejemploBorrarRegistro();
        // otro ejemplo con Statement
//        buscaArticulos();
    }

    /**
     * alta de registros en la tabla Podemos probar el alta de un solo articulo
     * o la de varios, metidas en una transaccion
     */
    private static void ejemploAlta() {

        Articulo[] arrArticulos = {
            //            new Articulo("0024", "Cocacola", 1, "02"), //            new Articulo("0026", "Champu de huevo", 1, "04") 
            new Articulo("0045", "Gel de Baño", 1, "04") //            new Articulo("0026", "Champu de huevo", 1, "04") 
            //            ,new Articulo("0027", "Cerveza Cruzcampo", 1, "05"),
            //            ,new Articulo("0028", "Champu ligero", 1, "04")
            ,};
        Connection con = null;
        try {
            // obtenemos una conexion a la BD
            con = UtilBD.getConexionBD();
        } catch (Exception ex) {
            System.out.println("Error obteniendo conexion a BD " + ex.getMessage());
        }
        try {
            con.setAutoCommit(false); // establecemos transaccion no monoOperacion
            ArticuloDAO artiDAO = new ArticuloDAO();
            for (int i = 0; i < arrArticulos.length; i++) {
                artiDAO.alta(arrArticulos[i], con);
            }
            con.commit();  // confirmamos fin de transaccion correcto
            con.setAutoCommit(true); // volvemos a establecer autcommit
        } catch (Exception e) {
            if (con != null) try {
                con.rollback();  // devuelve lo hecho y queda sin hacer
                System.err.println("Rollback. Error ejecutando transaccion:" + e.getMessage());
            } catch (SQLException ex) {
                Logger.getLogger(ejemploCRUD.class.getName()).log(Level.SEVERE, null, ex);

            }
        } finally {
            UtilBD.cierraConexionBD(con);
        }
    }

    /**
     * obtener un registro buscando por codigo
     */
    private static void ejemploRecuperarRegistro() {
        String codigoABuscar = "0065";
        Connection con = null;
        try {
            con = UtilBD.getConexionBD();
            Articulo arti = new ArticuloDAO().buscaArticuloPorCodigo(con, codigoABuscar);
            if (arti != null) {
                System.out.println("Encontrado articulo:" + arti.toString());
            } else {
                System.out.println("Articulo no encontrado codigo:" + codigoABuscar);
            }

        } catch (Exception ex) {
            Logger.getLogger(ejemploCRUD.class
                    .getName()).log(Level.SEVERE, null, ex);
        } finally {
            UtilBD.cierraConexionBD(con);
        }
    }

    /**
     * obtener la lista de todos los articulos de la tabla
     */
    private static void ejemploRecuperarListaTodos() {
        Connection con = null;
        try {
            con = UtilBD.getConexionBD();
            List<Articulo> lista = new ArticuloDAO().buscaListaTodos(con);
            if (lista.isEmpty()) {
                System.out.println("No hay registros en la tabla articulo");
            } else {
                System.out.println("ARTICULOS ENCONTRADOS");
                System.out.println("--------------------------------------------");
                for (Articulo arti : lista) {
                    System.out.println(arti.toString());
                }
            }

        } catch (Exception ex) {
            Logger.getLogger(ejemploCRUD.class
                    .getName()).log(Level.SEVERE, null, ex);
        } finally {
            UtilBD.cierraConexionBD(con);
        }
    }

    /**
     * Modificar un registgro buscando por id
     */
    private static void ejemploModificaRegistro() {
        Connection con = null;
        try {
            con = UtilBD.getConexionBD();
            int id = 5;
            String newSeccion = "99";
            new ArticuloDAO().actualizarSeccion(con, id, newSeccion);
        } catch (Exception ex) {
            Logger.getLogger(ejemploCRUD.class
                    .getName()).log(Level.SEVERE, null, ex);
        } finally {
            UtilBD.cierraConexionBD(con);
        }
    }

    /**
     * borrar registro por codigo
     */
    private static void ejemploBorrarRegistro() {
        Connection con = null;
        try {
            con = UtilBD.getConexionBD();
            String codigo = "0025";
            new ArticuloDAO().borrarArticulo(con, codigo);

        } catch (Exception ex) {
            Logger.getLogger(ejemploCRUD.class
                    .getName()).log(Level.SEVERE, null, ex);
        } finally {
            UtilBD.cierraConexionBD(con);
        }
    }

    private static void buscaArticulos() {
        Connection con = null;
        try {
            con = UtilBD.getConexionBD();

            List<Articulo> lista = new ArticuloDAO().buscaArticulos(con);
            UtilBD.cierraConexionBD(con);
            for (Articulo art : lista) {
                System.out.println("nombre:" + art.getDescripcion());
            }
        } catch (Exception ex) {
            Logger.getLogger(ejemploCRUD.class
                    .getName()).log(Level.SEVERE, null, ex);
        } finally {
            UtilBD.cierraConexionBD(con);
        }
    }
}

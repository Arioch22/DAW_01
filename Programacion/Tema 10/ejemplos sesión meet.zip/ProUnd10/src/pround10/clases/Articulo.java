/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10.clases;

/**
 * Clase que modela nuuestros objetos articulo
 * @author profesor
 */
public class Articulo {

    private int id;
    private String codigo;
    private String descripcion;
    private int ctrolStock;
    private String codSeccion;

    public Articulo(String codigo, String descripcion, int ctrolStock, String codSeccion) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.ctrolStock = ctrolStock;
        this.codSeccion = codSeccion;
    }

    public Articulo() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getCtrolStock() {
        return ctrolStock;
    }

    public void setCtrolStock(int ctrolStock) {
        this.ctrolStock = ctrolStock;
    }

    public String getCodSeccion() {
        return codSeccion;
    }

    public void setCodSeccion(String codSeccion) {
        this.codSeccion = codSeccion;
    }

    @Override
    public String toString() {
        String salida = String.format("%5d %-5s %-45s %d %s\n",
                getId(), getCodigo(), getDescripcion(), getCtrolStock(), getCodSeccion());
        return salida;
    }
}

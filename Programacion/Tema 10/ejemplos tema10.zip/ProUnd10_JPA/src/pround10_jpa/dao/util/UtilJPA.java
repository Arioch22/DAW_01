/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10_jpa.dao.util;

import java.util.Properties;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author profesor
 */
public class UtilJPA {

    private static EntityManagerFactory emf;
    private static String persistenceUnit = "EjemplosJPA";

    /**
     * obtener un EntityManagerFactory
     *
     * @return
     */
    public static EntityManagerFactory getEntitymanagerFactory() {
        if (emf == null) {
            // solo instanciamos emf la primera vez. 
            
            try {
                // estos datos se pueden tomar de un archivo externo
                //donde esté el password encriptado, por ejemplo
                String url = "jdbc:mysql://localhost:3306/curso?serverTimezone=UTC";
                String driverName = "com.mysql.jdbc.Driver";
//                String driverName = "com.mysql.cj.jdbc.Driver";
                String userName = "profesor";
                String pass = "123456";

                Properties props = new Properties(); // properties para los datos de la persistencia

                // mostramos los datos de acceso que vamos a usar
                System.out.println("BD_URL     :" + url);
                System.out.println("BD_Driver  :" + driverName);
                System.out.println("BD_Usuario :" + userName);
                System.out.println("BD_password:" + pass); // esto no seria bueno mostrarlo en producción

                // asignamos las propiedades necesarias al objeto properties
                props.setProperty("javax.persistence.jdbc.url", url);
                props.setProperty("javax.persistence.jdbc.driver", driverName);
                props.setProperty("javax.persistence.jdbc.user", userName);
                props.setProperty("javax.persistence.jdbc.password", pass);
                
                // cargamos en la unidad de persistencia las propiedades necesarias
                emf = Persistence.createEntityManagerFactory(persistenceUnit, props);
                
            } catch (Throwable t) {
                System.out.println("ERROR al crear la conexión a la base de datos");
                throw new ExceptionInInitializerError();
            }
        }
        return emf;
    }
}

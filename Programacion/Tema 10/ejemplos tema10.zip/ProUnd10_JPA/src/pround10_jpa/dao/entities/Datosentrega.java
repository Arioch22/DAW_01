/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10_jpa.dao.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author igo
 */
@Entity
@Table(name = "datosentrega")
@NamedQueries({
    @NamedQuery(name = "Datosentrega.findAll", query = "SELECT d FROM Datosentrega d"),
    @NamedQuery(name = "Datosentrega.findByIdTicket", query = "SELECT d FROM Datosentrega d WHERE d.idTicket = :idTicket"),
    @NamedQuery(name = "Datosentrega.findByDireccion", query = "SELECT d FROM Datosentrega d WHERE d.direccion = :direccion"),
    @NamedQuery(name = "Datosentrega.findByPoblacion", query = "SELECT d FROM Datosentrega d WHERE d.poblacion = :poblacion"),
    @NamedQuery(name = "Datosentrega.findByFechaEntrega", query = "SELECT d FROM Datosentrega d WHERE d.fechaEntrega = :fechaEntrega")})
public class Datosentrega implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "idTicket")
    private Integer idTicket;
    @Column(name = "direccion")
    private String direccion;
    @Column(name = "poblacion")
    private String poblacion;
    @Column(name = "fechaEntrega")
    @Temporal(TemporalType.DATE)
    private Date fechaEntrega;
    @JoinColumn(name = "idTicket", referencedColumnName = "id", insertable = false, updatable = false)
    @OneToOne(optional = false)
    private Ticket ticket;

    public Datosentrega() {
    }

    public Datosentrega(Integer idTicket) {
        this.idTicket = idTicket;
    }

    public Integer getIdTicket() {
        return idTicket;
    }

    public void setIdTicket(Integer idTicket) {
        this.idTicket = idTicket;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getPoblacion() {
        return poblacion;
    }

    public void setPoblacion(String poblacion) {
        this.poblacion = poblacion;
    }

    public Date getFechaEntrega() {
        return fechaEntrega;
    }

    public void setFechaEntrega(Date fechaEntrega) {
        this.fechaEntrega = fechaEntrega;
    }

    public Ticket getTicket() {
        return ticket;
    }

    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idTicket != null ? idTicket.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Datosentrega)) {
            return false;
        }
        Datosentrega other = (Datosentrega) object;
        if ((this.idTicket == null && other.idTicket != null) || (this.idTicket != null && !this.idTicket.equals(other.idTicket))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "pround10_jpa.dao.entities.Datosentrega[ idTicket=" + idTicket + " ]";
    }
    
}

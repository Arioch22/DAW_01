/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10_jpa.dao.jpaControllers;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import pround10_jpa.dao.entities.Lineaticket;
import pround10_jpa.dao.entities.Ticket;
import pround10_jpa.dao.jpaControllers.exceptions.NonexistentEntityException;

/**
 *
 * @author igo
 */
public class LineaticketJpaController implements Serializable {

    public LineaticketJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Lineaticket lineaticket) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Ticket idTicket = lineaticket.getIdTicket();
            if (idTicket != null) {
                idTicket = em.getReference(idTicket.getClass(), idTicket.getId());
                lineaticket.setIdTicket(idTicket);
            }
            em.persist(lineaticket);
            if (idTicket != null) {
                idTicket.getLineaticketCollection().add(lineaticket);
                idTicket = em.merge(idTicket);
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Lineaticket lineaticket) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Lineaticket persistentLineaticket = em.find(Lineaticket.class, lineaticket.getId());
            Ticket idTicketOld = persistentLineaticket.getIdTicket();
            Ticket idTicketNew = lineaticket.getIdTicket();
            if (idTicketNew != null) {
                idTicketNew = em.getReference(idTicketNew.getClass(), idTicketNew.getId());
                lineaticket.setIdTicket(idTicketNew);
            }
            lineaticket = em.merge(lineaticket);
            if (idTicketOld != null && !idTicketOld.equals(idTicketNew)) {
                idTicketOld.getLineaticketCollection().remove(lineaticket);
                idTicketOld = em.merge(idTicketOld);
            }
            if (idTicketNew != null && !idTicketNew.equals(idTicketOld)) {
                idTicketNew.getLineaticketCollection().add(lineaticket);
                idTicketNew = em.merge(idTicketNew);
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = lineaticket.getId();
                if (findLineaticket(id) == null) {
                    throw new NonexistentEntityException("The lineaticket with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Lineaticket lineaticket;
            try {
                lineaticket = em.getReference(Lineaticket.class, id);
                lineaticket.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The lineaticket with id " + id + " no longer exists.", enfe);
            }
            Ticket idTicket = lineaticket.getIdTicket();
            if (idTicket != null) {
                idTicket.getLineaticketCollection().remove(lineaticket);
                idTicket = em.merge(idTicket);
            }
            em.remove(lineaticket);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Lineaticket> findLineaticketEntities() {
        return findLineaticketEntities(true, -1, -1);
    }

    public List<Lineaticket> findLineaticketEntities(int maxResults, int firstResult) {
        return findLineaticketEntities(false, maxResults, firstResult);
    }

    private List<Lineaticket> findLineaticketEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Lineaticket.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Lineaticket findLineaticket(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Lineaticket.class, id);
        } finally {
            em.close();
        }
    }

    public int getLineaticketCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Lineaticket> rt = cq.from(Lineaticket.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

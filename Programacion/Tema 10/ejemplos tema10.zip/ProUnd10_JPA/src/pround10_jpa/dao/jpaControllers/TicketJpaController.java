/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10_jpa.dao.jpaControllers;

import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import pround10_jpa.dao.entities.Datosentrega;
import pround10_jpa.dao.entities.Lineaticket;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import pround10_jpa.dao.entities.Ticket;
import pround10_jpa.dao.jpaControllers.exceptions.IllegalOrphanException;
import pround10_jpa.dao.jpaControllers.exceptions.NonexistentEntityException;

/**
 *
 * @author igo
 */
public class TicketJpaController implements Serializable {

    public TicketJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Ticket ticket) {
        if (ticket.getLineaticketCollection() == null) {
            ticket.setLineaticketCollection(new ArrayList<Lineaticket>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Datosentrega datosentrega = ticket.getDatosentrega();
            if (datosentrega != null) {
                datosentrega = em.getReference(datosentrega.getClass(), datosentrega.getIdTicket());
                ticket.setDatosentrega(datosentrega);
            }
            Collection<Lineaticket> attachedLineaticketCollection = new ArrayList<Lineaticket>();
            for (Lineaticket lineaticketCollectionLineaticketToAttach : ticket.getLineaticketCollection()) {
                lineaticketCollectionLineaticketToAttach = em.getReference(lineaticketCollectionLineaticketToAttach.getClass(), lineaticketCollectionLineaticketToAttach.getId());
                attachedLineaticketCollection.add(lineaticketCollectionLineaticketToAttach);
            }
            ticket.setLineaticketCollection(attachedLineaticketCollection);
            em.persist(ticket);
            if (datosentrega != null) {
                Ticket oldTicketOfDatosentrega = datosentrega.getTicket();
                if (oldTicketOfDatosentrega != null) {
                    oldTicketOfDatosentrega.setDatosentrega(null);
                    oldTicketOfDatosentrega = em.merge(oldTicketOfDatosentrega);
                }
                datosentrega.setTicket(ticket);
                datosentrega = em.merge(datosentrega);
            }
            for (Lineaticket lineaticketCollectionLineaticket : ticket.getLineaticketCollection()) {
                Ticket oldIdTicketOfLineaticketCollectionLineaticket = lineaticketCollectionLineaticket.getIdTicket();
                lineaticketCollectionLineaticket.setIdTicket(ticket);
                lineaticketCollectionLineaticket = em.merge(lineaticketCollectionLineaticket);
                if (oldIdTicketOfLineaticketCollectionLineaticket != null) {
                    oldIdTicketOfLineaticketCollectionLineaticket.getLineaticketCollection().remove(lineaticketCollectionLineaticket);
                    oldIdTicketOfLineaticketCollectionLineaticket = em.merge(oldIdTicketOfLineaticketCollectionLineaticket);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Ticket ticket) throws IllegalOrphanException, NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Ticket persistentTicket = em.find(Ticket.class, ticket.getId());
            Datosentrega datosentregaOld = persistentTicket.getDatosentrega();
            Datosentrega datosentregaNew = ticket.getDatosentrega();
            Collection<Lineaticket> lineaticketCollectionOld = persistentTicket.getLineaticketCollection();
            Collection<Lineaticket> lineaticketCollectionNew = ticket.getLineaticketCollection();
            List<String> illegalOrphanMessages = null;
            if (datosentregaOld != null && !datosentregaOld.equals(datosentregaNew)) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("You must retain Datosentrega " + datosentregaOld + " since its ticket field is not nullable.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            if (datosentregaNew != null) {
                datosentregaNew = em.getReference(datosentregaNew.getClass(), datosentregaNew.getIdTicket());
                ticket.setDatosentrega(datosentregaNew);
            }
            Collection<Lineaticket> attachedLineaticketCollectionNew = new ArrayList<Lineaticket>();
            for (Lineaticket lineaticketCollectionNewLineaticketToAttach : lineaticketCollectionNew) {
                lineaticketCollectionNewLineaticketToAttach = em.getReference(lineaticketCollectionNewLineaticketToAttach.getClass(), lineaticketCollectionNewLineaticketToAttach.getId());
                attachedLineaticketCollectionNew.add(lineaticketCollectionNewLineaticketToAttach);
            }
            lineaticketCollectionNew = attachedLineaticketCollectionNew;
            ticket.setLineaticketCollection(lineaticketCollectionNew);
            ticket = em.merge(ticket);
            if (datosentregaNew != null && !datosentregaNew.equals(datosentregaOld)) {
                Ticket oldTicketOfDatosentrega = datosentregaNew.getTicket();
                if (oldTicketOfDatosentrega != null) {
                    oldTicketOfDatosentrega.setDatosentrega(null);
                    oldTicketOfDatosentrega = em.merge(oldTicketOfDatosentrega);
                }
                datosentregaNew.setTicket(ticket);
                datosentregaNew = em.merge(datosentregaNew);
            }
            for (Lineaticket lineaticketCollectionOldLineaticket : lineaticketCollectionOld) {
                if (!lineaticketCollectionNew.contains(lineaticketCollectionOldLineaticket)) {
                    lineaticketCollectionOldLineaticket.setIdTicket(null);
                    lineaticketCollectionOldLineaticket = em.merge(lineaticketCollectionOldLineaticket);
                }
            }
            for (Lineaticket lineaticketCollectionNewLineaticket : lineaticketCollectionNew) {
                if (!lineaticketCollectionOld.contains(lineaticketCollectionNewLineaticket)) {
                    Ticket oldIdTicketOfLineaticketCollectionNewLineaticket = lineaticketCollectionNewLineaticket.getIdTicket();
                    lineaticketCollectionNewLineaticket.setIdTicket(ticket);
                    lineaticketCollectionNewLineaticket = em.merge(lineaticketCollectionNewLineaticket);
                    if (oldIdTicketOfLineaticketCollectionNewLineaticket != null && !oldIdTicketOfLineaticketCollectionNewLineaticket.equals(ticket)) {
                        oldIdTicketOfLineaticketCollectionNewLineaticket.getLineaticketCollection().remove(lineaticketCollectionNewLineaticket);
                        oldIdTicketOfLineaticketCollectionNewLineaticket = em.merge(oldIdTicketOfLineaticketCollectionNewLineaticket);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = ticket.getId();
                if (findTicket(id) == null) {
                    throw new NonexistentEntityException("The ticket with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws IllegalOrphanException, NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Ticket ticket;
            try {
                ticket = em.getReference(Ticket.class, id);
                ticket.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The ticket with id " + id + " no longer exists.", enfe);
            }
            List<String> illegalOrphanMessages = null;
            Datosentrega datosentregaOrphanCheck = ticket.getDatosentrega();
            if (datosentregaOrphanCheck != null) {
                if (illegalOrphanMessages == null) {
                    illegalOrphanMessages = new ArrayList<String>();
                }
                illegalOrphanMessages.add("This Ticket (" + ticket + ") cannot be destroyed since the Datosentrega " + datosentregaOrphanCheck + " in its datosentrega field has a non-nullable ticket field.");
            }
            if (illegalOrphanMessages != null) {
                throw new IllegalOrphanException(illegalOrphanMessages);
            }
            Collection<Lineaticket> lineaticketCollection = ticket.getLineaticketCollection();
            for (Lineaticket lineaticketCollectionLineaticket : lineaticketCollection) {
                lineaticketCollectionLineaticket.setIdTicket(null);
                lineaticketCollectionLineaticket = em.merge(lineaticketCollectionLineaticket);
            }
            em.remove(ticket);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Ticket> findTicketEntities() {
        return findTicketEntities(true, -1, -1);
    }

    public List<Ticket> findTicketEntities(int maxResults, int firstResult) {
        return findTicketEntities(false, maxResults, firstResult);
    }

    private List<Ticket> findTicketEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Ticket.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Ticket findTicket(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Ticket.class, id);
        } finally {
            em.close();
        }
    }

    public int getTicketCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Ticket> rt = cq.from(Ticket.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}

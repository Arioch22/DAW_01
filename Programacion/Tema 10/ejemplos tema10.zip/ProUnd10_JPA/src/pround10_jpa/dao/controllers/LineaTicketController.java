/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10_jpa.dao.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import pround10_jpa.dao.entities.Lineaticket;
import pround10_jpa.dao.entities.Ticket;
import pround10_jpa.dao.jpaControllers.LineaticketJpaController;
import pround10_jpa.dao.util.UtilJPA;

/**
 *
 * @author profesor
 */
public class LineaTicketController extends LineaticketJpaController {

    public LineaTicketController() {
        super(UtilJPA.getEntitymanagerFactory());
    }

    /**
     * obtener las lineas de un ticket
     *
     * @param idTicket
     * @return
     */
    public List<Lineaticket> obtenerListaLineasTicket(int idTicket) {
        EntityManager em = getEntityManager();
        List<Lineaticket> lista = new ArrayList<>();
        System.out.println("Buscamos  las lineas del ticket id:" + idTicket);
        try {
            Query query;
            query = em.createQuery("select t "
                    + "from " + Lineaticket.class.getName() + " t "
                    + " where t.idTicket.id = :valor ");
            query.setParameter("valor", idTicket);
            lista = query.getResultList();
        } catch (Exception e) {
            System.err.println("error en la búsqueda:" + e.getMessage());
        }

        return lista;
    }
}

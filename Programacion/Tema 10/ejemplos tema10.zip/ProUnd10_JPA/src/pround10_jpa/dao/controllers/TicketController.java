/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10_jpa.dao.controllers;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import pround10_jpa.dao.entities.Datosentrega;
import pround10_jpa.dao.entities.Lineaticket;
import pround10_jpa.dao.entities.Ticket;
import pround10_jpa.dao.jpaControllers.TicketJpaController;
import pround10_jpa.dao.util.UtilJPA;

/**
 *
 * @author igo
 */
public class TicketController extends TicketJpaController {

    public TicketController() {
        super(UtilJPA.getEntitymanagerFactory());
    }

    public void creaTicket(Ticket tck, Datosentrega entrega, List<Lineaticket> listaLineas) throws Exception {
        // Creamos un entity manager
        EntityManager em;
        try {
            em = getEntityManager();
        } catch (Exception e) {
            throw new Exception("Error obteniendo acceso a la conexion a la BD");
        }
        try {

            // abrimos transaccion
            em.getTransaction().begin();
            // alta ticket

            em.persist(tck);
            em.flush();

            // Cogemos el id asignado y se lo ponemos a la entrega 
            entrega.setIdTicket(tck.getId());
            em.persist(entrega); // persistimos entrega

            // añadimos las lineas del ticket al ticket
            tck.setLineaticketCollection(listaLineas);
            em.merge(tck);
            em.getTransaction().commit();

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.out.println("Error " + e.getMessage());

        }
        // 

    }

    public Ticket buscaTicketPorId(int id) {
        EntityManager em = getEntityManager();
        Ticket ticket = null;
        System.out.println("Buscamos  el ticket id:" + id);
        try {
            Query query;
//            query = em.createQuery("select t from Ticket t where t.id = :codigo");
            query = em.createQuery("select t from " + Ticket.class.getName() + " t "
                    + " where t.id = :codigo ");
            query.setParameter("codigo", id);
            ticket = (Ticket) query.getSingleResult();
        } catch (Exception e) {
            System.err.println("error en la búsqueda:" + e.getMessage());
        }

        return ticket;
    }
}

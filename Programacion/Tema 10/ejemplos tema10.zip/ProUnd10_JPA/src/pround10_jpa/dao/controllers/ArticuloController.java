/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10_jpa.dao.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import pround10_jpa.dao.entities.Articulo;
import pround10_jpa.dao.jpaControllers.ArticuloJpaController;
import pround10_jpa.dao.util.UtilJPA;

/**
 * Controller para Articulo. Apoyados en ArticuloJpaController
 *
 * @author profesor
 */
public class ArticuloController extends ArticuloJpaController {

    public ArticuloController() {
        super(UtilJPA.getEntitymanagerFactory());
    }

    public boolean existeCodigo(String codigo) {
        List<Articulo> lista = new ArrayList();
        EntityManager em = getEntityManager();
        System.out.println("Buscamos si existe el articulo " + codigo);
        try {
            Query query;
            query = em.createQuery("select t from " + Articulo.class.getSimpleName() + " t "
                    + " where t.codigo = :codigo ");
            query.setParameter("codigo", codigo);
            lista = query.getResultList();
            System.out.println("encontrados:" + lista.size());
        } catch (Exception e) {
            System.err.println("error en la búsqueda:" + e.getMessage());
        } finally {
            em.close();
        }
        return (lista.size() > 0);
    }

    /**
     * buscar articulo por codigo
     *
     * @param codigo
     * @return objeto articulo encontrado o null si no es encontrado
     */
    public Articulo buscaArticuloPorCodigo(String codigo) {
        EntityManager em = getEntityManager();
        Articulo arti = null;
        System.out.println("Buscamos  el articulo " + codigo);
        try {
            Query query;
            query = em.createQuery("select t from " + Articulo.class.getName() + " t "
                    + " where t.codigo = :codigo ");
            query.setParameter("codigo", codigo);
            arti = (Articulo) query.getSingleResult();
        } catch (Exception e) {
            System.err.println("error en la búsqueda:" + e.getMessage());
        }

        return arti;
    }

    public List<Articulo> obtenerLista(String condicion) {
        List<Articulo> lista;
        EntityManager em = getEntityManager(); // emf.createEntityManager();

        String cSql = "SELECT t FROM " + "Articulo" + " t "
                + " where t.id > 0 ";
        if (!condicion.equalsIgnoreCase("")) {
            cSql += condicion;
        }
        cSql += " order by t.codigo";

        Query query;
        query = em.createQuery(cSql);

        lista = query.getResultList();
//        log.trace("Registros encontrados:" + lista.size());
        em.close();
        return lista;
    }

    /**
     * Realizar alta de una lista. O se dan de alta todos los elementos o
     * ninguno
     *
     * @param lista
     */
    public void altaListaArticulos(List<Articulo> lista) throws Exception {
        EntityManager em = getEntityManager();
        // abrimos transaccion
        try {

            em.getTransaction().begin();

            for (Articulo arti : lista) {
                em.persist(arti);
                em.flush(); // va a la BD, aunque no hace commit
            }
            em.getTransaction().commit(); // si falla, hace autorollback
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw new Exception("Error en alta de lista de articulos:" + e.getMessage());
        } finally {
            em.close();
        }

    }
}

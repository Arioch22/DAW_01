/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10_jpa.dao.controllers;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import pround10_jpa.dao.entities.Articulo;
import pround10_jpa.dao.util.UtilJPA;

/**
 * Esta clase no extiende de ArticuloJpaController
 * @author profesor
 */
public class ArticuloController_0 {

    EntityManagerFactory emf = UtilJPA.getEntitymanagerFactory();

    public boolean existeCodigo(String codigo) throws Exception {
        List<Articulo> lista = new ArrayList();
        EntityManager em = emf.createEntityManager();

        System.out.println("Buscamos si existe el articulo " + codigo);
        try {
            Query query;
            query = em.createQuery("select t from " + Articulo.class.getName() + " t "
                    + " where t.codigo = :codigo ");
            query.setParameter("codigo", codigo);
            lista = query.getResultList();
            System.out.println("encontrados:" + lista.size());
        } catch (Exception e) {
            System.err.println("error en la búsqueda:" + e.getMessage());
        }

        return (lista.size() > 0);
    }
    /**
     * buscar articulo por codigo
     * @param codigo
     * @return objeto articulo encontrado o null si no es encontrado
     */
    public Articulo buscaArticuloPorCodigo(String codigo) {
        EntityManager em = emf.createEntityManager();
        Articulo arti = null;
        System.out.println("Buscamos  el articulo " + codigo);
        try {
            Query query;
            String consulta="select t.id, t.descripcion from Articulo t "
                    + " where t.codigo= '0002'";
                    
            query = em.createQuery("select t from " + Articulo.class.getName() + " t "
                    + " where t.codigo = :pepe ");
            query.setParameter("pepe", codigo);
            arti = (Articulo) query.getSingleResult();
            arti.setDescripcion("pepito");
            em.getTransaction().begin();
            em.getTransaction().commit();
            
        } catch (Exception e) {
            System.err.println("error en la búsqueda:" + e.getMessage());
        }
        
        return arti;
    }

    public void altaArticulo(Articulo articulo) throws Exception {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(articulo);
            em.getTransaction().commit();
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }

    public void modificaArticulo(Articulo articulo) throws Exception {
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            em.merge(articulo);
            em.getTransaction().commit();
        } catch (Exception e) {
            throw new Exception(e.getMessage());
        }
    }
}

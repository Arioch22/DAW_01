/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround10_jpa.programa;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import pround10_jpa.dao.controllers.ArticuloController_0;
import pround10_jpa.dao.controllers.ArticuloController;
import pround10_jpa.dao.controllers.LineaTicketController;
import pround10_jpa.dao.controllers.TicketController;
import pround10_jpa.dao.entities.Articulo;
import pround10_jpa.dao.entities.Datosentrega;
import pround10_jpa.dao.entities.Lineaticket;
import pround10_jpa.dao.entities.Ticket;
import pround10_jpa.dao.jpaControllers.ArticuloJpaController;
import pround10_jpa.dao.jpaControllers.DatosentregaJpaController;
import pround10_jpa.dao.jpaControllers.exceptions.NonexistentEntityException;
import pround10_jpa.dao.util.UtilJPA;

/**
 *
 * @author profesor
 */
public class Main {

    public static void main(String[] args) {
        ArticuloController articuloCtrl = new ArticuloController();

        // ver si un articulo existe
//        String codigo = "0025";
//        boolean existe =  articuloCtrlBis.existeCodigo(codigo);
//        System.out.println("Existe el codigo " + codigo);
        // obtener lista de articulos
//        List<Articulo> lista = articuloCtrlBis.obtenerLista("");
//        
//        for ( Articulo arti : lista){
//            System.out.println("codigo:" + arti.getCodigo() + " nombre:" + arti.getDescripcion());
//        }
        // alta articulo  sin JpaController
//        altaArticulo_0();
        // alta articulo  CON JpaController
//            altaArticulo();
        // modifica articulo sin JpaController
//        modifArticulo();
        // modifica articulo CON JpaController
//        modifArticulo();
        // alta lista articulos en una transaccion
//        altaListaArticulos();

        // alta ticket
//        altaTicket();
//    // busca Ticket
//        buscaTicket(21);
        // busca lineas de ticket
        buscaLineasTicket(21);
    }

    /**
     * Alta articulo sin usar JpaController
     */
    private static void altaArticulo_0() {
        Articulo arti = new Articulo();
        arti.setCodigo("5555");
        arti.setCtrolStock(1);
        arti.setDescripcion("Limpiador de baños");
        arti.setCodSeccion("03");
        ArticuloController_0 artiCtrl = new ArticuloController_0();
        try {
            artiCtrl.altaArticulo(arti);
        } catch (Exception ex) {
            System.err.println("Error en alta " + ex.getMessage());
        }

    }

    /**
     * Alta articulo usando JpaController
     */
    private static void altaArticulo() {
        Articulo arti = new Articulo();
        arti.setCodigo("5555");
        arti.setCtrolStock(1);
        arti.setDescripcion("Limpiador de baños");
        arti.setCodSeccion("03");
        ArticuloController artiCtrl = new ArticuloController();
        try {
            artiCtrl.create(arti);
        } catch (Exception e) {
            System.err.println("Error " + e.getMessage());
        }
    }

    private static void altaListaArticulos() {
        List<Articulo> lista = new ArrayList<>();
        Articulo arti;
        arti = new Articulo();
        arti.setCodigo("0044");
        arti.setDescripcion("Cocacola");
        arti.setCtrolStock(1);
        arti.setCodSeccion("42");
        lista.add(arti);
        arti = new Articulo();
        arti.setCodigo("0027");
        arti.setDescripcion("Cerveza Amstel");
        arti.setCtrolStock(1);
        arti.setCodSeccion("03");
        lista.add(arti);
        ArticuloController artiCtrl = new ArticuloController();
        try {
            artiCtrl.altaListaArticulos(lista);
            System.out.println("Alta realizada !!");
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
       
    }

    private static void modifArticulo_0() {
        // busco el articulo
        ArticuloController_0 artiCtrl = new ArticuloController_0();
        Articulo arti = artiCtrl.buscaArticuloPorCodigo("0025");
        if (arti != null) {
            // modifico la seccion
            arti.setCodSeccion("33");
            try {
                artiCtrl.modificaArticulo(arti);
                System.out.println("Modificacion realizada");
            } catch (Exception ex) {
                System.err.println("Error modificando articulo " + ex.getMessage());
            }
        } else {
            System.out.println("Articulo no encontrado");
        }
    }

    /**
     * modifica articulo con JpaController
     */
    private static void modifArticulo() {
        // busco el articulo
        ArticuloController artiCtrl = new ArticuloController();
        Articulo arti = artiCtrl.buscaArticuloPorCodigo("0025");
        if (arti != null) {
            // modifico la seccion
            arti.setCodSeccion("44");
            try {
                artiCtrl.edit(arti);
                System.out.println("Modificacion realizada");
            } catch (Exception ex) {
                System.err.println("Error modificando articulo " + ex.getMessage());
            }
        } else {
            System.out.println("Articulo no encontrado");
        }
    }

    private static void altaTicket() {
        // Creamos el objeto ticket
        Ticket tck = new Ticket();
        tck.setFecha(new Date());
        tck.setTicketCerrado(Integer.valueOf(0).shortValue());

        // Creamos el objeto datos entrega
        Datosentrega entrega = new Datosentrega();
        entrega.setDireccion("Avda La Marina -36, 1º B");
        entrega.setFechaEntrega(new Date());
        entrega.setPoblacion("Almendralejo-1");

        // Creamos la lista de lineas del ticket
        List<Lineaticket> listaLineas = new ArrayList<>();

        Lineaticket lin = new Lineaticket();
        lin.setCodArticulo("0002");
        lin.setCantidad(2);
        lin.setPrecio(2.45d);
        listaLineas.add(lin);
        lin.setIdTicket(tck);

        // articulo 5
        lin = new Lineaticket();
        lin.setCodArticulo("0003");
        lin.setCantidad(7);
        lin.setPrecio(6.22d);
        lin.setIdTicket(tck);
        listaLineas.add(lin);

        // articulo 3
        lin = new Lineaticket();
        lin.setCodArticulo("0004");
        lin.setCantidad(10);
        lin.setPrecio(8d);
        lin.setIdTicket(tck);
        listaLineas.add(lin);

        // nos vamos a crear el ticket
        TicketController tckCtrl = new TicketController();

        try {
            tckCtrl.creaTicket(tck, entrega, listaLineas);
            System.out.println("Creado ticket!!");
        } catch (Exception ex) {
            System.err.println("Error el alta de ticket");
        }

    }

    private static void buscaTicket(int id) {
        Ticket tck;
        TicketController tckCtrl = new TicketController();
        try {
            tck = tckCtrl.buscaTicketPorId(id);
            if (tck != null) {
                System.out.println("id:" + tck.getId() + " Fecha:" + tck.getFecha()
                        + "Dir. Entrega:" + tck.getDatosentrega().getDireccion());
                for (Lineaticket lin : tck.getLineaticketCollection()) {
                    System.out.println("codigo " + lin.getCodArticulo()
                            + " cantidad:" + lin.getCantidad()
                            + " precio:" + lin.getPrecio());
                }
            } else {
                System.out.println("Ticket no encontrado");
            }
        } catch (Exception e) {
            System.err.println("Error buscando ticket id:" + id);
        }

    }

    private static void buscaLineasTicket(int id) {
        List<Lineaticket> lista;
        LineaTicketController linCtrl = new LineaTicketController();
        try {
            lista = linCtrl.obtenerListaLineasTicket(id);
            if (lista.isEmpty()) {
                System.out.println("no encontradas lineas del ticket id:" + id);
            } else {
                for (Lineaticket lin : lista) {
                    System.out.println("idTicket:" + lin.getIdTicket().getId()
                            + " Fecha:" + lin.getIdTicket().getFecha()
                            + " Direcc. Entrega:" + lin.getIdTicket().getDatosentrega().getDireccion()
                            + " codigo " + lin.getCodArticulo()
                            + " cantidad:" + lin.getCantidad()
                            + " precio:" + lin.getPrecio());
                }
            }
        } catch (Exception e) {
            System.err.println("Error buscando lineas de ticket id:" + id);
        }
    }
}

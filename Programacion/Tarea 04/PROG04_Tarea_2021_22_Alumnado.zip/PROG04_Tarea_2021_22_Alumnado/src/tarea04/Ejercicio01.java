package tarea04;


/**
 * Ejercicio 1. Cálculo de puntuaciones.
 * @author Nombre y apellidos del alumno/a
 */

public class Ejercicio01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada
        // 1.- Declaramos un array de objetos String (anotaciones) 
        // con el contenido que se nos pide en el enunciado
        
        

        // Variables de salida

        
        // Variables auxiliares


        //String elemento;

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CÁLCULO DE PUNTUACIONES");
        System.out.println("-----------------------");

        // 2.- Mostramos por pantalla el contenido del array de anotaciones

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------

        // 3.- Recorremos cada elemento del array
 
        

            // 3.1.- Si el elemento "encaja" con el patrón (anotación válida), se calcula su puntuación
                // Para ello habrá que descomponer la anotación en cada uno de sus elementos,
                // calcular su valor y sumarlos.
            
                
            // 3.2.- Si no "encaja" con el patrón, la anotación será inválida y su puntuación -1

            
            // 3.3.- Las puntuaciones obtenidas se "acumulan" o "concatenan" separadaa por comas en un objeto de tipo StringBuilder

            
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO: PUNTUACIONES CALCULADAS");
        System.out.println("----------------------------------");

        // 4.- Mostramos por pantalla el resultado final
        
        // 4.1.- Lista completa de puntuaciones de cada mano

        // 4.2.- Número de anotaciones válidas
        
        // 4.3.- Número de anotaciones no válidas
        
        
    }

}

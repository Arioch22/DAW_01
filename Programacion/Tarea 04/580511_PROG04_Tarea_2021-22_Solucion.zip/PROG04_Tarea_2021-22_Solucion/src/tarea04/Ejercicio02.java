package tarea04;

import java.util.Arrays;

/**
 * Ejercicio 2. Reconocimiento de palíndromos.
 * @author Profe
 */

public class Ejercicio02 {
    
    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        String arrayTextos[] = {
            "Reconocer",
            "AMANECER",            
            "Esto no es un palindromo",
            "Dabale arroz a la zorra el abad.",
            "A man, a plan, a canal: Panama",
            "A man a plan and a canal, Panama",
            "No deseo ese don..."
        };
        // Variables de salida
        boolean[] esPalindromo;

        // Variables auxiliares

        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("RECONOCIMIENTO DE PALÍNDROMOS");
        System.out.println("-----------------------------");

        // Reservamos espacio para los arrays de resultado
        esPalindromo = new boolean[arrayTextos.length];
        
        // Mostramos el array de textos
        System.out.printf ("Los textos que vamos a analizar son: \n");
        for (int i=0; i<arrayTextos.length; i++) {
            System.out.printf ("-Texto %d: %s\n", i+1, arrayTextos[i]);
        }
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Recorremos el array de textos
        // Para cada texto comprobamos si es palíndromo.
        for (int i = 0; i < arrayTextos.length; i++) {
            String texto = arrayTextos[i];
            // Eliminamos espacios y signos de puntuación del texto
            StringBuilder todoJunto = new StringBuilder(
                    texto.trim().toLowerCase().replaceAll("[ :.;,]", "")
            );
            // Invertimos el texto
            StringBuilder todoJuntoInverso = new StringBuilder(todoJunto).reverse();
            // Comprobamos si el texto invertido y el original son iguales
            esPalindromo[i] = todoJunto.toString().equals(todoJuntoInverso.toString());
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADOS OBTENIDOS");
        System.out.println("--------------------");
        // Mostramos el array de resultados
        System.out.printf ("Palíndromos encontrados: %s\n", Arrays.toString(esPalindromo));
    }

    
}
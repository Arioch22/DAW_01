package tarea04;

import java.util.Arrays;

/**
 * Ejercicio 5. Sopa de letras.
 * @author profe
 */

public class Ejercicio05 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Variables de entrada
        String[] arrayEntrada = {"Hola", "sol", "AMOR", "ARA", "Casa", "dos"};

        // Variables de salida
        String[] arrayResultado;
        int numPalabrasEncontradas=0;

        char[][] arrayLetras = {
            {'H', 'J', 'S', 'O', 'L'},
            {'O', 'E', 'C', 'A', 'U'},
            {'L', 'Y', 'K', 'D', 'A'},
            {'A', 'A', 'M', 'O', 'R'},
            {'V', 'C', 'A', 'S', 'A'}
        };


        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BUSCADOR DE PALABRAS EN HORIZONTAL");
        System.out.println("----------------------------------");
        System.out.println("Sopa de letras:");
        for (int fil = 0; fil < arrayLetras.length; fil++) {
            for (int col = 0; col < arrayLetras[fil].length; col++) {
                char letra= arrayLetras[fil][col];
                System.out.printf ("%c ", letra);
            }
            System.out.println();
        }
        System.out.println("Lista de palabras de prueba:");
        System.out.println(Arrays.toString(arrayEntrada));

        //----------------------------------------------
        //                Procesamiento 
        //----------------------------------------------
        arrayResultado = new String[arrayEntrada.length];
        for (int i = 0; i < arrayEntrada.length; i++) {  // Recorremos cada palabra del array de entrada
            String palabra= arrayEntrada[i].toUpperCase();
            boolean encontrada= false;
            arrayResultado[i]= "no";
            for (int fil = 0; fil < arrayLetras.length && !encontrada; fil++) { // Recorremos cada fila
                String linea= new String (arrayLetras[fil]);  // Y buscamos la palabra en la fila
                encontrada= linea.contains(palabra);
                if (encontrada) {
                    numPalabrasEncontradas++;
                    arrayResultado[i]= String.format ("fila %d columna %d", 
                            fil, linea.indexOf(palabra));
                }
            }
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.printf("Resultado de la búsqueda horizontal:\n%s\n",
                Arrays.toString(arrayResultado));
        System.out.printf ("Número de palabras encontradas: %d\n", numPalabrasEncontradas);

    }
}

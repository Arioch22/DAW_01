package tarea04;

import java.util.Arrays;

/**
 * Ejercicio 4. ¡Línea!
 * @author Profe
 */

public class Ejercicio04 {
    
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Variables de entrada
        int[] arrayBolasExtraidas = {1, 2, 5, 10, 11, 12, 14, 15, 22, 55, 56, 57, 59, 60, 61, 66, 78, 89, 90};
        int[][] arrayCarton = {
            {1, 2, 5, 9},
            {11, 15},
            {22, 29},
            {34},
            {47, 49},
            {55, 59, 60},
            {61},
            {71, 75},
            {88, 90}
        };

        // Variables de salida
        String[] arrayResultado;
        int numLineas=0;

        // Variables auxiliares

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("BUSCADOR DE LÍNEAS EN UN CARTÓN DE BINGO");
        System.out.println("----------------------------------------");
        System.out.printf ("Cartón: %s\n", Arrays.deepToString (arrayCarton));
        System.out.printf ("Números que ya han salido: %s\n", Arrays.toString (arrayBolasExtraidas));

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------  
        // Reservamos espacio para el array de resultados (obteniendo el número de filas que tenga el cartón)
        arrayResultado = new String[arrayCarton.length];  
        for (int fil = 0; fil < arrayCarton.length ; fil++) { // Recorremos cada fila
            boolean lineaPosible= true;
            arrayResultado[fil]= "no";  // En principio no hay línea salvo que se demuestre lo contrario
            for (int col=0; col< arrayCarton[fil].length && lineaPosible; col++) { // Recorremos todas las columnas de cada fila
                boolean encontrado= false;
                for (int i = 0; i < arrayBolasExtraidas.length && !encontrado; i++) { // Comparamos el contenido de la columna con los números ya aparecidos
                     encontrado= arrayCarton[fil][col] == arrayBolasExtraidas[i];
                }
                lineaPosible= lineaPosible & encontrado;  // En cuanto no se encuentre un número ya no hay línea en esa fila
            }
            if (lineaPosible) {  // Si todos los números han sido encontrados
                arrayResultado[fil]= "línea";
                numLineas++;
            }
        }
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO");
        System.out.println("---------");
        System.out.printf("Resultado de la búsqueda de líneas en el cartón de bingo:\n%s\n",
                Arrays.toString(arrayResultado));
        System.out.printf("Número de líneas obtenidas: %d\n", numLineas);
    }      
}

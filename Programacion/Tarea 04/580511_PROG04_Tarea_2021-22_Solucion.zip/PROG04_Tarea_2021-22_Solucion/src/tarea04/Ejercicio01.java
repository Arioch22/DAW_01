package tarea04;

import java.util.Arrays;

/**
 * Ejercicio 1. Cálculo de puntuaciones.
 * @author Profe
 */

public class Ejercicio01 {

    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes

        // Variables de entrada
        String arrayAnotaciones[] = {"a", "a-b", "X-A", "O-O-B", "X--X", "O-X-", "-X-X", "O-X-O-X-O",
            "o", "O-o", "X", "o-x-o", "x", "x-x", "O-x-X", "X-X-X", "x-X-X-x"};

        // Variables de salida
        StringBuilder resultadoFinal;
        int anotacionesValidas=0, anotacionesInvalidas=0;

        // Variables auxiliares
        String elementosAnotacion[];
        int puntuacionTotalAnotacion;

        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("CÁLCULO DE PUNTUACIONES");
        System.out.println("-----------------------");

        // Mostramos por pantalla el contenido del array de anotaciones
        System.out.println("Anotaciones obtenidas de cada mano del juego:");
        System.out.println(Arrays.toString(arrayAnotaciones));

        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        String patron = "[OoXx](-[OoXx]){0,3}";
        resultadoFinal = new StringBuilder();

        // Recorremos cada cadena del array
        for (int i = 0; i < arrayAnotaciones.length; i++) {
            String elemento = arrayAnotaciones[i];
            puntuacionTotalAnotacion = -1;
            if (i > 0) {
                resultadoFinal.append(", ");
            }
            // Si el elemento "encaja" con el patrón
            if (elemento.matches(patron)) {
                anotacionesValidas++; // Incrementamos elc ontado de anotaciones válidas
                // Obtenemos cada una de las puntuaciones de la anotación (X/x o bien O/o)
                elementosAnotacion = elemento.split("-"); // Para ello separamos todo lo que esté entre "-"
                puntuacionTotalAnotacion = 0;
                // Y las vamos sumando (acumulando)
                for (String fragmento : elementosAnotacion) {
                    if (fragmento.toUpperCase().charAt(0) == 'X') {
                        puntuacionTotalAnotacion++; // Si es X/x podemos sumamos +1, si no (O/o) nada
                    }
                }
            } else {
                anotacionesInvalidas++; // Incrementamos el contador de anotaciones inválidas
            }
            // Vamos "acumulando" cada puntuación
            resultadoFinal.append(puntuacionTotalAnotacion);
        }
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println();
        System.out.println("RESULTADO: PUNTUACIONES CALCULADAS");
        System.out.println("----------------------------------");

        // Mostrar por pantalla el resultado final
        System.out.printf ("Puntuaciones: %s\n", resultadoFinal);
        System.out.printf ("Número de anotaciones válidas:  %2d.\n", anotacionesValidas);
        System.out.printf ("Número de anotaciones inválidas:%2d.\n", anotacionesInvalidas);
    }

}

package tarea04;

/**
 * Ejercicio 3. Inversión de palabras.
 * @author Profe
 */

public class Ejercicio03 {
    
    public static void main(String[] args) {
        //----------------------------------------------
        //          Declaración de variables 
        //----------------------------------------------
        // Constantes
        // Variables de entrada
        String arrayTextos[] = {
            "Reconocer",
            "AMANECER",            
            "Esto no es un palindromo",
            "Dabale arroz a la zorra el abad.",
            "A man, a plan, a canal: Panama",
            "A man a plan and a canal, Panama",
            "No deseo ese don..."
        };
        // Variables de salida
        String[] arrayTextosInvertidos;

        // Variables auxiliares

        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("INVERSIÓN DE PALABRAS");
        System.out.println("---------------------");

        // Reservamos espacio para los arrays de resultado
        arrayTextosInvertidos = new String[arrayTextos.length];
        
        // Mostramos el array de textos
        System.out.printf ("Los textos que vamos a analizar son: \n");
        for (int i=0; i<arrayTextos.length; i++) {
            System.out.printf ("-Texto %d: %s\n", i+1, arrayTextos[i]);
        }
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // Recorremos el array de textos
        // Para cada texto invertimos cada palabra que contenga.
        for (int i = 0; i < arrayTextos.length; i++) {
            String texto = arrayTextos[i];

            // Separamos cada palabra del texto
            String[] arrayPalabras = texto.trim().split("[ :.;,]+");

            // Generamos un nuevo texto con las palabras invertidas
            StringBuilder textoPalabrasInvertidas = new StringBuilder();
            for (String palabra : arrayPalabras) {
                textoPalabrasInvertidas.append(new StringBuilder(palabra).reverse()).append(" ");
            }
            if (textoPalabrasInvertidas.length() > 0) {
                textoPalabrasInvertidas.deleteCharAt(textoPalabrasInvertidas.length() - 1);
            }
            arrayTextosInvertidos[i] = textoPalabrasInvertidas.toString();
        }

        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        // Recorremos el array de textos
        // Para cada texto:
        // 1. Mostramos el texto original (array arrayTextos)
        // 2. Mostramos el texto con las palabras invertidas (array arrayTextosInvertidos)
        System.out.println();
        System.out.println("RESULTADOS OBTENIDOS");
        System.out.println("--------------------");
        for (int i = 0; i < arrayTextos.length; i++) {
            System.out.printf("Texto %d: \"%s\"\n", i+1, arrayTextos[i]);
            System.out.printf("Palabras invertidas: \"%s\"\n\n",
                    arrayTextosInvertidos[i]);
        }
    }

    
}
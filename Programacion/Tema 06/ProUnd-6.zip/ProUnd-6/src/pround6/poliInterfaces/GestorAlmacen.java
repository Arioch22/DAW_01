/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround6.poliInterfaces;

import java.util.List;

/**
 * Representa un módulo gestor de almacen, al que recurrimos para imprimir y
 * facturar documentos
 *
 * @author
 */
public class GestorAlmacen {

    public static void imprimeDocumento(IImprimible documento) {
        System.out.println("Imprimir Documento------------------------");
        List<String> listaCabecera = documento.devolverCabecera();
        List<String> listaLineas = documento.devolverListaLineas();
        for (String s : listaCabecera) {
            System.out.println(s);
        }

        // fin de cabecera, empiezanlas lineas
        System.out.println("-----------------------------------------");
        for (String s : listaLineas) {
            System.out.println(s);
        }
        System.out.println("Fin documento");
        System.out.println("===============================================");
    }

    public static void facturaDocumento(IFacturable documento) {
        double base = documento.devolverBase();
        double porcIva = documento.devolverPorcentajeIVA();

        System.out.printf("Esto es la factura de un documento de base %.2f y porcentaje iva %.2f \n",
                base, porcIva);
        System.out.printf("Toral factura: %.2f \n", base * (1 + porcIva / 100));
        System.out.println("fin factura ");
        System.out.println("===============================================");

    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.poliInterfaces;

//import org.slf4j.Logger;
import java.util.ArrayList;
import java.util.List;

/**
 * El pedido de mayhor es imprimible, pero no es facturable. Se supone que hasta
 * que no esta servido, es decir convertido en albaran de mayor no seria
 * facturable. 
 *
 * @author profesor *
 */
public class PedidoMayor implements IImprimible {

    @Override
    public List devolverCabecera() {
        List<String> listaCab = new ArrayList<>();
        listaCab.add("linea1 de cabecera");
        listaCab.add("linea 2 de cabecera de pedido");
        return listaCab;
    }

    @Override
    public List devolverListaLineas() {
        List<String> listaLineas = new ArrayList<>();
        listaLineas.add("linea1 de detalle");
        listaLineas.add("linea 2 de detalle de pedido");
        return listaLineas;
    }

}

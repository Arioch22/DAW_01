/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.poliInterfaces;

import java.util.List;

/**
 * interface que describe el comportamiento de un documento que sea imprimible
 * @author profesor
 */
public interface IImprimible {
    List devolverCabecera();
    List devolverListaLineas (); 
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround6.poliInterfaces;

/**
 *
 * @author profesor
 */
public class PruebasMain {

    public static void main(String[] args) {

        // Crear un albaran de mayor , imprimirlo y facturarlo
        
        AlbaranVentaMayor alba_1 = new AlbaranVentaMayor("Bar La Esquina", "Avda Lopez Ibor, 34");
        alba_1.addLinea("Patatas fritas cant=10   importe= 121", 100);
        alba_1.addLinea("Cerveza la fresca    cant=22   importe= 242", 200);
        
        // Imprimimos el documento
        
        GestorAlmacen.imprimeDocumento(alba_1);
        

        // Facturamos  el documento
        
        GestorAlmacen.facturaDocumento(alba_1);
        
        // Creamos un pedido de mayor y lo imprimimos
        
        PedidoMayor ped_1 =new PedidoMayor();
        
        GestorAlmacen.imprimeDocumento(ped_1);
        
        // Creamos un ticket y lo facturamos
        
        TicketCaja tc = new TicketCaja();
        tc.addLinea("Tomate Frito fruco cant 1, importe = 1.21", 1);
        tc.addLinea("Lejía Estrella cant 1, importe = 3.63", 3);

//        // Sin polimorfismo
//        GestorAlmacenSinPoli.imprimeTicketCaja(tc);
//        GestorAlmacenSinPoli.facturaTicketCaja(tc);
        
        // Usando polimorfismo. 
        // Invocamos a los metodos imprimir y facturar pasandole
        // como parametro los interfaces

        GestorAlmacen.imprimeDocumento(tc);
        GestorAlmacen.facturaDocumento(tc);
        
    }
}

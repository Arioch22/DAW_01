/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.poliInterfaces;

//import org.slf4j.Logger;
import java.util.ArrayList;
import java.util.List;


/** Un tiecket de caja es imprimible y facturable. Implementa ambos interfaces
 * @author profesor /
 */
//public class TicketCaja implements IImprimible {
public class TicketCaja implements IImprimible, IFacturable {

    double baseTotal = 0;
    double porcIva = 21;
    private List<String> listaLineas;

    public TicketCaja() {
        listaLineas = new ArrayList<>();
    }

    public void addLinea(String linea, int baseArticulo) {
        listaLineas.add(linea);
        this.baseTotal += baseArticulo;
    }

    @Override
    public List devolverCabecera() {
        List<String> listaCabecera = new ArrayList<>();
        listaCabecera.add("Clientes Varios");
        return listaCabecera;
    }

    @Override
    public List devolverListaLineas() {
        return listaLineas;
    }
    // -- Si no implementa facturable, escribo los métodos
    // necesarios llamándoles como quiera
    //
    public double getPorcIva(){
        double porc = 21;
        return  porc;
    }
    public double getBase(){
        return  this.baseTotal;
    }
    
//    // Si implementa facturable, tengo que escribir los métodos del
//    // interface
//
    @Override
    public double devolverBase() {
             return  this.baseTotal;
    }

    @Override
    public double devolverPorcentajeIVA() {
         double porc = 21;
        return  porc;
    }
    
    
}

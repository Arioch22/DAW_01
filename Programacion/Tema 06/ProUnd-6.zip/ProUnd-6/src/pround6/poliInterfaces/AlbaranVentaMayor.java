/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.poliInterfaces;

//import org.slf4j.Logger;
import java.util.ArrayList;
import java.util.List;

//import org.slf4j.LoggerFactory;
/**
 * @author profesor 
 */
public class AlbaranVentaMayor implements IImprimible, IFacturable {

    private String nombre;
    private String direccion;
    double baseTotal = 0;
    double porcIva = 21;

    private List<String> listaLineas;

    public AlbaranVentaMayor(String nombre, String direccion) {
        this.nombre = nombre;
        this.direccion = direccion;
        listaLineas = new ArrayList<>();
    }

    public void addLinea(String linea, int baseArticulo) {
        listaLineas.add(linea);
        this.baseTotal += baseArticulo;
    }

    @Override
    public List devolverCabecera() {
        List<String> listaCabecera = new ArrayList<>();
        listaCabecera.add(nombre);
        listaCabecera.add(direccion);
        return listaCabecera;
    }

    @Override
    public List devolverListaLineas() {
        return listaLineas;
    }

    @Override
    public double devolverBase() {
        return baseTotal;
    }

    @Override
    public double devolverPorcentajeIVA() {
        return porcIva;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.poliInterfaces;

/**
 * interface que define el comportamiento de un documento que sea facturable
 * @author profesor
 */
public interface IFacturable {
    double devolverBase();
    double devolverPorcentajeIVA();
}

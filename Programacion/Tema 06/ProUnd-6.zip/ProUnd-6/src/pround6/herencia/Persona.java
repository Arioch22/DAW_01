/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pround6.herencia;



import java.time.LocalDate;


/**
 *@author  profesor 
 * 
 */
public class Persona {
 
    private String nombre;
    protected String apellidos;
    private LocalDate fechaNto;
    private static int nroPersonasCreadas;

    public Persona(String nombre, String apellidos, LocalDate fechaNto) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNto = fechaNto;
        nroPersonasCreadas++;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    protected String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public LocalDate getFechaNto() {
        return fechaNto;
    }

    public void setFechaNto(LocalDate fechaNto) {
        this.fechaNto = fechaNto;
    }
    public  int getEdad(){
        int edad = LocalDate.now().getYear() - this.fechaNto.getYear();
        return edad;
    }

    public static int getNroPersonasCreadas() {
        return nroPersonasCreadas;
    }
    
}

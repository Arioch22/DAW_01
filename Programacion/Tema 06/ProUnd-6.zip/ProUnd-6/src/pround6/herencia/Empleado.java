/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.herencia;

//import org.slf4j.Logger;
import java.time.LocalDate;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

/**
 * @author profesor 
 */
public class Empleado extends Persona {
 
    private double sueldo = 0d;
    private String puesto = "";
    private String empresa;
    
    public Empleado(double sueldo, String puesto, String nombre, String apellidos, LocalDate fechaNto) {
        super(nombre, apellidos, fechaNto);
        this.sueldo = sueldo;
        this.puesto = puesto;
    }
    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    @Override
    public String getNombre() {
        return "Sr. " + super.getNombre();
    }
    // sobreescribimos con la misma visibilidad
//    @Override
//    protected String getApellidos(){
//        return "Apellidos:" + super.getApellidos();
//    }

    // sobreescribimos ampliando visibilidad
//    @Override
//    public String getApellidos(){
//        return "Apellidos: " + super.getApellidos();
//    }
    
    
    // No se puede sobreescribir un método static
//    @Override
//    public static getNroPersonasCreadas(){
//        
//    }
    
    
    // Un método final no se puede sobreescribir
    
    @Override
    public int getEdad(){
        // me quito años
        return super.getEdad() -2 ;
    }
}

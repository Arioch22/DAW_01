/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.herencia;

//import org.slf4j.Logger;
import java.time.LocalDate;
import java.time.Month;

//import org.slf4j.LoggerFactory;
/**
 * @author profesor 
 */
public class MainHerencia {
    // private static final Logger log = LoggerFactory.getLogger(MainHerencia.class);

    public static void main(String args[]) {
        Persona p1 = new Persona("Susnsa", "López Fernández", LocalDate.of(1997,10,24));
        System.out.println("La edad de "+ p1.getNombre() + " es " + p1.getEdad());
        
        Empleado carpintero1 = new Empleado(1500, "Carpintero", "Juan", "Garcia",
                LocalDate.of(2000, 3, 23));

        // queremos ver el nombre del empleado
        System.out.println("El nombre del empleado es " + carpintero1.getNombre());

        // queremos ver el apellido , que es protected en persona
        System.out.println("El apellido del empleado es " + carpintero1.getApellidos());

        // queremos usar un método publico de la clase antecesora
        System.out.println("La edad de " +  carpintero1.getNombre() +
                " es " + carpintero1.getEdad());
        
        // Ahora usamos los métodos específicos de la subclase 

        System.out.printf("El puesto de %s es %s, y El sueldo  es %.0f\n" , 
                carpintero1.getNombre(),
                carpintero1.getPuesto(),
                carpintero1.getSueldo());
        
        
    }
}

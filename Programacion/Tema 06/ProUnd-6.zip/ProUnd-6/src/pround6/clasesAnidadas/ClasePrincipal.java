/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.clasesAnidadas;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
/**
 *
 * @author
 */
public class ClasePrincipal {
// private static final Logger log = LoggerFactory.getLogger(ClasePrincipal.class);

    int[] numeros;

    ClasePrincipal(int n[]) {
        numeros = n;
    }

    void analizaMaxMin() {
        ClaseInterna objInterna = new ClaseInterna();
        System.out.println("Minimo: " + objInterna.calculaMinimo());
        System.out.println("Máximo: " + objInterna.calculaMaximo());

    }

    //Clase interna
    class ClaseInterna {

        int calculaMinimo() {
            int m = numeros[0];

            for (int i = 1; i < numeros.length; i++) {
                if (numeros[i] < m) {
                    m = numeros[i];
                }
            }
            return m;
        }

        int calculaMaximo() {
            int m = numeros[0];
            for (int i = 1; i < numeros.length; i++) {
                if (numeros[i] > m) {
                    m = numeros[i];
                }
            }
            return m;
        }

    }
    // ...
}

class ClaseAndidada {

    public static void main(String[] args) {

        int x[] = {6, 3, 4, 1, 5, 2, 9, 8};
        ClasePrincipal objPral = new ClasePrincipal(x);
        objPral.analizaMaxMin();

    }
}


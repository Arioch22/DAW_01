/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pround6.clasesAnidadas;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
/**
 *
 * @author 
 */
public class ClaseTal {
// private static final Logger log = LoggerFactory.getLogger(ClaseTal.class);
    public ClaseTal(){
        
    }
    public String metodoTal(){
        System.out.println("Este metodo Tal hace esto de la forma 1");
        return "Forma 1 de hacerlo";
    }
}

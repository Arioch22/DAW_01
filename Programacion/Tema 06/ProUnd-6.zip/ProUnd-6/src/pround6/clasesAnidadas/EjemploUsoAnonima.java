/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.clasesAnidadas;

/**
 *
 * @author 
 */
public class EjemploUsoAnonima {


    public static void main(String args[]) {
        // instancio objeto de la claseTal
        ClaseTal obj1 = new ClaseTal();
        String resultado1 = obj1.metodoTal();
        System.out.println("Resultado1:" + resultado1);

        // ahora lo hago mediante clase anonima porque me interesa cambiar al vuelo
        // lo que hace alguno de sus métodos, o crear otros.
        ClaseTal obj2 = new ClaseTal() {
            @Override // sobreescribo el funcionamiento del metodo metodoTal
            public String metodoTal() {
                String texto = "palabraEjemplo";
                System.out.println("Este metodo Tal hace esto de la forma 2 y usa el metodo nuevo cuentaLetras");
                return "El nro. de letras de la palabra " + texto + " es " + cuentaLetras(texto);
            }

            // añado un metodo nuevo 
            public int cuentaLetras(String palabra) {
                return palabra.length();
            }
        };

        System.out.println("Resultado2:" + obj2.metodoTal());

        // ahora usamos solo el metodo nuevo
        String resultado3 = new ClaseTal() {
            public String metodoNuevo(String texto) {
                // este metodo usa metodos de la clase ClaseTal, pero no existia
                return metodoTal() + ":" + texto;
            }
        }.metodoNuevo("Texto añadido");

        System.out.println("Resultado3:" + resultado3);
    }

}

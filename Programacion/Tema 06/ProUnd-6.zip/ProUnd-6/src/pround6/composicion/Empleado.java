/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.composicion;

//import org.slf4j.Logger;
import java.time.LocalDate;

//import org.slf4j.LoggerFactory;
/**
 * @author profesor 
 */
public class Empleado {
    // private static final Logger log = LoggerFactory.getLogger(Empleado.class);

    private String nombre;
    private String apellidos;
    private LocalDate fechaNto;
    private Direccion direccion;

    public Empleado(String nombre, String apellidos, LocalDate fechaNto) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNto = fechaNto;
        direccion = new Direccion();
    }

    public Empleado(String nombre, String apellidos, LocalDate fechaNto, Direccion direccion) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.fechaNto = fechaNto;
        this.direccion = new Direccion(direccion);
//        this.direccion = direccion;  // forma incorrecta
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public LocalDate getFechaNto() {
        return fechaNto;
    }

    // No seria correcto. Dejamos una puerta abierta
//    public Direccion getDireccion(){  
//        return direccion;
//    }

//     Correcto devolver una copia
    public Direccion getDireccion(){
        return new Direccion(direccion);
    }
//    public void setDireccion(Direccion dire) {
//        this.direccion = new Direccion(dire);
//    }
    public void modificaCiudadEmpleado(String ciudad) {
        direccion.setCiudad(ciudad);
    }
}

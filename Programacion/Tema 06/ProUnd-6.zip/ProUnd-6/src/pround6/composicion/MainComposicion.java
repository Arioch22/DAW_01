/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.composicion;

//import org.slf4j.Logger;
import java.time.LocalDate;

//import org.slf4j.LoggerFactory;
/**
 * @author profesor 
 */
public class MainComposicion {
    // private static final Logger log = LoggerFactory.getLogger(MainComposicion.class);

    public static void main(String args[]) {
        System.out.println("Voy a crear un empleado con su direccion");
        Direccion direccion1 = new Direccion("C/Sebastian El Cano",
                "nª 7- 2º A",
                "41025", "Utrera");
        Empleado empleado1 = new Empleado("Juan Manuel", "Garcia Garcia",
                LocalDate.of(1995, 3, 1),
                direccion1);
        System.out.println("La ciudad del empleado1 es " + empleado1.getDireccion().getCiudad());

        // voy a modificar la ciudad con control de la clase empleadopermiso del empleado
//        System.out.println("Voy a modificar la ciudad de empleado 1 a Madrid");
//        empleado1.modificaCiudadEmpleado("Madrid");
//        System.out.println("La ciudad del empleado1 es " + empleado1.getDireccion().getCiudad());
//
        // Voy a cargar la direccion del empleado 1 y modificarla 
//        System.out.println("Voy a cambiar la ciudad de empleado 1  a Bercelona (Sin control de la clase Empleado)");
//        empleado1.getDireccion().setCiudad("Barcelona");
//        System.out.println("La ciudad del empleado1 es " + empleado1.getDireccion().getCiudad());

        // voy a cambiar la ciudad de empleado1 sin que se controle la clase Empleado
        // por haber usado mal el constructor
        System.out.println("Voy a cambiar la ciudad de empleado 1  a Bercelona (Sin control de la clase Empleado-constructor)");
        direccion1.setCiudad("Sevilla");
        System.out.println("La ciudad del empleado1 es " + empleado1.getDireccion().getCiudad());
        
    }
}

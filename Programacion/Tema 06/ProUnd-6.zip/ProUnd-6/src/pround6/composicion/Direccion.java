/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.composicion;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
/**
 * Clase que define una direccion. Se utilizará como atributo  referenciado en otras clases
 * @author profesor 
 */
public class Direccion {
    // private static final Logger log = LoggerFactory.getLogger(Direccion.class);

    private String nombreCalle = "";
    private String numeroPiso = "";
    private String codPostal = "";
    private String ciudad = "";

    public Direccion() {

    }

    public Direccion(String nombreCalle, String numeroPiso, String codPostal, String ciudad) {
        this.nombreCalle = nombreCalle;
        this.numeroPiso = numeroPiso;
        this.codPostal = codPostal;
        this.ciudad = ciudad;
    }

    // constructor copia
    public Direccion(Direccion dire) {
        this(dire.getNombreCalle(), dire.getNumeroPiso(),
                dire.getCodPostal(), dire.getCiudad());
    }

    public String getNombreCalle() {
        return nombreCalle;
    }

    public void setNombreCalle(String nombreCalle) {
        this.nombreCalle = nombreCalle;
    }

    public String getNumeroPiso() {
        return numeroPiso;
    }

    public void setNumeroPiso(String numeroPiso) {
        this.numeroPiso = numeroPiso;
    }

    public String getCodPostal() {
        return codPostal;
    }

    public void setCodPostal(String codPostal) {
        this.codPostal = codPostal;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

}

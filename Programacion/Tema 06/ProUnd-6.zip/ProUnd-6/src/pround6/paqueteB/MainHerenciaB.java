/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.paqueteB;

//import org.slf4j.Logger;
import pround6.herencia.*;
import java.time.LocalDate;
import java.time.Month;

//import org.slf4j.LoggerFactory;
/**
 * @author profesor //@author igo - JAGV - IES-Trassierra
 */
public class MainHerenciaB {
    // private static final Logger log = LoggerFactory.getLogger(MainHerenciaB.class);

    public static void main(String args[]) {
        Empleado carpintero1 = new Empleado(1500, "Carpintero", "Juan", "Garcia",
                LocalDate.of(2000, 3, 23));
        
        // queremos ver el nombre del empleado
        System.out.println("El nombre del empleado es " + carpintero1.getNombre());
        
//         // queremos ver el apellido , que es protected en persona
//        System.out.println("El apellido del empleado es " + carpintero1.getApellidos());
    }
}

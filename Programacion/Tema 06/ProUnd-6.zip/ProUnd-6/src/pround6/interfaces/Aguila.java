/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround6.interfaces;

/**
 *
 * @author 
 */
public class Aguila extends Animal implements Depredador {

    public Aguila(String especie) {
        super(especie);
    }

    @Override
    public void localiza(Animal animal) {
        System.out.println("Forma en la que un aguila localiza una presa");
    }

    @Override
    public void persigue(Animal animal) {
        System.out.println("esta es la formza en que un aguila persigue: volando");
    }

    @Override
    public boolean caza(Animal animal) {
        System.out.println("un aguila caza asi");  
        return true;
    }

}

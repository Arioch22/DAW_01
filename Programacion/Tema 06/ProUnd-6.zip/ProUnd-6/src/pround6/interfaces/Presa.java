/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package pround6.interfaces;

/**
 *
 * @author 
 */
public interface Presa {
    public void huir();
    public void esconderse();
   
}

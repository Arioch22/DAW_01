/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pround6.interfaces;

/**
 *
 * @author
 */
public class Leon extends Animal implements Depredador {

    String habitat;
    private final int NRO_PATAS = 4;
    int peso;

    public Leon(String habitat, int peso, String especie) {
        super(especie);
        this.habitat = habitat;
        this.peso = peso;
    }

    @Override
    public void localiza(Animal animal) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void persigue(Animal animal) {
        System.out.println("Esta es la forma en que persigue un Leon a su presa");
    }

    @Override
    public boolean caza(Animal animal) {
        System.out.println("Esta es la forma en que un Leon caza a su presa");
        return true;
    }

}

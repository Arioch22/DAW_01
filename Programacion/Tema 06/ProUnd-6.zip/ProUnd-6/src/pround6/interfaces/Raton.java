/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package pround6.interfaces;

/**
 *
 * @author
 */
public class Raton extends Animal implements Presa {
    
    public Raton(String especie) {
        super(especie);
    }

    @Override
    public void huir() {
        System.out.println("así huye un ratón");
    }

    @Override
    public void esconderse() {
        System.out.println("Así se esconde un raton");
    }

}

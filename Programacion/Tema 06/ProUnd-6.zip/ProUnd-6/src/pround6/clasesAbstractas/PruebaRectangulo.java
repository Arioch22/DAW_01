/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pround6.clasesAbstractas;

//import org.slf4j.Logger;

import java.util.Scanner;

//import org.slf4j.LoggerFactory;
/** 
 *@author  profesor 
 * 
 */
public class PruebaRectangulo {
  public static void main(String[] args)
    {
        String color;
        double base;
        double altura;

        Scanner teclado = new Scanner(System.in);

        System.out.print("Introduzca el color del rectangulo: ");
        color = teclado.nextLine();

        System.out.print("Introduzca la base del rectangulo: ");
        base = teclado.nextDouble();

        System.out.print("Introduzca la altura del rectangulo: ");
        altura = teclado.nextDouble();

        Rectangulo rectangulo1 = new Rectangulo(color, base,altura);

        // se podria instanciar la clase abstracta a través de alguna de sus subclases
        FormaGeometrica pepe = new Rectangulo(color, base, altura);
        
        System.out.printf("El área del rectangulo %s es: %.2f\n", rectangulo1.getColor(), rectangulo1.calcularArea());
    }
}

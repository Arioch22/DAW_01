/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.clasesAbstractas;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
/**
 * clase abstracta.Superclase Patron de construccion de subclases, con propieddes /metodos comunes
 * que ya está implementados en la propia clase (superclase) y otros abstractos que han 
 * de implementarse obligatoriamente en las subclases que extiendan ésta
 * @author profesor
 */
public abstract  class FormaGeometrica {


    private  String color;

    public FormaGeometrica(String color) {
        this.color = color;
    }
    // método abstracto. Lo implementaran todas sus subclases
    public abstract double calcularArea();     

    // método no abstracto. Implementado aquí.
    public String getColor() {
        return color;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package pround6.clasesAbstractas;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
/**
 ** representa un circulo que hereda de FormaGeometrica
 * @author
 */
public class Circulo extends FormaGeometrica {
    double radio;
    public Circulo(String color, double radio) {
        super(color);
        this.radio = radio;
    }

    @Override
    public double calcularArea() {
        return Math.PI * Math.pow(radio,2);
    }

}

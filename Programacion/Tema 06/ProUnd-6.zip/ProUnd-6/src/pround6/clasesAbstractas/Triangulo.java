/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pround6.clasesAbstractas;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
/**
 ** representa un trianglo que hereda de FormaGeometrica
 * @author profesor
 */
public class Triangulo extends FormaGeometrica {

    double base;
    double altura;

    public Triangulo(String color, double base, double altura) {
        super(color);
        this.base = base;
        this.altura = altura;
    }

//    @Override
//    public double calcularArea() {
//        return 0.5 * base * altura ;
//    }

    @Override
    public double calcularArea() {
        return 0.5 * base * altura ;
        
    }

}

package tarea1;

import java.util.Scanner;

/**
 * M�quina expendedora de productos.
 * @author Nombre alumno/a
 */
public class Ejercicio05 {
    
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes

        // Variables de entrada
        
        // Variables de salida
        
        // Variables auxiliares

        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("M�QUINA EXPENDEDORA DE PRODUCTOS");
        System.out.println("--------------------------------");
        
                
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------




        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        
    }
    
}

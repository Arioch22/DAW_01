package tarea1;

import java.util.Scanner;

/**
 * C�lculos aritm�ticos.
 * Escribe un programa en Java que solicite dos n�meros reales y lleve a cabo los 
 * siguientes c�lculos:
 *  1. el triple del primer n�mero,
 *  2. la d�cima parte del segundo n�mero,
 *  3. el cuadrado del doble del producto de ambos n�meros,
 *  4. la mitad del cuadrado de la suma de ambos n�meros.
 * 
 * @author Nombre alumno/a
 */
public class Ejercicio02 {
    
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes

        
        // Variables de entrada

        
        // Variables de salida

        
        // Variables auxiliares

        
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("C�LCULOS ARITM�TICOS");
        System.out.println("--------------------");


        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Primer c�lculo: triple del primer n�mero
        
        // Segundo c�lculo: d�cima parte del segundo n�mero

        // Tercer c�lculo: cuadrado del doble del producto de ambos n�meros
        
        // Cuarto c�lculo: mitad del cuadrado de la suma de ambos n�meros
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
    }    
}
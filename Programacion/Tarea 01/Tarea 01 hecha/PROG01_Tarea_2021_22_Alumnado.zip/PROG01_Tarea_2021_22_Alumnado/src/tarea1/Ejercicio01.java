package tarea1;

/**
 * Provincias de Andaluc�a.
 * @author Nombre alumno/a
 */
public class Ejercicio01 {
    
    // Definici�n del enum

    
    // Programa principal
    public static void main(String[] args) {
             
        System.out.println ("PROVINCIAS DE ANDALUC�A");
        System.out.println ("-----------------------");
        
        // Vamos mostrando cada uno de los posibles valores del enum
        // (no hace falta estructurar el programa en entrada/procesamiento/salida)

    }
    
}

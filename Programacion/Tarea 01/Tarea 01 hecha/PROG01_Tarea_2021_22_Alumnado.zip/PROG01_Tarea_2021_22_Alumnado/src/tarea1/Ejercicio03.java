
package tarea1;

import java.util.Scanner;

/**
 * An�lisis de un n�mero.
 * 
 * @author Nombre alumno/a
 */
public class Ejercicio03 {
    
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada

        
        // Variables de salida

        
        // Variables auxiliares

        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("AN�LISIS DE UN N�MERO");
        System.out.println("---------------------");
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // C�lculo de los resultados l�gicos

        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
    }    
}

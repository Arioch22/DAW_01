package tarea1;

/**
 * Trayecto en dos etapas.
 * 
 * @author Nombre alumno/a
 */
import java.util.Scanner;

public class Ejercicio04 {
 
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes


        // Variables de entrada

        
        // Variables de salida

                
        // Variables auxiliares

        
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("TRAYECTO EN DOS ETAPAS");
        System.out.println("----------------------");

        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        

        
        
        
        
        //----------------------------------------------    
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
    }    
}

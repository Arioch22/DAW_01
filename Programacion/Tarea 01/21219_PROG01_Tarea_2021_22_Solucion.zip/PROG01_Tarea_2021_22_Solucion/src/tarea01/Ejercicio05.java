package tarea01;

import java.util.Scanner;

/**
 * M�quina expendedora de productos.
 * @author Profe
 */
public class Ejercicio05 {
    
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes

        // Variables de entrada
        int precio;
        int dineroIntroducido;
        
        // Variables de salida
        int monedas1Cent, monedas2Cent, monedas5Cent, monedas10Cent, monedas20Cent;
        int cambio;
        int totalMonedas;
        
        // Variables auxiliares
        int residuoCentimos;

        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("M�QUINA EXPENDEDORA DE PRODUCTOS");
        System.out.println("--------------------------------");
        
        System.out.print("Precio del producto (en c�ntimos): ") ;
        precio = teclado.nextInt();        
        System.out.print("Dinero introducido (en c�ntimos): ") ;
        dineroIntroducido = teclado.nextInt();
                
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        // C�lculo del cambio
        cambio = dineroIntroducido - precio ;
        residuoCentimos= cambio;
        
        // C�lculo de las monedas de 20 c�ntimos y del residuo que queda
        monedas20Cent= residuoCentimos / 20;   // Divisi�n entera (cociente /)
        residuoCentimos= residuoCentimos % 20; // Resto de la divis�n entera (m�dulo %)

        // C�lculo de las monedas de 10 c�ntimos y del residuo que queda
        monedas10Cent= residuoCentimos / 10;   
        residuoCentimos= residuoCentimos % 10; 

        // C�lculo de las monedas de 5 c�ntimos y del residuo que queda
        monedas5Cent= residuoCentimos / 5;   
        residuoCentimos= residuoCentimos % 5; 
        
        // C�lculo de las monedas de 2 c�ntimos y del residuo que queda
        monedas2Cent= residuoCentimos / 2;   
        residuoCentimos= residuoCentimos % 2; 
        
        // El residuo que queda ser� la cantidad de monedas de 1 c�ntimo que queda
        monedas1Cent= residuoCentimos;     
        
        // C�lculo del total de monedas
        totalMonedas= monedas1Cent + monedas2Cent + monedas5Cent + monedas10Cent + monedas20Cent;
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        System.out.println ("El cambio es: " + cambio + " c�ntimos.");
        
        System.out.println("Monedas de 20 c�ntimos: " + monedas20Cent);
        System.out.println("Monedas de 10 c�ntimos: " + monedas10Cent);
        System.out.println("Monedas de  5 c�ntimos: " + monedas5Cent);
        System.out.println("Monedas de  2 c�ntimos: " + monedas2Cent);
        System.out.println("Monedas de  1 c�ntimo:  " + monedas1Cent);
        System.out.println("Total de monedas: " + totalMonedas);
        
        System.out.println ();
    }
    
}

package tarea01;

/**
 * An�lisis de un texto.
 * 
 * @author Profe
 */
import java.util.Scanner;

public class Ejercicio06 {
 
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes

        // Variables de entrada
        String texto;
        
        // Variables de salida
        boolean mas5Caracteres, comienzaMayuscula, terminaMinuscula, terminaPuntosSuspensivos;   
        
        // Variables auxiliares
        int longitudTexto;
        char primerCaracter, ultimoCaracter, penultimoCaracter, antepenultimoCaracter;

        
        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado = new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("AN�LISIS DE UN TEXTO");
        System.out.println("--------------------");
        System.out.print("Introduzca un texto: ");
        texto = teclado.nextLine();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // C�lculo de informaci�n auxiliar previa
        longitudTexto= texto.length();        
        primerCaracter= texto.charAt(0);
        ultimoCaracter= texto.charAt(longitudTexto-1);
        penultimoCaracter= texto.charAt(longitudTexto-2);
        antepenultimoCaracter= texto.charAt(longitudTexto-3);

        // Comprobamos si tiene m�s de cinco caracteres
        mas5Caracteres= longitudTexto > 5;

        // Comprobamos si comienza por una letra may�scula
        comienzaMayuscula= primerCaracter>='A' && primerCaracter<='Z';
        
        // Comprobamos si termina por una letra min�scula
        terminaMinuscula= ultimoCaracter>='a' && ultimoCaracter<='z';

        // Comprobamos si termina por puntos suspensivos ("...")
        terminaPuntosSuspensivos= ultimoCaracter=='.' && penultimoCaracter=='.' 
                && antepenultimoCaracter == '.';
        
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        System.out.println ("El texto contiene m�s de cinco caracteres: " + mas5Caracteres);
        System.out.println ("El texto comienza con una letra may�scula: " + comienzaMayuscula);
        System.out.println ("El texto termina con una letra min�scula: " + terminaMinuscula);
        System.out.println ("El texto termina con unos puntos suspensivos (...): " + terminaPuntosSuspensivos);        
    }    
}
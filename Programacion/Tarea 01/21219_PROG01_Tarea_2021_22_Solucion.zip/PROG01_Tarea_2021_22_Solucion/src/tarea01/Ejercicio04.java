package tarea01;

/**
 * Trayecto en dos etapas.
 * 
 * @author Profe
 */
import java.util.Scanner;

public class Ejercicio04 {
 
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes
        final double COEFICIENTE_CONSUMO1= 1.0/2;		// 0.50
        final double COEFICIENTE_CONSUMO2= 25.0/100;	// 0.25


        // Variables de entrada
        double litrosInicialesDeposito;
        
        // Variables de salida
        double consumoPrimerRecorrido;
        double consumoSegundoRecorrido;

        // Variables auxiliares
        double litrosActualesDeposito;

        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("TRAYECTO EN DOS ETAPAS");
        System.out.println("----------------------");
        System.out.print("Introduzca la cantidad inicial de litros que se introducen en el dep�sito del veh�culo: ");
        litrosInicialesDeposito= teclado.nextDouble();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Iniciamos 
        litrosActualesDeposito= litrosInicialesDeposito;
        
        // Calculamos el consumo realizado en el primer recorrido
        consumoPrimerRecorrido= litrosActualesDeposito * COEFICIENTE_CONSUMO1;
        
        // Actualizamos la cantidad que queda en el dep�sito
        litrosActualesDeposito -= consumoPrimerRecorrido;
        
        // Calculamos el consumo realizado en el segundo recorrido
        consumoSegundoRecorrido= litrosActualesDeposito * COEFICIENTE_CONSUMO2;

        // Actualizamos la cantidad que queda en el dep�sito
        litrosActualesDeposito -= consumoSegundoRecorrido;
        
        //----------------------------------------------    
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        System.out.println ("Litros consumidos en el primer recorrido: " + consumoPrimerRecorrido);
        System.out.println ("Litros consumidos en el segundo recorrido: " + consumoSegundoRecorrido);
        System.out.println ("Litros sobrantes en el dep�sito: " + litrosActualesDeposito);        
    }    
}

package tarea01;

/**
 * Provincias de Andaluc�a.
 * @author Profe
 */
public class Ejercicio01 {
    
    
    // Definici�n del enum
    public enum ProvinciaAndalucia {ALMERIA, CADIZ, CORDOBA, GRANADA, HUELVA, JAEN, MALAGA, SEVILLA};
     
    public static void main(String[] args) {
     
        // Declaraci�n de una variable de ese tipo enum
        ProvinciaAndalucia provincia;

        // Presentaci�n del programa
        System.out.println ("PROVINCIAS DE ANDALUC�A");
        System.out.println ("-----------------------");
        
        // Vamos asignando a la variable cada uno de los valores posibles del enum
        provincia=ProvinciaAndalucia.ALMERIA;
        // Y la mostramos por pantalla
        System.out.println("Provincia 1: " + provincia);

        provincia=ProvinciaAndalucia.CADIZ;
        System.out.println("Provincia 2: " + provincia);

        provincia=ProvinciaAndalucia.CORDOBA;
        System.out.println("Provincia 3: " + provincia);

        provincia=ProvinciaAndalucia.GRANADA;
        System.out.println("Provincia 4: " + provincia);

        provincia=ProvinciaAndalucia.HUELVA;
        System.out.println("Provincia 5: " + provincia);

        provincia=ProvinciaAndalucia.JAEN;
        System.out.println("Provincia 6: " + provincia);

        provincia=ProvinciaAndalucia.MALAGA;
        System.out.println("Provincia 7: " + provincia);

        provincia=ProvinciaAndalucia.SEVILLA;
        System.out.println("Provincia 8: " + provincia);
    }
    
}

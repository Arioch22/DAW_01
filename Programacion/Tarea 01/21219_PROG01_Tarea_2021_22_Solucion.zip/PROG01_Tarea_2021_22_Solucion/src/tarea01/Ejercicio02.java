package tarea01;

import java.util.Scanner;

/**
 * C�lculos aritm�ticos.
 * Escribe un programa en Java que solicite dos n�meros reales y lleve a cabo los 
 * siguientes c�lculos:
 *  1. el triple del primer n�mero,
 *  2. la d�cima parte del segundo n�mero,
 *  3. el cuadrado del doble del producto de ambos n�meros,
 *  4. la mitad del cuadrado de la suma de ambos n�meros.
 * 
 * @author Profe
 */
public class Ejercicio02 {
    
    public static void main(String[] args) {

        //----------------------------------------------
        //          Declaraci�n de variables 
        //----------------------------------------------

        // Constantes

        
        // Variables de entrada
        double numero1, numero2;
        
        // Variables de salida
        double resultado1, resultado2, resultado3, resultado4;

        // Variables auxiliares
        double dobleProducto, suma;

        // Clase Scanner para petici�n de datos de entrada
        Scanner teclado= new Scanner (System.in);
        
        
        //----------------------------------------------
        //                Entrada de datos 
        //----------------------------------------------
        System.out.println("C�LCULOS ARITM�TICOS");
        System.out.println("--------------------");
        System.out.println("Introduzca dos n�meros reales: ");
        System.out.print("Primer n�mero: ");
        numero1= teclado.nextDouble();
        System.out.print("Segundo n�mero: ");
        numero2= teclado.nextDouble();
        
        //----------------------------------------------
        //                 Procesamiento 
        //----------------------------------------------
        
        // Primer c�lculo: triple del primer n�mero
        resultado1= 3.0 * numero1;
        
        // Segundo c�lculo: d�cima parte del segundo n�mero
        resultado2= numero2 / 10.0;

        // Tercer c�lculo: cuadrado del doble del producto de ambos n�meros
        dobleProducto= 2 * numero1 * numero2;
        resultado3= dobleProducto * dobleProducto;
        
        // Cuarto c�lculo: mitad del cuadrado de la suma de ambos n�meros
        suma= numero1+numero2;
        resultado4= (suma * suma) / 2.0;
        
        //----------------------------------------------
        //              Salida de resultados 
        //----------------------------------------------
        System.out.println ();
        System.out.println ("RESULTADO");
        System.out.println ("---------");
        System.out.println ("Triple del primer n�mero: " + resultado1);
        System.out.println ("D�cima parte del segundo n�mero: " + resultado2);
        System.out.println ("Cuadrado del doble del producto de ambos n�meros: " + resultado3);
        System.out.println ("Mitad del cuadrado de la suma de ambos n�meros: " + resultado4);                
    }    
}